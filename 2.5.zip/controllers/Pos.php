<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pos extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper(array('url', 'form'));
    }

    // ==========================================
    // LICENSE & HARDWARE BINDING MODULE
    // ==========================================

    private function _get_machine_id() {
        $id = '';
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            @exec('wmic csproduct get uuid 2>&1', $output);
            if (!empty($output)) {
                foreach ($output as $line) {
                    $line = trim($line);
                    if (!empty($line) && strtolower($line) !== 'uuid' && strtolower($line) !== 'none') {
                        $id = $line;
                        break;
                    }
                }
            }
            if (empty($id)) {
                @exec('vol C: 2>&1', $vol_output);
                if (!empty($vol_output)) {
                    foreach ($vol_output as $line) {
                        if (preg_match('/Serial Number is\s+([A-Za-0-9\-]+)/i', $line, $matches)) {
                            $id = $matches[1];
                            break;
                        }
                    }
                }
            }
        }
        if (empty($id)) {
            $id = gethostname() . '_' . php_uname('m');
        }
        return strtoupper(md5('ZENITH_POS_' . $id));
    }

    private function _check_license_status() {
        $machine_id = $this->_get_machine_id();
        $lic_file = APPPATH . 'config/license.lic';

        if (!file_exists($lic_file)) {
            return array(
                'valid' => false,
                'status' => 'NO_LICENSE',
                'message' => 'No active system license found on this machine hardware.',
                'machine_id' => $machine_id,
                'expiry_date' => null,
                'expiry_date_slash' => null,
                'expiry_md5_dash' => null,
                'expiry_md5_slash' => null,
                'system_date' => date('Y-m-d')
            );
        }

        $raw = @file_get_contents($lic_file);
        $lic_data = json_decode($raw, true);

        if (!$lic_data || empty($lic_data['machine_id']) || empty($lic_data['expiry_date']) || empty($lic_data['signature'])) {
            return array(
                'valid' => false,
                'status' => 'INVALID_LICENSE',
                'message' => 'License file structure is invalid or corrupted.',
                'machine_id' => $machine_id,
                'expiry_date' => null,
                'expiry_date_slash' => null,
                'expiry_md5_dash' => null,
                'expiry_md5_slash' => null,
                'system_date' => date('Y-m-d')
            );
        }

        // Hardware Binding Check
        if ($lic_data['machine_id'] !== $machine_id) {
            return array(
                'valid' => false,
                'status' => 'HARDWARE_MISMATCH',
                'message' => 'License file is bound to a different machine hardware ID.',
                'machine_id' => $machine_id,
                'expiry_date' => $lic_data['expiry_date'],
                'expiry_date_slash' => str_replace('-', '/', $lic_data['expiry_date']),
                'expiry_md5_dash' => md5($lic_data['expiry_date']),
                'expiry_md5_slash' => md5(str_replace('-', '/', $lic_data['expiry_date'])),
                'system_date' => date('Y-m-d')
            );
        }

        $expiry_dash = str_replace('/', '-', trim($lic_data['expiry_date']));
        $expiry_slash = str_replace('-', '/', trim($lic_data['expiry_date']));
        $expiry_md5_dash = md5($expiry_dash);
        $expiry_md5_slash = md5($expiry_slash);

        $secret = 'ZenithOMS@Dev2026#HardwareBoundSecret';
        $expected_sig1 = md5($machine_id . '|' . $expiry_dash . '|' . $expiry_md5_dash . '|' . $secret);
        $expected_sig2 = md5($machine_id . '|' . $expiry_slash . '|' . $expiry_md5_slash . '|' . $secret);

        if ($lic_data['signature'] !== $expected_sig1 && $lic_data['signature'] !== $expected_sig2) {
            return array(
                'valid' => false,
                'status' => 'INVALID_SIGNATURE',
                'message' => 'Cryptographic signature mismatch. License key tampered or invalid.',
                'machine_id' => $machine_id,
                'expiry_date' => $expiry_dash,
                'expiry_date_slash' => $expiry_slash,
                'expiry_md5_dash' => $expiry_md5_dash,
                'expiry_md5_slash' => $expiry_md5_slash,
                'system_date' => date('Y-m-d')
            );
        }

        // Expiration Check
        $current_date = date('Y-m-d');
        if ($current_date >= $expiry_dash) {
            return array(
                'valid' => false,
                'status' => 'EXPIRED',
                'message' => 'System license expired on ' . $expiry_dash . ' (' . $expiry_slash . '). System locked.',
                'machine_id' => $machine_id,
                'expiry_date' => $expiry_dash,
                'expiry_date_slash' => $expiry_slash,
                'expiry_md5_dash' => $expiry_md5_dash,
                'expiry_md5_slash' => $expiry_md5_slash,
                'system_date' => $current_date
            );
        }

        return array(
            'valid' => true,
            'status' => 'ACTIVE',
            'message' => 'License valid until ' . $expiry_dash,
            'machine_id' => $machine_id,
            'expiry_date' => $expiry_dash,
            'expiry_date_slash' => $expiry_slash,
            'expiry_md5_dash' => $expiry_md5_dash,
            'expiry_md5_slash' => $expiry_md5_slash,
            'system_date' => $current_date
        );
    }

    private function _decode_expiry_md5($input_str) {
        $input = strtolower(trim($input_str));
        $clean_date = str_replace('/', '-', $input);
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $clean_date)) {
            $t = strtotime($clean_date);
            if ($t) return date('Y-m-d', $t);
        }
        if (preg_match('/^[a-f0-9]{32}$/i', $input)) {
            $start = new DateTime('2020-01-01');
            $end   = new DateTime('2100-12-31');
            $interval = new DateInterval('P1D');
            $period = new DatePeriod($start, $interval, $end);
            
            foreach ($period as $dt) {
                $dash = $dt->format('Y-m-d');
                $slash = $dt->format('Y/m/d');
                if (md5($dash) === $input || md5($slash) === $input) {
                    return $dash;
                }
            }
        }
        return false;
    }

    public function get_license_info() {
        $info = $this->_check_license_status();
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'license' => $info
        )));
    }

    public function activate_license() {
        $password = $this->input->post('dev_password');
        $expiry_input = trim($this->input->post('expiry_date'));

        $confidential_password = 'ZenithDev@9988#Admin';

        if (empty($password) || $password !== $confidential_password) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Invalid Password. Activation access denied.'
            )));
            return;
        }

        if (empty($expiry_input)) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Activation Code (MD5 of Expiration Date YYYY/MM/DD) is required.'
            )));
            return;
        }

        $expiry_dash = $this->_decode_expiry_md5($expiry_input);

        if (!$expiry_dash) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Invalid Activation Code. Enter a valid MD5 hash of YYYY/MM/DD (or YYYY-MM-DD).'
            )));
            return;
        }

        $expiry_slash = str_replace('-', '/', $expiry_dash);
        $expiry_md5_dash = md5($expiry_dash);
        $expiry_md5_slash = md5($expiry_slash);

        $machine_id = $this->_get_machine_id();
        $secret = 'ZenithOMS@Dev2026#HardwareBoundSecret';

        $signature = md5($machine_id . '|' . $expiry_dash . '|' . $expiry_md5_dash . '|' . $secret);

        $lic_content = array(
            'system' => 'Zenith OMS POS Desktop',
            'machine_id' => $machine_id,
            'expiry_date' => $expiry_dash,
            'expiry_date_slash' => $expiry_slash,
            'expiry_md5_dash' => $expiry_md5_dash,
            'expiry_md5_slash' => $expiry_md5_slash,
            'signature' => $signature,
            'activated_at' => date('Y-m-d H:i:s')
        );

        $lic_file = APPPATH . 'config/license.lic';
        $written = file_put_contents($lic_file, json_encode($lic_content, JSON_PRETTY_PRINT));

        if ($written === false) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Failed to write license file to application/config/license.lic. Check directory permissions.'
            )));
            return;
        }

        $new_status = $this->_check_license_status();

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'message' => 'License successfully activated with Activation Code!',
            'license' => $new_status
        )));
    }

    /**
     * Main Screen View
     */
    public function index() {
        $license = $this->_check_license_status();
        $data['license'] = $license;
        $data['settings'] = $this->db->get_where('settings', array('id' => 1))->row_array();
        if (empty($data['settings'])) {
            $data['settings'] = array(
                'id' => 1,
                'reset_on_confirm' => 1,
                'direct_print' => 0,
                'enable_low_stock' => 1,
                'low_stock_limit' => 5,
                'enable_delivery' => 1,
                'delivery_partner' => 'Prompt XP',
                'custom_parcel_desc' => 'Handle with Care - Electronic & Retail Items',
                'remind_delivery' => 1,
                'remind_customer' => 1,
                'default_status' => 'Paid',
                'invoice_printer' => 'Standard PDF Printer',
                'receipt_printer' => 'POS-80 Thermal Printer',
                'parcel_printer' => 'Label Printer 4x6',
                'barcode_printer' => 'Barcode Label Printer',
                'restricted_mode' => 0
            );
        }
        $data['products'] = $license['valid'] ? $this->db->get('products')->result_array() : array();
        $data['customers'] = $license['valid'] ? $this->db->get('customers')->result_array() : array();
        $data['courier_rates'] = $license['valid'] ? $this->db->get('courier_rates')->result_array() : array();
        $this->load->view('pos_main', $data);
    }

    /**
     * Get initial state & settings via AJAX
     */
    public function get_initial_data() {
        $license = $this->_check_license_status();
        if (!$license['valid']) {
            $this->output
                 ->set_content_type('application/json')
                 ->set_output(json_encode(array(
                     'status' => 'license_error',
                     'license' => $license,
                     'message' => $license['message']
                 )));
            return;
        }

        $settings = $this->db->get_where('settings', array('id' => 1))->row_array();
        $products = $this->db->order_by('product_code', 'ASC')->get('products')->result_array();
        $customers = $this->db->order_by('name', 'ASC')->get('customers')->result_array();
        $courier_rates = $this->db->get('courier_rates')->result_array();

        // Calculate Next Order No & Invoice No
        $last_order = $this->db->select('id')->order_by('id', 'DESC')->limit(1)->get('orders')->row();
        $next_id = ($last_order ? $last_order->id : 0) + 1;
        $next_order_no = 'ORD-' . date('Ymd') . '-' . str_pad($next_id, 4, '0', STR_PAD_LEFT);
        $next_invoice_no = 'INV-' . (1000 + $next_id);

        $this->output
             ->set_content_type('application/json')
             ->set_output(json_encode(array(
                 'status' => 'success',
                 'license' => $license,
                 'settings' => $settings,
                 'products' => $products,
                 'customers' => $customers,
                 'courier_rates' => $courier_rates,
                 'next_order_no' => $next_order_no,
                 'next_invoice_no' => $next_invoice_no
             )));
    }

    // ==========================================
    // PRODUCTS MANAGEMENT MODULE
    // ==========================================

    public function get_products() {
        $search = $this->input->get('search');
        if (!empty($search)) {
            $this->db->group_start();
            $this->db->like('product_code', $search);
            $this->db->or_like('description', $search);
            $this->db->group_end();
        }
        $products = $this->db->order_by('product_code', 'ASC')->get('products')->result_array();

        // Aggregates for footer stats
        $total_products = count($products);
        $total_stock = 0;
        $total_cost_val = 0;
        $total_selling_val = 0;

        foreach ($products as $p) {
            $stk = (int)$p['stock'];
            $total_stock += $stk;
            $total_cost_val += ($stk * (float)$p['cost']);
            $total_selling_val += ($stk * (float)$p['selling_price']);
        }

        $this->output
             ->set_content_type('application/json')
             ->set_output(json_encode(array(
                 'status' => 'success',
                 'products' => $products,
                 'stats' => array(
                     'total_products' => $total_products,
                     'total_stock' => $total_stock,
                     'total_cost' => number_format($total_cost_val, 2, '.', ''),
                     'total_selling' => number_format($total_selling_val, 2, '.', '')
                 )
             )));
    }

    public function save_product() {
        $id = $this->input->post('id');
        $code = trim($this->input->post('product_code'));
        $desc = trim($this->input->post('description'));
        $stock = (int)$this->input->post('stock');
        $cost = (float)$this->input->post('cost');
        $price = (float)$this->input->post('selling_price');

        if (empty($code) || empty($desc)) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Product code and description are required.'
            )));
            return;
        }

        // Unique check
        if (!empty($id)) {
            $existing = $this->db->get_where('products', array('product_code' => $code, 'id !=' => $id))->row();
        } else {
            $existing = $this->db->get_where('products', array('product_code' => $code))->row();
        }

        if ($existing) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Product Code already exists. Choose a unique product code.'
            )));
            return;
        }

        $data = array(
            'product_code' => $code,
            'description' => $desc,
            'stock' => $stock,
            'cost' => $cost,
            'selling_price' => $price
        );

        if (!empty($id)) {
            $this->db->where('id', $id)->update('products', $data);
            $msg = 'Product updated successfully.';
        } else {
            $this->db->insert('products', $data);
            $id = $this->db->insert_id();
            $msg = 'Product added successfully.';
        }

        $product = $this->db->get_where('products', array('id' => $id))->row_array();

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'message' => $msg,
            'product' => $product
        )));
    }

    public function delete_product() {
        $id = $this->input->post('id');
        if (!empty($id)) {
            $this->db->where('id', $id)->delete('products');
        }
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'message' => 'Product deleted successfully.'
        )));
    }

    public function increase_stock() {
        $id = $this->input->post('id');
        $qty = (int)$this->input->post('quantity');

        if (empty($id) || $qty <= 0) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Valid product and stock quantity addition are required.'
            )));
            return;
        }

        $this->db->set('stock', 'stock + ' . $qty, FALSE);
        $this->db->where('id', $id);
        $this->db->update('products');

        $updated = $this->db->get_where('products', array('id' => $id))->row_array();

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'message' => 'Stock increased successfully.',
            'product' => $updated
        )));
    }

    // ==========================================
    // CUSTOMERS MANAGEMENT MODULE
    // ==========================================

    public function get_customers() {
        $search = $this->input->get('search');
        $sort = $this->input->get('sort');

        if (!empty($search)) {
            $this->db->group_start();
            $this->db->like('name', $search);
            $this->db->or_like('contacts', $search);
            $this->db->or_like('contact_2', $search);
            $this->db->or_like('email', $search);
            $this->db->or_like('address', $search);
            $this->db->or_like('nearest_city', $search);
            $this->db->group_end();
        }

        $customers = $this->db->get('customers')->result_array();
        $result = array();

        foreach ($customers as $c) {
            // Aggregate totals from completed orders
            $orders = $this->db->get_where('orders', array('customer_id' => $c['id'], 'is_draft' => 0))->result_array();
            $orders_count = count($orders);
            $total_spent = 0.00;
            $total_cost = 0.00;
            $items_count = 0;

            foreach ($orders as $o) {
                $total_spent += (float)$o['total_amount'];
                $total_cost += (float)$o['total_cost'];
                
                // Count items
                $item_query = $this->db->select_sum('quantity')->get_where('order_items', array('order_id' => $o['id']))->row();
                if ($item_query && $item_query->quantity) {
                    $items_count += (int)$item_query->quantity;
                }
            }

            $total_profit = $total_spent - $total_cost;
            $profit_margin = ($total_spent > 0) ? ($total_profit / $total_spent) * 100 : 0.00;
            $loyalty_score = floor($total_spent / 100);

            $c['orders_count'] = $orders_count;
            $c['items_count'] = $items_count;
            $c['total_spent'] = number_format($total_spent, 2, '.', '');
            $c['total_cost'] = number_format($total_cost, 2, '.', '');
            $c['total_profit'] = number_format($total_profit, 2, '.', '');
            $c['profit_margin'] = number_format($profit_margin, 2, '.', '');
            $c['loyalty_score'] = $loyalty_score;

            $result[] = $c;
        }

        // Sorting logic
        if ($sort === 'orders_high') {
            usort($result, function($a, $b) {
                return $b['orders_count'] - $a['orders_count'];
            });
        } else if ($sort === 'spent_high') {
            usort($result, function($a, $b) {
                return (float)$b['total_spent'] <=> (float)$a['total_spent'];
            });
        } else {
            usort($result, function($a, $b) {
                return strcmp($a['name'], $b['name']);
            });
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'customers' => $result
        )));
    }

    public function save_customer() {
        $id = $this->input->post('id');
        $name = trim($this->input->post('name'));
        $contacts = trim($this->input->post('contacts'));
        $contact_2 = trim($this->input->post('contact_2'));
        $email = trim($this->input->post('email'));
        $address = trim($this->input->post('address'));
        $nearest_city = trim($this->input->post('nearest_city'));

        if (empty($name)) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Customer name is required.'
            )));
            return;
        }

        $data = array(
            'name' => $name,
            'contacts' => $contacts,
            'contact_2' => $contact_2,
            'email' => $email,
            'address' => $address,
            'nearest_city' => $nearest_city
        );

        if (!empty($id)) {
            $this->db->where('id', $id)->update('customers', $data);
            $msg = 'Customer details updated successfully.';
        } else {
            $this->db->insert('customers', $data);
            $id = $this->db->insert_id();
            $msg = 'Customer added successfully.';
        }

        $customer = $this->db->get_where('customers', array('id' => $id))->row_array();

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'message' => $msg,
            'customer' => $customer
        )));
    }

    public function delete_customer() {
        $id = $this->input->post('id');
        if (!empty($id) && $id > 1) { // Prevent deleting default walk-in customer
            $this->db->where('id', $id)->delete('customers');
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'success',
                'message' => 'Customer deleted successfully.'
            )));
        } else {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Default Walk-in customer cannot be deleted.'
            )));
        }
    }

    // ==========================================
    // POS CHECKOUT & ORDERS ENGINE
    // ==========================================

    public function save_order() {
        $post = json_decode(file_get_contents('php://input'), true);
        if (empty($post)) {
            $post = $this->input->post();
        }

        $order_id = isset($post['order_id']) ? $post['order_id'] : null;
        $customer_id = isset($post['customer_id']) ? (int)$post['customer_id'] : 1;
        $customer_name = isset($post['customer_name']) ? trim($post['customer_name']) : 'Walk-in Customer';
        $customer_contacts = isset($post['customer_contacts']) ? trim($post['customer_contacts']) : '';
        $customer_address = isset($post['customer_address']) ? trim($post['customer_address']) : '';
        $is_draft = isset($post['is_draft']) ? (int)$post['is_draft'] : 0;
        $draft_name = isset($post['draft_name']) ? trim($post['draft_name']) : null;
        $status = isset($post['status']) ? $post['status'] : 'Paid';
        $delivery_charge = isset($post['delivery_charge']) ? (float)$post['delivery_charge'] : 500.00;
        $discount = isset($post['discount']) ? (float)$post['discount'] : 0.00;
        $items = isset($post['items']) ? $post['items'] : array();

        if (empty($items)) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Cannot save an empty order. Please add products to cart.'
            )));
            return;
        }

        // Load Settings to check low stock rules
        $settings = $this->db->get_where('settings', array('id' => 1))->row_array();

        // Check & Ensure Customer ID
        if ($customer_id <= 0) {
            $cust_row = $this->db->get_where('customers', array('name' => $customer_name))->row();
            if ($cust_row) {
                $customer_id = $cust_row->id;
            } else {
                $this->db->insert('customers', array(
                    'name' => $customer_name,
                    'contacts' => $customer_contacts,
                    'address' => $customer_address
                ));
                $customer_id = $this->db->insert_id();
            }
        }

        // Start DB Transaction for Safety
        $this->db->trans_start();

        // Stock Availability Check if Confirm Order (not draft)
        if ($is_draft == 0 && !empty($settings['enable_low_stock'])) {
            foreach ($items as $item) {
                $prod_id = isset($item['product_id']) ? $item['product_id'] : null;
                $pcode = isset($item['product_code']) ? $item['product_code'] : '';
                $req_qty = (int)$item['quantity'];

                $prod = null;
                if ($prod_id) {
                    $prod = $this->db->get_where('products', array('id' => $prod_id))->row();
                } else if (!empty($pcode)) {
                    $prod = $this->db->get_where('products', array('product_code' => $pcode))->row();
                }

                if ($prod && $prod->stock < $req_qty) {
                    $this->db->trans_rollback();
                    $this->output->set_content_type('application/json')->set_output(json_encode(array(
                        'status' => 'error',
                        'message' => "Insufficient stock for product {$prod->product_code} ({$prod->description}). Available: {$prod->stock}, Requested: {$req_qty}"
                    )));
                    return;
                }
            }
        }

        // Compute Subtotals, Costs, Profit
        $sub_total = 0.00;
        $total_cost = 0.00;
        $calculated_discount = 0.00;

        foreach ($items as &$item) {
            $qty = (int)$item['quantity'];
            $unit_price = (float)$item['unit_price'];
            $cost = (float)$item['cost'];
            $disc_per_unit = isset($item['discount']) ? (float)$item['discount'] : 0.00;

            $line_total = ($qty * $unit_price) - ($qty * $disc_per_unit);
            $line_cost = $qty * $cost;

            $item['total'] = $line_total;
            $item['discount'] = $disc_per_unit;
            $sub_total += ($qty * $unit_price);
            $calculated_discount += ($qty * $disc_per_unit);
            $total_cost += $line_cost;
        }

        if (empty($discount) || $discount == 0) {
            $discount = $calculated_discount;
        }

        $total_amount = $sub_total + $delivery_charge - $discount;
        $profit = ($total_amount - $delivery_charge) - $total_cost;
        $profit_margin = ($total_amount > 0) ? ($profit / $total_amount) * 100 : 0.00;

        $waybill_id = isset($post['waybill_id']) ? trim($post['waybill_id']) : '';

        // Generate Order No & Invoice No if new
        if (empty($order_id)) {
            $last_order = $this->db->select('id')->order_by('id', 'DESC')->limit(1)->get('orders')->row();
            $next_num = ($last_order ? $last_order->id : 0) + 1;
            
            if ($is_draft) {
                $order_no = 'ORD-DRAFT-' . str_pad($next_num, 4, '0', STR_PAD_LEFT);
                $invoice_no = null;
            } else {
                $order_no = 'ORD-' . date('Ymd') . '-' . str_pad($next_num, 4, '0', STR_PAD_LEFT);
                $invoice_no = 'INV-' . (1000 + $next_num);
            }
            $tracking_no = !empty($waybill_id) ? $waybill_id : ('PXP-' . rand(100000, 999999));
        } else {
            $existing_order = $this->db->get_where('orders', array('id' => $order_id))->row();
            $order_no = $existing_order->order_no;
            $tracking_no = !empty($waybill_id) ? $waybill_id : ($existing_order->tracking_no ? $existing_order->tracking_no : ('PXP-' . rand(100000, 999999)));
            if ($is_draft == 0 && empty($existing_order->invoice_no)) {
                $invoice_no = 'INV-' . (1000 + $order_id);
            } else {
                $invoice_no = $existing_order->invoice_no;
            }
        }

        $paid_amount = isset($post['paid_amount']) ? (float)$post['paid_amount'] : 0.00;
        $balance_amount = isset($post['balance']) ? (float)$post['balance'] : 0.00;
        if ($status === 'Paid') {
            $paid_amount = $total_amount;
            $balance_amount = 0.00;
        } else if ($status === 'Pending') {
            $paid_amount = 0.00;
            $balance_amount = $total_amount;
        }

        $order_data = array(
            'order_no' => $order_no,
            'customer_id' => $customer_id,
            'order_date' => date('Y-m-d H:i:s'),
            'status' => $status,
            'waybill_id' => $waybill_id,
            'tracking_no' => $tracking_no,
            'delivery_charge' => $delivery_charge,
            'discount' => $discount,
            'sub_total' => $sub_total,
            'total_cost' => $total_cost,
            'total_amount' => $total_amount,
            'paid_amount' => $paid_amount,
            'balance_amount' => $balance_amount,
            'profit' => $profit,
            'profit_margin' => $profit_margin,
            'is_draft' => $is_draft,
            'draft_name' => $is_draft ? $draft_name : null,
            'invoice_no' => $invoice_no
        );

        if (!empty($order_id)) {
            $this->db->where('id', $order_id)->update('orders', $order_data);
            // Remove old order items
            $this->db->where('order_id', $order_id)->delete('order_items');
            $current_order_id = $order_id;
        } else {
            $this->db->insert('orders', $order_data);
            $current_order_id = $this->db->insert_id();
        }

        // Insert items & Deduct stock if confirmed order
        foreach ($items as $item) {
            $prod_id = isset($item['product_id']) ? $item['product_id'] : null;
            $pcode = isset($item['product_code']) ? $item['product_code'] : 'N/A';
            $desc = isset($item['description']) ? $item['description'] : '';
            $qty = (int)$item['quantity'];
            $cost = (float)$item['cost'];
            $unit_price = (float)$item['unit_price'];
            $total = (float)$item['total'];

            $disc_per_unit = isset($item['discount']) ? (float)$item['discount'] : 0.00;

            $this->db->insert('order_items', array(
                'order_id' => $current_order_id,
                'product_id' => $prod_id,
                'product_code' => $pcode,
                'description' => $desc,
                'quantity' => $qty,
                'cost' => $cost,
                'unit_price' => $unit_price,
                'discount' => $disc_per_unit,
                'total' => $total
            ));

            // Inventory Stock Deduction
            if ($is_draft == 0) {
                if ($prod_id) {
                    $this->db->set('stock', 'stock - ' . $qty, FALSE);
                    $this->db->where('id', $prod_id);
                    $this->db->update('products');
                } else if (!empty($pcode)) {
                    $this->db->set('stock', 'stock - ' . $qty, FALSE);
                    $this->db->where('product_code', $pcode);
                    $this->db->update('products');
                }
            }
        }

        $this->db->trans_complete();

        if ($this->db->trans_status() === FALSE) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Failed to save order transaction in database.'
            )));
            return;
        }

        $full_order = $this->db->get_where('orders', array('id' => $current_order_id))->row_array();
        $full_order['customer'] = $this->db->get_where('customers', array('id' => $customer_id))->row_array();
        $full_order['items'] = $this->db->get_where('order_items', array('order_id' => $current_order_id))->result_array();

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'message' => $is_draft ? 'Draft order saved successfully.' : 'Order confirmed and inventory updated successfully.',
            'order' => $full_order
        )));
    }

    // ==========================================
    // ORDERS MANAGEMENT MODULE
    // ==========================================

    public function get_orders() {
        $search = $this->input->get('search');
        $sort = $this->input->get('sort');
        $hide_drafts = $this->input->get('hide_drafts');

        $this->db->select('orders.*, customers.name as customer_name, customers.contacts as customer_contacts, customers.address as customer_address');
        $this->db->from('orders');
        $this->db->join('customers', 'customers.id = orders.customer_id', 'left');

        if ($hide_drafts == '1') {
            $this->db->where('orders.is_draft', 0);
        }

        if (!empty($search)) {
            $this->db->group_start();
            $this->db->like('orders.order_no', $search);
            $this->db->or_like('orders.invoice_no', $search);
            $this->db->or_like('orders.tracking_no', $search);
            $this->db->or_like('customers.name', $search);
            $this->db->group_end();
        }

        if ($sort === 'oldest') {
            $this->db->order_by('orders.id', 'ASC');
        } else {
            $this->db->order_by('orders.id', 'DESC');
        }

        $orders = $this->db->get()->result_array();

        foreach ($orders as &$o) {
            $raw_date = (!empty($o['order_date']) && $o['order_date'] !== '0000-00-00 00:00:00') ? $o['order_date'] : ((!empty($o['created_at']) && $o['created_at'] !== '0000-00-00 00:00:00') ? $o['created_at'] : null);
            $o['formatted_date'] = $raw_date ? date('Y-m-d H:i', strtotime($raw_date)) : '-';
            
            $cnt_row = $this->db->query("SELECT COUNT(*) as cnt FROM order_items WHERE order_id = " . (int)$o['id'])->row();
            $o['items_count'] = $cnt_row ? (int)$cnt_row->cnt : 0;

            $o['sub_total'] = number_format((float)$o['sub_total'], 2, '.', '');
            $o['delivery_charge'] = number_format((float)$o['delivery_charge'], 2, '.', '');
            $o['discount'] = number_format((float)$o['discount'], 2, '.', '');
            $o['total_cost'] = number_format((float)$o['total_cost'], 2, '.', '');
            $o['total_amount'] = number_format((float)$o['total_amount'], 2, '.', '');
            $o['profit'] = number_format((float)$o['profit'], 2, '.', '');
            $o['profit_margin'] = number_format((float)$o['profit_margin'], 2, '.', '');
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'orders' => $orders
        )));
    }

    public function delete_order() {
        $id = $this->input->post('id');
        if (empty($id)) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array('status' => 'error', 'message' => 'Order ID required.')));
            return;
        }

        $order = $this->db->get_where('orders', array('id' => $id))->row();
        if (!$order) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array('status' => 'error', 'message' => 'Order not found.')));
            return;
        }

        $this->db->trans_start();

        // Stock Undo if deleting confirmed order
        if ($order->is_draft == 0) {
            $items = $this->db->get_where('order_items', array('order_id' => $id))->result_array();
            foreach ($items as $item) {
                if (!empty($item['product_id'])) {
                    $this->db->set('stock', 'stock + ' . (int)$item['quantity'], FALSE);
                    $this->db->where('id', $item['product_id']);
                    $this->db->update('products');
                } else if (!empty($item['product_code'])) {
                    $this->db->set('stock', 'stock + ' . (int)$item['quantity'], FALSE);
                    $this->db->where('product_code', $item['product_code']);
                    $this->db->update('products');
                }
            }
        }

        $this->db->where('id', $id)->delete('orders');

        $this->db->trans_complete();

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'message' => 'Order deleted successfully and inventory stock restored (Delete & Undo).'
        )));
    }

    public function update_order_status() {
        $id = $this->input->post('id');
        $status = $this->input->post('status');

        if (!in_array($status, array('Pending', 'Paid', 'Partial Paid'))) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array('status' => 'error', 'message' => 'Invalid status option.')));
            return;
        }

        $this->db->where('id', $id)->update('orders', array('status' => $status));

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'message' => "Order status updated to {$status}."
        )));
    }

    // ==========================================
    // DRAFTS MODULE
    // ==========================================

    public function get_drafts() {
        $search = $this->input->get('search');
        $this->db->select('orders.*, customers.name as customer_name');
        $this->db->from('orders');
        $this->db->join('customers', 'customers.id = orders.customer_id', 'left');
        $this->db->where('orders.is_draft', 1);

        if (!empty($search)) {
            $this->db->group_start();
            $this->db->like('orders.order_no', $search);
            $this->db->or_like('orders.draft_name', $search);
            $this->db->or_like('customers.name', $search);
            $this->db->group_end();
        }

        $this->db->order_by('orders.id', 'DESC');
        $drafts = $this->db->get()->result_array();

        foreach ($drafts as &$d) {
            $raw_date = (!empty($d['order_date']) && $d['order_date'] !== '0000-00-00 00:00:00') ? $d['order_date'] : ((!empty($d['created_at']) && $d['created_at'] !== '0000-00-00 00:00:00') ? $d['created_at'] : null);
            $d['formatted_date'] = $raw_date ? date('Y-m-d H:i', strtotime($raw_date)) : '-';
            $cnt_row = $this->db->query("SELECT COUNT(*) as cnt FROM order_items WHERE order_id = " . (int)$d['id'])->row();
            $d['items_count'] = $cnt_row ? (int)$cnt_row->cnt : 0;
            $d['total_amount'] = number_format((float)$d['total_amount'], 2, '.', '');
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'drafts' => $drafts
        )));
    }

    public function load_draft($id) {
        $order = $this->db->get_where('orders', array('id' => $id, 'is_draft' => 1))->row_array();
        if (!$order) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array('status' => 'error', 'message' => 'Draft order not found.')));
            return;
        }

        $customer = $this->db->get_where('customers', array('id' => $order['customer_id']))->row_array();
        $items = $this->db->get_where('order_items', array('order_id' => $id))->result_array();

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'order' => $order,
            'customer' => $customer,
            'items' => $items
        )));
    }

    // ==========================================
    // INVOICES MODULE
    // ==========================================

    public function get_invoices() {
        $search = $this->input->get('search');
        $this->db->select('orders.*, customers.name as customer_name');
        $this->db->from('orders');
        $this->db->join('customers', 'customers.id = orders.customer_id', 'left');
        $this->db->where('orders.is_draft', 0);

        if (!empty($search)) {
            $this->db->group_start();
            $this->db->like('orders.invoice_no', $search);
            $this->db->or_like('orders.order_no', $search);
            $this->db->or_like('customers.name', $search);
            $this->db->group_end();
        }

        $this->db->order_by('orders.id', 'DESC');
        $invoices = $this->db->get()->result_array();

        foreach ($invoices as &$inv) {
            $raw_date = (!empty($inv['order_date']) && $inv['order_date'] !== '0000-00-00 00:00:00') ? $inv['order_date'] : ((!empty($inv['created_at']) && $inv['created_at'] !== '0000-00-00 00:00:00') ? $inv['created_at'] : null);
            $inv['formatted_date'] = $raw_date ? date('Y-m-d H:i', strtotime($raw_date)) : '-';
            $inv['total_amount'] = number_format((float)$inv['total_amount'], 2, '.', '');
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'invoices' => $invoices
        )));
    }

    public function get_invoice_details($id) {
        $order = $this->db->get_where('orders', array('id' => $id))->row_array();
        if (!$order) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array('status' => 'error', 'message' => 'Invoice not found.')));
            return;
        }

        $customer = $this->db->get_where('customers', array('id' => $order['customer_id']))->row_array();
        $items = $this->db->get_where('order_items', array('order_id' => $id))->result_array();
        $settings = $this->db->get_where('settings', array('id' => 1))->row_array();

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'order' => $order,
            'customer' => $customer,
            'items' => $items,
            'settings' => $settings
        )));
    }

    public function get_bulk_parcel_details() {
        $post = json_decode(file_get_contents('php://input'), true);
        $raw_ids = isset($post['ids']) ? $post['ids'] : $this->input->post('ids');
        if (is_string($raw_ids)) {
            $raw_ids = explode(',', $raw_ids);
        }
        
        $ids = array_filter(array_map('intval', (array)$raw_ids));
        
        if (empty($ids)) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'No order IDs selected.'
            )));
            return;
        }

        $this->db->where_in('id', $ids);
        $this->db->order_by('id', 'DESC');
        $orders = $this->db->get('orders')->result_array();

        $settings = $this->db->get_where('settings', array('id' => 1))->row_array();
        if (empty($settings)) {
            $settings = array('delivery_partner' => 'Prompt XP');
        }

        $result = array();
        foreach ($orders as $order) {
            $customer = $this->db->get_where('customers', array('id' => $order['customer_id']))->row_array();
            $items = $this->db->get_where('order_items', array('order_id' => $order['id']))->result_array();

            $desc_parts = array();
            foreach ($items as $it) {
                $p_title = !empty($it['description']) ? $it['description'] : (!empty($it['product_code']) ? $it['product_code'] : 'Item');
                $desc_parts[] = $p_title . ' (' . $it['quantity'] . ')';
            }
            $item_summary = !empty($desc_parts) ? implode(', ', $desc_parts) : 'General Store Goods';

            $raw_date = (!empty($order['order_date']) && $order['order_date'] !== '0000-00-00 00:00:00') ? $order['order_date'] : $order['created_at'];
            $order['formatted_date'] = date('d/m/Y', strtotime($raw_date));
            $order['item_summary'] = $item_summary;

            $result[] = array(
                'order' => $order,
                'customer' => $customer ? $customer : array('name' => 'Walk-in Customer', 'contacts' => '-', 'contact_2' => '', 'address' => '-', 'nearest_city' => '-'),
                'items' => $items
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'orders' => $result,
            'settings' => $settings
        )));
    }

    // ==========================================
    // SALES ANALYTICS MODULE
    // ==========================================

    public function get_sales_analytics() {
        $period = $this->input->get('period'); // 'Today', 'Month', 'Year', 'All'
        
        $this->db->where('is_draft', 0);

        if ($period === 'Today') {
            $this->db->where('DATE(order_date)', date('Y-m-d'));
        } else if ($period === 'Month') {
            $this->db->where('MONTH(order_date)', date('m'));
            $this->db->where('YEAR(order_date)', date('Y'));
        } else if ($period === 'Year') {
            $this->db->where('YEAR(order_date)', date('Y'));
        }

        $orders = $this->db->get('orders')->result_array();

        $rows = array();
        $summary_orders = count($orders);
        $summary_items = 0;
        $summary_revenue = 0.00;
        $summary_cost = 0.00;
        $summary_profit = 0.00;

        // Grouping array
        $grouped = array();

        foreach ($orders as $o) {
            $rev = (float)$o['total_amount'];
            $cst = (float)$o['total_cost'];
            $prf = (float)$o['profit'];
            
            // Get item count for order
            $item_qty = 0;
            $items_q = $this->db->select_sum('quantity')->get_where('order_items', array('order_id' => $o['id']))->row();
            if ($items_q && $items_q->quantity) {
                $item_qty = (int)$items_q->quantity;
            }

            $summary_items += $item_qty;
            $summary_revenue += $rev;
            $summary_cost += $cst;
            $summary_profit += $prf;

            // Group key definition
            if ($period === 'Today') {
                $group_key = date('Y-m-d H:00', strtotime($o['order_date']));
            } else if ($period === 'Month') {
                $group_key = date('Y-m-d', strtotime($o['order_date']));
            } else {
                $group_key = date('Y-m', strtotime($o['order_date']));
            }

            if (!isset($grouped[$group_key])) {
                $grouped[$group_key] = array(
                    'period' => $group_key,
                    'orders_count' => 0,
                    'items_sold' => 0,
                    'revenue' => 0.00,
                    'cost' => 0.00,
                    'profit' => 0.00
                );
            }

            $grouped[$group_key]['orders_count']++;
            $grouped[$group_key]['items_sold'] += $item_qty;
            $grouped[$group_key]['revenue'] += $rev;
            $grouped[$group_key]['cost'] += $cst;
            $grouped[$group_key]['profit'] += $prf;
        }

        foreach ($grouped as $g) {
            $margin = ($g['revenue'] > 0) ? ($g['profit'] / $g['revenue']) * 100 : 0.00;
            $g['revenue'] = number_format($g['revenue'], 2, '.', '');
            $g['cost'] = number_format($g['cost'], 2, '.', '');
            $g['profit'] = number_format($g['profit'], 2, '.', '');
            $g['profit_margin'] = number_format($margin, 2, '.', '');
            $rows[] = $g;
        }

        $overall_margin = ($summary_revenue > 0) ? ($summary_profit / $summary_revenue) * 100 : 0.00;

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'period' => $period,
            'rows' => $rows,
            'summary' => array(
                'total_orders' => $summary_orders,
                'total_items' => $summary_items,
                'total_revenue' => number_format($summary_revenue, 2, '.', ''),
                'total_cost' => number_format($summary_cost, 2, '.', ''),
                'total_profit' => number_format($summary_profit, 2, '.', ''),
                'profit_margin' => number_format($overall_margin, 2, '.', '')
            )
        )));
    }

    // ==========================================
    // SETTINGS MODULE
    // ==========================================

    public function get_settings() {
        $settings = $this->db->get_where('settings', array('id' => 1))->row_array();
        $courier_rates = $this->db->get('courier_rates')->result_array();
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'settings' => $settings,
            'courier_rates' => $courier_rates
        )));
    }

    public function save_courier_rates() {
        $rates = json_decode($this->input->post('rates'), true);
        if (is_array($rates)) {
            foreach ($rates as $r) {
                if (!empty($r['courier_name'])) {
                    $cname = trim($r['courier_name']);
                    $first_kg = (float)$r['first_kg_rate'];
                    $add_kg = (float)$r['additional_kg_rate'];

                    $existing = $this->db->get_where('courier_rates', array('courier_name' => $cname))->row();
                    if ($existing) {
                        $this->db->where('id', $existing->id)->update('courier_rates', array(
                            'first_kg_rate' => $first_kg,
                            'additional_kg_rate' => $add_kg
                        ));
                    } else {
                        $this->db->insert('courier_rates', array(
                            'courier_name' => $cname,
                            'first_kg_rate' => $first_kg,
                            'additional_kg_rate' => $add_kg
                        ));
                    }
                }
            }
        }

        $updated_rates = $this->db->get('courier_rates')->result_array();
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'message' => 'Courier partner rates saved successfully.',
            'courier_rates' => $updated_rates
        )));
    }

    public function save_settings() {
        $store_name = trim($this->input->post('store_name'));
        $store_phone = trim($this->input->post('store_phone'));
        $store_address = trim($this->input->post('store_address'));
        $store_logo = trim($this->input->post('store_logo'));

        if (isset($_FILES['store_logo_file']) && $_FILES['store_logo_file']['error'] == UPLOAD_ERR_OK) {
            $tmp_name = $_FILES['store_logo_file']['tmp_name'];
            $ext = strtolower(pathinfo($_FILES['store_logo_file']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, array('jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'))) {
                $ext = 'png';
            }
            $target_filename = 'uploads/logo_' . time() . '.' . $ext;
            if (move_uploaded_file($tmp_name, FCPATH . $target_filename)) {
                $store_logo = $target_filename;
            }
        } else if (!empty($store_logo) && strpos($store_logo, 'data:image/') === 0) {
            if (preg_match('/^data:image\/(\w+);base64,/', $store_logo, $type)) {
                $img_data = substr($store_logo, strpos($store_logo, ',') + 1);
                $ext = strtolower($type[1]);
                $decoded = base64_decode($img_data);
                $target_filename = 'uploads/logo_' . time() . '.' . $ext;
                if (file_put_contents(FCPATH . $target_filename, $decoded)) {
                    $store_logo = $target_filename;
                }
            }
        }

        $data = array(
            'store_name' => !empty($store_name) ? $store_name : 'Sithangi Teddy Factory',
            'store_phone' => $store_phone,
            'store_address' => $store_address,
            'store_logo' => $store_logo,
            'reset_on_confirm' => (int)$this->input->post('reset_on_confirm'),
            'direct_print' => (int)$this->input->post('direct_print'),
            'enable_low_stock' => (int)$this->input->post('enable_low_stock'),
            'low_stock_limit' => (int)$this->input->post('low_stock_limit'),
            'enable_delivery' => (int)$this->input->post('enable_delivery'),
            'delivery_partner' => trim($this->input->post('delivery_partner')),
            'custom_parcel_desc' => trim($this->input->post('custom_parcel_desc')),
            'remind_delivery' => (int)$this->input->post('remind_delivery'),
            'remind_customer' => (int)$this->input->post('remind_customer'),
            'default_status' => $this->input->post('default_status'),
            'invoice_printer' => trim($this->input->post('invoice_printer')),
            'receipt_printer' => trim($this->input->post('receipt_printer')),
            'parcel_printer' => trim($this->input->post('parcel_printer')),
            'barcode_printer' => trim($this->input->post('barcode_printer')),
            'restricted_mode' => (int)$this->input->post('restricted_mode')
        );

        $this->db->where('id', 1)->update('settings', $data);

        $updated = $this->db->get_where('settings', array('id' => 1))->row_array();

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'message' => 'Business info & system settings saved successfully.',
            'settings' => $updated
        )));
    }

    // ==========================================
    // CLOUD SYSTEM CODE UPDATER MODULE
    // ==========================================

    public function check_cloud_update() {
        $current_version = '2.5.0';
        $custom_server_url = trim($this->input->get('update_server_url'));

        if (empty($custom_server_url)) {
            $custom_server_url = 'https://raw.githubusercontent.com/zencoresystems/zenith-oms-updates/main/version.json';
        }

        // Fetch remote version JSON
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $custom_server_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 6);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Zenith-OMS-Updater/2.5.0');
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error_msg = curl_error($ch);
        curl_close($ch);

        if ($http_code != 200 || empty($response)) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'warning',
                'message' => 'Could not connect to Cloud Update Server URL (' . (!empty($error_msg) ? $error_msg : 'HTTP ' . $http_code) . '). Please verify your network connection or update server URL.',
                'current_version' => $current_version,
                'update_available' => false
            )));
            return;
        }

        $update_data = json_decode($response, true);
        if (!$update_data || empty($update_data['latest_version'])) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Invalid update payload format received from Cloud Server.',
                'current_version' => $current_version,
                'update_available' => false
            )));
            return;
        }

        $latest_version = trim($update_data['latest_version']);
        $update_available = version_compare($latest_version, $current_version, '>');

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'status' => 'success',
            'current_version' => $current_version,
            'latest_version' => $latest_version,
            'update_available' => $update_available,
            'release_date' => isset($update_data['release_date']) ? $update_data['release_date'] : date('Y-m-d'),
            'changelog' => isset($update_data['changelog']) ? $update_data['changelog'] : 'General system enhancements and stability fixes.',
            'download_url' => isset($update_data['download_url']) ? $update_data['download_url'] : '',
            'message' => $update_available 
                ? "A new version (v{$latest_version}) is available for download!" 
                : "Your system is up to date (v{$current_version})."
        )));
    }

    public function apply_cloud_update() {
        $download_url = trim($this->input->post('download_url'));
        $target_version = trim($this->input->post('target_version'));

        if (empty($download_url)) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Invalid download URL for cloud update package.'
            )));
            return;
        }

        // Download update zip file to temp path
        $temp_zip = FCPATH . 'uploads/update_pack_' . time() . '.zip';
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $download_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Zenith-OMS-Updater/2.5.0');
        $raw_zip = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code != 200 || empty($raw_zip)) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Failed to download update package from cloud server. HTTP Code: ' . $http_code
            )));
            return;
        }

        if (file_put_contents($temp_zip, $raw_zip) === false) {
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Failed to write update zip archive to uploads directory.'
            )));
            return;
        }

        // Extract ZIP archive
        $zip = new ZipArchive();
        if ($zip->open($temp_zip) === TRUE) {
            $zip->extractTo(FCPATH);
            $zip->close();
            @unlink($temp_zip);

            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'success',
                'message' => 'System code successfully updated to v' . $target_version . '! Reloading Zenith POS...',
                'new_version' => $target_version
            )));
        } else {
            @unlink($temp_zip);
            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'status' => 'error',
                'message' => 'Corrupted or invalid update ZIP archive.'
            )));
        }
    }
}
