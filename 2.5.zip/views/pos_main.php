<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zenith OMS - Point of Sale (POS) Desktop Web Edition</title>
    <!-- Local Offline Bootstrap 5 CSS & FontAwesome & SweetAlert2 -->
    <link href="<?php echo base_url('bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('all.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('sweetalert2.min.css'); ?>" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #2196f3;
            --primary-blue-hover: #1976d2;
            --bg-neutral: #f8f9fa;
            --border-light: #dee2e6;
            --border-input: #cbd5e1;
            --font-desktop: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        }

        html, body {
            height: 100vh;
            overflow: hidden;
            margin: 0;
            padding: 0;
            background-color: var(--bg-neutral);
            font-family: var(--font-desktop);
            font-size: 0.875rem;
            color: #212529;
            user-select: none;
        }

        /* Top Navigation Bar */
        .desktop-navbar {
            background-color: #ffffff;
            border-bottom: 1px solid var(--border-light);
            padding: 0.2rem 0.75rem;
            height: 38px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            flex-shrink: 0;
        }

        .desktop-brand {
            font-weight: 700;
            font-size: 0.95rem;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .desktop-nav-btn {
            font-weight: 600;
            font-size: 0.78rem;
            padding: 0.2rem 0.55rem;
            border-radius: 4px;
            border: 1px solid var(--border-input);
            background-color: #ffffff;
            color: #334155;
            transition: all 0.15s ease-in-out;
        }

        .desktop-nav-btn:hover {
            background-color: #f1f5f9;
            border-color: #94a3b8;
            color: #0f172a;
        }

        .desktop-nav-btn.active {
            background-color: var(--primary-blue);
            color: #ffffff;
            border-color: var(--primary-blue);
        }

        /* Desktop Panels & Layout */
        .pos-card {
            background-color: #ffffff;
            border: 1px solid var(--border-light);
            border-radius: 5px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.03);
            margin-bottom: 0.35rem;
        }

        .pos-card-header {
            background-color: #f1f5f9;
            border-bottom: 1px solid var(--border-light);
            padding: 0.25rem 0.55rem;
            font-weight: 700;
            font-size: 0.8rem;
            color: #334155;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .pos-card-body {
            padding: 0.45rem 0.55rem;
        }

        /* Desktop Window Modals Aesthetics */
        .modal-desktop .modal-content {
            border-radius: 6px;
            border: 1px solid #94a3b8;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        .modal-desktop .modal-header {
            background-color: #f8fafc;
            border-bottom: 1px solid #e2e8f0;
            padding: 0.5rem 1rem;
        }

        .modal-desktop .modal-title {
            font-size: 0.95rem;
            font-weight: 700;
            color: #1e293b;
        }

        /* Desktop Form Controls & Buttons */
        .form-control-desktop, .form-select-desktop {
            border: 1px solid var(--border-input);
            border-radius: 4px;
            font-size: 0.82rem;
            padding: 0.2rem 0.4rem;
        }

        .btn-desktop-primary {
            background-color: var(--primary-blue);
            color: #ffffff;
            border: 1px solid var(--primary-blue-hover);
            font-weight: 600;
            border-radius: 4px;
            padding: 0.25rem 0.65rem;
            font-size: 0.82rem;
        }

        .btn-desktop-primary:hover {
            background-color: var(--primary-blue-hover);
            color: #ffffff;
        }

        .btn-desktop-secondary {
            background-color: #ffffff;
            border: 1px solid var(--border-input);
            color: #334155;
            font-weight: 500;
            border-radius: 4px;
            padding: 0.25rem 0.65rem;
            font-size: 0.82rem;
        }

        .btn-desktop-secondary:hover {
            background-color: #f1f5f9;
            color: #0f172a;
        }

        /* Desktop Grid / Table System */
        .left-pane-column {
            height: calc(100vh - 46px);
            display: flex;
            flex-direction: column;
            overflow: hidden;
            padding-right: 2px;
        }

        .customer-calc-card {
            flex: 1 1 auto;
            display: flex;
            flex-direction: column;
            min-height: 0;
        }

        .customer-calc-card .pos-card-body {
            display: flex;
            flex-direction: column;
            gap: 0.45rem;
        }

        .right-pane-column {
            height: calc(100vh - 46px);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .order-items-card {
            flex: 1 1 auto;
            display: flex;
            flex-direction: column;
            min-height: 0;
            margin-bottom: 0.35rem;
        }

        .order-items-card .pos-card-body {
            flex: 1 1 auto;
            min-height: 0;
            display: flex;
            flex-direction: column;
            padding: 0;
        }

        .pos-table-container {
            background: #ffffff;
            border: 1px solid var(--border-light);
            border-radius: 4px;
            flex: 1 1 auto;
            min-height: 0;
            max-height: none !important;
            overflow-y: auto;
        }

        .pos-table {
            margin-bottom: 0;
            font-size: 0.85rem;
        }

        .pos-table th {
            background-color: #f1f5f9;
            color: #1e293b;
            font-weight: 700;
            border-bottom: 1px solid var(--border-light);
            position: sticky;
            top: 0;
            z-index: 2;
            padding: 0.45rem 0.6rem;
        }

        .pos-table td {
            padding: 0.45rem 0.6rem;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
            color: #334155;
        }

        .pos-table tr.selected-row {
            background-color: #e0f2fe !important;
        }

        .pos-table tr:hover {
            background-color: #f8fafc;
            cursor: pointer;
        }

        /* Status Soft Badges */
        .badge-soft-paid {
            background-color: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
            padding: 0.25em 0.6em;
            border-radius: 12px;
            font-weight: 600;
        }

        .badge-soft-pending {
            background-color: #fef3c7;
            color: #92400e;
            border: 1px solid #fde68a;
            padding: 0.25em 0.6em;
            border-radius: 12px;
            font-weight: 600;
        }

        .badge-soft-partial {
            background-color: #e0e7ff;
            color: #3730a3;
            border: 1px solid #c7d2fe;
            padding: 0.25em 0.6em;
            border-radius: 12px;
            font-weight: 600;
        }

        /* Summary Calculations Grid */
        .calc-row {
            display: flex;
            justify-content: space-between;
            padding: 0.25rem 0;
            border-bottom: 1px dashed #e2e8f0;
            font-size: 0.825rem;
        }

        .calc-row.total-highlight {
            font-weight: 800;
            font-size: 1.05rem;
            color: var(--primary-blue-hover);
            border-bottom: 2px solid var(--primary-blue);
            padding-top: 0.4rem;
        }

        .calc-row.profit-highlight {
            font-weight: 700;
            color: #059669;
        }

        /* Footer Summaries Bar */
        .pos-footer-bar {
            background-color: #1e293b;
            color: #ffffff;
            padding: 0.6rem 1rem;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 0.85rem;
        }

        .pos-footer-metric {
            display: flex;
            flex-direction: column;
        }

        .pos-footer-metric .label {
            font-size: 0.7rem;
            color: #94a3b8;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .pos-footer-metric .value {
            font-weight: 700;
            font-size: 1.05rem;
        }

        /* Print Modal Template Styling */
        @media print {
            html, body {
                height: auto !important;
                overflow: visible !important;
                background: #ffffff !important;
            }
            body * {
                visibility: hidden;
            }
            .printable-area, .printable-area * {
                visibility: visible;
            }
            .printable-area {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
            }
            .a4-parcel-page {
                page-break-after: always !important;
                break-after: page !important;
                page-break-inside: avoid !important;
                break-inside: avoid !important;
                margin: 0 auto !important;
                box-shadow: none !important;
                border: none !important;
            }
        }

        .thermal-receipt {
            width: 300px;
            margin: 0 auto;
            background: #fff;
            padding: 15px;
            font-family: 'Courier New', Courier, monospace;
            font-size: 12px;
            color: #000;
        }

        .thermal-header {
            text-align: center;
            border-bottom: 1px dashed #000;
            padding-bottom: 8px;
            margin-bottom: 8px;
        }
    </style>
</head>
<body>

    <!-- Top Navigation Toolbar -->
    <nav class="desktop-navbar d-flex align-items-center justify-content-between">
        <div class="d-flex align-items-center gap-2">
            <div class="desktop-brand me-3">
                <i class="fa-solid fa-desktop text-primary"></i> Zenith OMS
            </div>
            <button id="btnNavProducts" class="desktop-nav-btn"><i class="fa-solid fa-boxes-stacked me-1"></i> Products</button>
            <button id="btnNavOrders" class="desktop-nav-btn"><i class="fa-solid fa-receipt me-1"></i> Orders</button>
            <button id="btnNavInvoices" class="desktop-nav-btn"><i class="fa-solid fa-file-invoice-dollar me-1"></i> Invoices</button>
            <button id="btnNavDrafts" class="desktop-nav-btn"><i class="fa-solid fa-folder-open me-1"></i> Drafts</button>
            <button id="btnNavSales" class="desktop-nav-btn"><i class="fa-solid fa-chart-line me-1"></i> Sales</button>
            <button id="btnNavCustomers" class="desktop-nav-btn"><i class="fa-solid fa-users me-1"></i> Customers</button>
        </div>
        <div class="d-flex align-items-center gap-2">
            <span class="badge bg-light text-dark border px-2 py-1"><i class="fa-solid fa-circle text-success me-1" style="font-size:8px;"></i> Offline Desktop</span>
            <button id="btnNavLicense" class="desktop-nav-btn text-primary fw-bold"><i class="fa-solid fa-shield-halved me-1"></i> License</button>
            <button id="btnNavSettings" class="desktop-nav-btn"><i class="fa-solid fa-gear me-1"></i> Settings</button>
            <button id="btnNavInfo" class="desktop-nav-btn"><i class="fa-solid fa-circle-info me-1"></i> Info</button>
        </div>
    </nav>

    <!-- Main Workspace Split Canvas -->
    <div class="container-fluid px-2 py-1 main-workspace-canvas">
        <div class="row g-2">
            
            <!-- LEFT PANE (~35% Width) -->
            <div class="col-lg-4 left-pane-column">
                
                <!-- Product Details Card -->
                <div class="pos-card">
                    <div class="pos-card-header">
                        <span><i class="fa-solid fa-barcode me-1 text-primary"></i> Product Details</span>
                        <span class="badge bg-secondary text-white" id="badgeStockStatus">Stock: -</span>
                    </div>
                    <div class="pos-card-body">
                        <div class="row g-2 mb-1">
                            <div class="col-8">
                                <label class="form-label mb-0 fw-semibold text-secondary" style="font-size: 0.82rem;">Product ID / Code</label>
                                <div class="input-group input-group-sm">
                                    <input type="text" id="inputProdCode" class="form-control form-control-desktop fw-bold" style="font-size: 0.88rem;" placeholder="e.g. AA-0001">
                                    <button id="btnSelectProductModal" class="btn btn-desktop-secondary btn-sm" style="font-size: 0.82rem;" type="button"><i class="fa-solid fa-magnifying-glass"></i> Select</button>
                                </div>
                            </div>
                            <div class="col-4">
                                <label class="form-label mb-0 fw-semibold text-secondary" style="font-size: 0.82rem;">Qty</label>
                                <input type="number" id="inputProdQty" class="form-control form-control-desktop text-center fw-bold" style="font-size: 0.88rem;" value="1" min="1">
                            </div>
                        </div>

                        <div class="mb-1">
                            <label class="form-label mb-0 fw-semibold text-secondary" style="font-size: 0.82rem;">Description</label>
                            <textarea id="inputProdDesc" class="form-control form-control-desktop" rows="1" style="height: 32px; resize: none; font-size: 0.85rem;" placeholder="Product name & specification details"></textarea>
                        </div>

                        <div class="row g-2 mb-2">
                            <div class="col-4">
                                <label class="form-label mb-0 fw-semibold text-secondary" style="font-size: 0.82rem;">Cost (Rs)</label>
                                <input type="number" id="inputProdCost" class="form-control form-control-desktop bg-light" style="font-size: 0.88rem;" readonly value="0.00">
                            </div>
                            <div class="col-4">
                                <label class="form-label mb-0 fw-semibold text-secondary" style="font-size: 0.82rem;">Selling (Rs)</label>
                                <input type="number" id="inputProdPrice" class="form-control form-control-desktop fw-bold" style="font-size: 0.88rem;" value="0.00" step="0.01">
                            </div>
                            <div class="col-4">
                                <label class="form-label mb-0 fw-semibold text-secondary" style="font-size: 0.82rem;">Discount / Unit</label>
                                <input type="number" id="inputProdDiscount" class="form-control form-control-desktop text-danger" style="font-size: 0.88rem;" value="0.00" step="0.01">
                            </div>
                        </div>

                        <div class="d-flex gap-2">
                            <button id="btnInsertCartItem" class="btn btn-sm btn-desktop-primary w-100 py-1" style="font-size: 0.85rem;"><i class="fa-solid fa-plus me-1"></i> [Insert] Item</button>
                            <button id="btnDeleteCartItem" class="btn btn-sm btn-desktop-secondary w-50 py-1 text-danger" style="font-size: 0.85rem;"><i class="fa-solid fa-trash me-1"></i> [Delete]</button>
                        </div>
                    </div>
                </div>

                <!-- Customer & Calculation Panel (Pixel-Accurate Screenshot 1 Clone) -->
                <div class="pos-card customer-calc-card mb-0">
                    <div class="pos-card-body p-2" style="font-size: 0.92rem; line-height: 1.4;">
                        <div class="d-flex align-items-center justify-content-between my-0">
                            <span class="fw-bold text-dark" style="font-size: 0.92rem;">Customer: <span id="lblActiveCustomerName" class="text-primary">---</span></span>
                            <div class="d-flex gap-1">
                                <button type="button" class="btn btn-xs btn-desktop-secondary text-primary border-primary py-0.5 px-2" style="font-size: 0.78rem;" id="btnEnterDetails">Enter Details</button>
                                <button type="button" class="btn btn-xs btn-desktop-secondary py-0.5 px-2" style="font-size: 0.78rem;" id="btnSelectCustomer">Select</button>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center my-0" style="font-size: 0.92rem;">
                            <div>Total Items: <strong id="calcTotalItems" style="font-size: 0.98rem;">0</strong></div>
                            <div class="d-flex align-items-center gap-1">
                                <span>Delivery: <strong id="lblDeliveryChargeVal" style="font-size: 0.98rem;">Rs.0</strong></span>
                                <button type="button" class="btn btn-xs btn-desktop-secondary py-0 px-1.5" style="font-size: 0.75rem;" id="btnSetDeliveryCharge">Set</button>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center my-0" style="font-size: 0.92rem;">
                            <div>Sub Total: <strong id="calcSubTotal" style="font-size: 0.98rem;">Rs.0</strong></div>
                            <div>Discount: <strong id="calcDiscountSummary" class="text-danger" style="font-size: 0.98rem;">Rs.0</strong></div>
                        </div>

                        <div class="fw-bold text-dark border-top pt-1 my-0 d-flex justify-content-between align-items-center" style="font-size: 1.1rem;">
                            <span>Total:</span>
                            <span id="calcGrandTotal" class="text-primary fw-extrabold" style="font-size: 1.3rem;">Rs.0</span>
                        </div>

                        <div class="d-flex align-items-center justify-content-between my-0 p-1.5 rounded bg-light border">
                            <div class="d-flex align-items-center gap-1">
                                <span class="fw-semibold text-secondary" style="font-size:0.8rem;">Status:</span>
                                <span id="lblActiveStatusText" class="badge bg-success text-white px-2 py-1" style="font-size:0.8rem;">Paid</span>
                            </div>
                            <div class="btn-group shadow-sm" role="group" id="statusBtnGroup">
                                <button type="button" class="btn btn-xs btn-outline-warning py-0.5 px-2 btn-status-toggle" style="font-size:0.78rem;" data-status="Pending"><i class="fa-solid fa-clock me-1"></i> Pending</button>
                                <button type="button" class="btn btn-xs btn-outline-success py-0.5 px-2 btn-status-toggle active" style="font-size:0.78rem;" data-status="Paid"><i class="fa-solid fa-circle-check me-1"></i> Paid</button>
                                <button type="button" class="btn btn-xs btn-outline-primary py-0.5 px-2 btn-status-toggle" style="font-size:0.78rem;" data-status="Partial Paid"><i class="fa-solid fa-pie-chart me-1"></i> Partial</button>
                            </div>
                        </div>

                        <div class="row align-items-center g-1 my-0 p-1.5 bg-white border rounded">
                            <div class="col-6">
                                <div class="small text-secondary fw-semibold" style="font-size:0.78rem;">Paid Amount</div>
                                <div class="fw-bold text-success" style="font-size: 1.2rem;" id="calcPaidAmountDisplay" title="Click to edit paid amount">Rs. 0</div>
                            </div>
                            <div class="col-6 text-end">
                                <div class="small text-secondary fw-semibold" style="font-size:0.78rem;">Balance Due</div>
                                <div class="fw-bold text-danger" style="font-size: 1.2rem;" id="calcBalance">Rs. 0</div>
                            </div>
                        </div>

                        <!-- Hidden state inputs for form payload binding -->
                        <select id="selectCustomer" class="d-none"></select>
                        <input type="hidden" id="custContact" value="">
                        <input type="hidden" id="custAddress" value="">
                        <input type="hidden" id="calcDeliveryCharge" value="0">
                        <input type="hidden" name="paymentStatus" id="inputPaymentStatusVal" value="Paid">
                    </div>
                </div>

            </div>

            <!-- RIGHT PANE (~65% Width) -->
            <div class="col-lg-8 right-pane-column">
                
                <!-- Order Items Grid Panel -->
                <div class="pos-card order-items-card">
                    <div class="pos-card-header">
                        <span><i class="fa-solid fa-cart-shopping me-1 text-primary"></i> Order Items</span>
                        <div class="d-flex align-items-center gap-2">
                            <span class="text-secondary" style="font-size:0.75rem;">Order No: <strong id="lblActiveOrderNo" class="text-dark">ORD-NEW</strong></span>
                        </div>
                    </div>
                    <div class="pos-card-body">
                        <div class="pos-table-container">
                            <table class="table pos-table table-hover align-middle mb-0" id="tableCartItems">
                                <thead>
                                    <tr>
                                        <th style="width: 15%;">Product ID</th>
                                        <th style="width: 40%;">Description</th>
                                        <th style="width: 12%;" class="text-center">Qty</th>
                                        <th style="width: 15%;" class="text-end">Unit Price</th>
                                        <th style="width: 18%;" class="text-end">Total</th>
                                    </tr>
                                </thead>
                                <tbody id="tbodyCartItems">
                                    <tr id="trEmptyCartPlaceholder">
                                        <td colspan="5" class="text-center py-5 text-muted">
                                            <i class="fa-solid fa-basket-shopping fa-3x mb-2 text-light-gray"></i>
                                            <p class="mb-0 fw-bold">No content in table</p>
                                            <small>Select or insert products from the left pane to build order</small>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Footer Summary Metric Bar -->
                <div class="pos-footer-bar mb-1">
                    <div class="pos-footer-metric">
                        <span class="label">Items</span>
                        <span class="value" id="footSummaryItems">0</span>
                    </div>
                    <div class="pos-footer-metric">
                        <span class="label">Sub Total</span>
                        <span class="value" id="footSummarySubtotal">Rs. 0</span>
                    </div>
                    <div class="pos-footer-metric">
                        <span class="label">Delivery</span>
                        <span class="value" id="footSummaryDelivery">Rs. 0</span>
                    </div>
                    <div class="pos-footer-metric">
                        <span class="label">Net Discount</span>
                        <span class="value text-warning" id="footSummaryDiscount">Rs. 0</span>
                    </div>
                    <div class="pos-footer-metric">
                        <span class="label">Grand Total</span>
                        <span class="value text-info" id="footSummaryGrandTotal">Rs. 0</span>
                    </div>
                    <div class="pos-footer-metric">
                        <span class="label">Profit</span>
                        <span class="value text-success" id="footSummaryProfit">Rs. 0</span>
                    </div>
                </div>

                <!-- Main Action Buttons -->
                <div class="d-flex gap-2 justify-content-end bg-white p-1 border rounded shadow-sm">
                    <button id="btnResetCart" class="btn btn-desktop-secondary"><i class="fa-solid fa-rotate-left me-1"></i> [Reset]</button>
                    <button id="btnSaveDraft" class="btn btn-desktop-secondary"><i class="fa-solid fa-floppy-disk me-1"></i> [Save Draft]</button>
                    <button id="btnGenerateInvoice" class="btn btn-desktop-secondary"><i class="fa-solid fa-file-invoice me-1"></i> [Generate Invoice]</button>
                    <button id="btnConfirmOrder" class="btn btn-desktop-primary px-4"><i class="fa-solid fa-print me-1"></i> [Confirm & Generate Receipt]</button>
                </div>

            </div>
        </div>
    <!-- ================================================================= -->
    <!-- MODAL: CUSTOMER DETAILS MODAL (Screenshot 2 Clone) -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalCustomerDetails" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center py-2 px-3">
                    <div class="modal-title fw-bold text-dark">Customer Details</div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-3">
                    <form id="formCustomerDetails">
                        <input type="hidden" id="custDetailId" value="">
                        
                        <div class="mb-3">
                            <label class="form-label mb-1 text-dark fw-semibold">Customer Name:</label>
                            <input type="text" id="custDetailName" class="form-control form-control-desktop">
                        </div>

                        <div class="mb-3">
                            <label class="form-label mb-1 text-dark fw-semibold">Customer Address:</label>
                            <textarea id="custDetailAddress" class="form-control form-control-desktop" rows="3"></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label mb-1 text-dark fw-semibold">Nearest City:</label>
                            <input type="text" id="custDetailNearestCity" class="form-control form-control-desktop">
                        </div>

                        <div class="mb-3">
                            <label class="form-label mb-1 text-dark fw-semibold">Contact Number 1:</label>
                            <input type="text" id="custDetailContact1" class="form-control form-control-desktop">
                        </div>

                        <div class="mb-3">
                            <label class="form-label mb-1 text-dark fw-semibold">Contact Number 2:</label>
                            <input type="text" id="custDetailContact2" class="form-control form-control-desktop">
                        </div>

                        <div class="mb-3">
                            <label class="form-label mb-1 text-dark fw-semibold">Email:</label>
                            <input type="text" id="custDetailEmail" class="form-control form-control-desktop">
                        </div>
                    </form>

                    <div class="d-flex justify-content-between align-items-center mt-3 pt-2">
                        <button type="button" class="btn btn-desktop-secondary px-3" id="btnOpenCustomerSelectorFromModal">Select</button>
                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-desktop-secondary px-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-desktop-primary px-4" id="btnSaveCustomerDetails">Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL: CUSTOMERS SELECTOR MODAL (Screenshot 3 Clone) -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalCustomerSelector" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center py-2 px-3">
                    <div class="modal-title fw-bold text-dark">Customers</div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-3">
                    <div class="mb-3">
                        <input type="text" id="custSelectorSearchInput" class="form-control form-control-desktop w-100" placeholder="" autofocus>
                    </div>
                    <div class="pos-table-container" style="max-height: 400px;">
                        <table class="table pos-table table-hover align-middle mb-0" id="tableCustSelector">
                            <thead>
                                <tr>
                                    <th style="width: 25%;">Customer Name</th>
                                    <th style="width: 35%;">Address</th>
                                    <th style="width: 15%;">Contacts</th>
                                    <th style="width: 13%;">Email</th>
                                    <th style="width: 12%;">Loyalty ...</th>
                                </tr>
                            </thead>
                            <tbody id="tbodyCustSelector">
                                <!-- Dynamic customer selector rows -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL: DELIVERY DETAILS MODAL (Screenshot 4 Clone) -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalDeliveryDetails" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center py-2 px-3">
                    <div class="modal-title fw-bold text-dark">Delivery Details</div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3 row align-items-center">
                        <label class="col-5 col-form-label text-dark fw-semibold">Delivery Service:</label>
                        <div class="col-7">
                            <select id="deliveryServiceSelect" class="form-select form-select-desktop">
                                <option value="Prompt XP">Prompt XP</option>
                                <option value="Fargo">Fargo</option>
                                <option value="Pronto">Pronto</option>
                                <option value="Domex">Domex</option>
                                <option value="SL Post">SL Post</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3 row align-items-center">
                        <label class="col-5 col-form-label text-dark fw-semibold">Waybill ID / Tracking No:</label>
                        <div class="col-7">
                            <input type="text" id="inputWaybillId" class="form-control form-control-desktop text-start" placeholder="e.g. WB-998811">
                        </div>
                    </div>

                    <div class="mb-3 row align-items-center">
                        <label class="col-5 col-form-label text-dark fw-semibold">Package Weight (KG):</label>
                        <div class="col-7">
                            <input type="number" id="inputPackageWeight" class="form-control form-control-desktop text-start" value="0" step="0.1">
                        </div>
                    </div>

                    <div class="mb-3 row align-items-center">
                        <label class="col-5 col-form-label text-dark fw-semibold">Delivery Charge:</label>
                        <div class="col-7">
                            <input type="number" id="inputDeliveryChargeModal" class="form-control form-control-desktop text-start" value="0" step="10">
                        </div>
                    </div>

                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" id="chkFreeDelivery">
                        <label class="form-check-label fw-semibold text-dark" for="chkFreeDelivery">Free Delivery Charge</label>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-desktop-secondary px-4" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-desktop-primary px-4" id="btnSaveDeliveryDetails" data-bs-dismiss="modal">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL 0: PRODUCT SELECTION POPUP MODAL (Latest Screenshot 2 Clone) -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalProductSelector" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center py-2 px-3">
                    <div class="modal-title fw-bold">Products</div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-3">
                    <div class="mb-3">
                        <input type="text" id="psSearch" class="form-control form-control-desktop w-100" placeholder="Search products..." autofocus>
                    </div>
                    <div class="pos-table-container" style="max-height: 380px;">
                        <table class="table pos-table table-hover align-middle mb-0" id="tablePsProducts">
                            <thead>
                                <tr>
                                    <th style="width: 20%;">Product ID</th>
                                    <th style="width: 50%;">Description</th>
                                    <th style="width: 15%;">Price</th>
                                    <th style="width: 15%;">Stock</th>
                                </tr>
                            </thead>
                            <tbody id="tbodyPsProducts">
                                <!-- Dynamic product selector rows -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL 1: PRODUCTS MANAGEMENT MODAL (Screenshot 1 Clone) -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalProducts" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center">
                    <div class="modal-title">Products Management</div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-3">
                    <div class="row g-3">
                        <!-- Left Pane Form -->
                        <div class="col-md-4 pe-3">
                            <form id="formProductManagement">
                                <input type="hidden" id="pmId">
                                <div class="mb-2">
                                    <label class="form-label mb-1 text-secondary">Product ID:</label>
                                    <input type="text" id="pmCode" class="form-control form-control-desktop" placeholder="AA-0001" required>
                                </div>
                                <div class="mb-2">
                                    <label class="form-label mb-1 text-secondary">Description:</label>
                                    <textarea id="pmDesc" class="form-control form-control-desktop" rows="3" required></textarea>
                                </div>
                                <div class="mb-2">
                                    <label class="form-label mb-1 text-secondary">Stock:</label>
                                    <input type="number" id="pmStock" class="form-control form-control-desktop" required>
                                </div>
                                <div class="mb-2">
                                    <label class="form-label mb-1 text-secondary">Cost:</label>
                                    <input type="number" id="pmCost" class="form-control form-control-desktop" step="0.01" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label mb-1 text-secondary">Selling Price:</label>
                                    <input type="number" id="pmSellingPrice" class="form-control form-control-desktop" step="0.01" required>
                                </div>

                                <div class="d-grid gap-2">
                                    <div class="d-flex gap-2">
                                        <button type="button" id="btnPmInsert" class="btn btn-desktop-primary w-100">Insert</button>
                                        <button type="button" id="btnPmUpdate" class="btn btn-desktop-secondary w-100">Update</button>
                                        <button type="button" id="btnPmDelete" class="btn btn-desktop-secondary w-100 text-danger">Delete</button>
                                    </div>
                                    <div class="d-flex gap-2">
                                        <button type="button" id="btnPmPrintBarcode" class="btn btn-desktop-secondary w-100">Print Barcodes</button>
                                        <button type="button" id="btnPmIncreaseStock" class="btn btn-desktop-secondary w-100">Increase Stock</button>
                                    </div>
                                </div>
                            </form>

                            <!-- Desktop Bottom Stats Text (Matching Screenshot 1) -->
                            <div class="mt-4 text-dark font-monospace" style="font-size:0.825rem; line-height: 1.6;">
                                <div>Products: <span id="pmStatTotalProd" class="fw-bold">0</span></div>
                                <div>Stock: <span id="pmStatTotalStock" class="fw-bold">0</span></div>
                                <div>Total Products (Cost): <span id="pmStatTotalCost" class="fw-bold">Rs. 0</span></div>
                                <div>Total Products (Selling Price): <span id="pmStatTotalSelling" class="fw-bold">Rs. 0</span></div>
                            </div>
                        </div>

                        <!-- Right Pane Table Grid -->
                        <div class="col-md-8 border-start ps-3">
                            <div class="mb-2">
                                <input type="text" id="pmSearch" class="form-control form-control-desktop w-100" placeholder="Search products...">
                            </div>
                            <div class="pos-table-container" style="min-height:360px; max-height:420px;">
                                <table class="table pos-table table-hover align-middle mb-0" id="tablePmProducts">
                                    <thead>
                                        <tr>
                                            <th style="width: 20%;">Product ID</th>
                                            <th style="width: 45%;">Description</th>
                                            <th style="width: 10%;" class="text-center">Stock</th>
                                            <th style="width: 12.5%;">Cost</th>
                                            <th style="width: 12.5%;">Selling Price</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tbodyPmProducts">
                                        <!-- Dynamic product rows -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL 2: ORDERS MANAGEMENT MODAL -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalOrders" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center">
                    <div class="modal-title">Orders</div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-3">
                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
                        <div class="d-flex align-items-center gap-2">
                            <span class="text-secondary fw-semibold">Sort :</span>
                            <select id="omSort" class="form-select form-select-desktop" style="width:150px;">
                                <option value="newest">Newest First</option>
                                <option value="oldest">Oldest First</option>
                            </select>
                            <div class="form-check form-check-inline mb-0 ms-2">
                                <input class="form-check-input" type="checkbox" id="omHideDrafts" checked>
                                <label class="form-check-label text-secondary" for="omHideDrafts">Filter</label>
                            </div>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <button id="btnOmDeleteUndo" class="btn btn-desktop-secondary btn-sm">Delete & Undo</button>
                            <button id="btnOmUpdateStatus" class="btn btn-desktop-secondary btn-sm">Update Status</button>
                            <button id="btnOmGenInvoice" class="btn btn-desktop-secondary btn-sm">Generate Invoice</button>
                            <button id="btnOmGenReceipt" class="btn btn-desktop-secondary btn-sm">Generate Receipt</button>
                            <button id="btnOmBulkPrintParcel" class="btn btn-desktop-primary btn-sm"><i class="fa-solid fa-print me-1"></i> Bulk Print Parcel Labels (4 per A4 Sheet)</button>
                            <button id="btnOmExport" class="btn btn-desktop-secondary btn-sm px-3">Export</button>
                        </div>
                    </div>

                    <div class="mb-2">
                        <input type="text" id="omSearch" class="form-control form-control-desktop" placeholder="Search order no, customer, tracking no...">
                    </div>

                    <div class="pos-table-container" style="max-height: 420px;">
                        <table class="table pos-table table-hover align-middle mb-0" id="tableOrders">
                            <thead>
                                <tr>
                                    <th style="width: 4%;" class="text-center"><input type="checkbox" id="chkSelectAllOrders" class="form-check-input" title="Select All Orders"></th>
                                    <th style="width: 7%;">No.</th>
                                    <th style="width: 14%;">Date</th>
                                    <th style="width: 20%;">Customer Name</th>
                                    <th style="width: 9%;">Status</th>
                                    <th style="width: 10%;">Tracking...</th>
                                    <th style="width: 8%;">Cost</th>
                                    <th style="width: 7%;">Discount</th>
                                    <th style="width: 9%;">Total</th>
                                    <th style="width: 7%;">Profit</th>
                                    <th style="width: 5%;">Mar...</th>
                                </tr>
                            </thead>
                            <tbody id="tbodyOrders">
                                <!-- Dynamic order rows -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL 3: INVOICES MODAL -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalInvoices" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center">
                    <div class="modal-title">Invoices</div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-3">
                    <div class="mb-3">
                        <input type="text" id="invSearch" class="form-control form-control-desktop w-100" placeholder="Search...">
                    </div>
                    <div class="pos-table-container mb-3" style="max-height: 380px;">
                        <table class="table pos-table table-hover align-middle mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 15%;">No.</th>
                                    <th style="width: 35%;">Date</th>
                                    <th style="width: 50%;">Customer Name</th>
                                </tr>
                            </thead>
                            <tbody id="tbodyInvoices">
                                <!-- Dynamic Invoices -->
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end gap-2">
                        <button id="btnInvDelete" class="btn btn-desktop-secondary px-4">Delete</button>
                        <button id="btnInvOpen" class="btn btn-desktop-secondary px-4">Open</button>
                        <button id="btnInvPreview" class="btn btn-desktop-primary px-4">Preview</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL 4: DRAFTS MODAL -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalDrafts" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center">
                    <div class="modal-title">Drafts</div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-3">
                    <div class="mb-3">
                        <input type="text" id="draftSearch" class="form-control form-control-desktop w-100" placeholder="Search...">
                    </div>
                    <div class="pos-table-container mb-3" style="max-height: 380px;">
                        <table class="table pos-table table-hover align-middle mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 15%;">No.</th>
                                    <th style="width: 30%;">Date</th>
                                    <th style="width: 25%;">Draft Name</th>
                                    <th style="width: 30%;">Customer Name</th>
                                </tr>
                            </thead>
                            <tbody id="tbodyDrafts">
                                <!-- Dynamic Drafts -->
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end gap-2">
                        <button id="btnDraftDelete" class="btn btn-desktop-secondary px-4">Delete</button>
                        <button id="btnDraftOpen" class="btn btn-desktop-primary px-4">Open</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL 5: SALES ANALYTICS MODAL -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalSales" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center">
                    <div class="modal-title">Sales</div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-3">
                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="d-flex align-items-center gap-2">
                                <span class="text-secondary fw-semibold">Period :</span>
                                <select id="salesPeriodSelect" class="form-select form-select-desktop" style="width:140px;">
                                    <option value="Month">Month</option>
                                    <option value="Year">Year</option>
                                    <option value="Today">Today</option>
                                </select>
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <span class="text-secondary fw-semibold">Sort :</span>
                                <select id="salesSortSelect" class="form-select form-select-desktop" style="width:140px;">
                                    <option value="newest">Newest First</option>
                                    <option value="oldest">Oldest First</option>
                                </select>
                            </div>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <button id="btnSalesCharts" class="btn btn-desktop-secondary btn-sm px-3">Charts</button>
                            <button id="btnSalesMoreDetails" class="btn btn-desktop-secondary btn-sm px-3">More Details</button>
                            <button id="btnSalesExport" class="btn btn-desktop-secondary btn-sm px-3">Export</button>
                        </div>
                    </div>

                    <div class="pos-table-container mb-3" style="max-height: 380px;">
                        <table class="table pos-table table-hover align-middle mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 18%;">Period</th>
                                    <th style="width: 10%;">Orders</th>
                                    <th style="width: 12%;">Items Sold</th>
                                    <th style="width: 18%;">Revenue</th>
                                    <th style="width: 16%;">Cost</th>
                                    <th style="width: 14%;">Profit</th>
                                    <th style="width: 12%;">Profit Margin</th>
                                </tr>
                            </thead>
                            <tbody id="tbodySales">
                                <!-- Dynamic Sales Rows -->
                            </tbody>
                        </table>
                    </div>

                    <div class="row pt-2 font-monospace border-top fw-bold text-dark" style="font-size:0.9rem;">
                        <div class="col-4 text-start">
                            Total Orders: <span id="salesTotalOrders">0</span>
                        </div>
                        <div class="col-4 text-center">
                            Total Revenue: <span id="salesTotalRevenue">Rs. 0.00</span>
                        </div>
                        <div class="col-4 text-end text-success">
                            Total Profit: <span id="salesTotalProfit">Rs. 0.00</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL 6: CUSTOMERS MODAL -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalCustomers" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center">
                    <div class="modal-title">Customers</div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-3">
                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="d-flex align-items-center gap-2">
                                <span class="text-secondary fw-semibold">Sort :</span>
                                <select id="cmSort" class="form-select form-select-desktop" style="width:200px;">
                                    <option value="orders_high">Orders Count (High to Low)</option>
                                    <option value="spent_high">Total Spent (High to Low)</option>
                                    <option value="name">Name A-Z</option>
                                </select>
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <span class="text-secondary fw-semibold">Search :</span>
                                <input type="text" id="cmSearch" class="form-control form-control-desktop" style="width:250px;">
                            </div>
                        </div>
                        <div>
                            <button id="btnCmExport" class="btn btn-desktop-secondary btn-sm px-3">Export</button>
                        </div>
                    </div>

                    <div class="pos-table-container" style="max-height: 400px;">
                        <table class="table pos-table table-hover align-middle mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 18%;">Customer Name</th>
                                    <th style="width: 18%;">Contacts</th>
                                    <th style="width: 7%;">Orders</th>
                                    <th style="width: 7%;">Items</th>
                                    <th style="width: 12%;">Total Spent</th>
                                    <th style="width: 11%;">Total Cost</th>
                                    <th style="width: 11%;">Total Profit</th>
                                    <th style="width: 8%;">Profit Mar...</th>
                                    <th style="width: 8%;">Loyalty Sc...</th>
                                </tr>
                            </thead>
                            <tbody id="tbodyCustomers">
                                <!-- Dynamic Customers -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL 7: SETTINGS MODAL -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalSettings" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center">
                    <div class="modal-title">Settings</div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-3">
                    <form id="formSystemSettings">
                        <h6 class="fw-bold border-bottom pb-1 mb-2 text-primary"><i class="fa-solid fa-store me-1"></i> Business & Store Details</h6>
                        <div class="row g-2 mb-3">
                            <div class="col-md-6">
                                <label class="form-label mb-1 fw-semibold">Business / Store Name</label>
                                <input type="text" id="setStoreName" class="form-control form-control-desktop" placeholder="e.g. Sithangi Teddy Factory">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label mb-1 fw-semibold">Telephone / TP Number</label>
                                <input type="text" id="setStorePhone" class="form-control form-control-desktop" placeholder="e.g. 0775476996">
                            </div>
                            <div class="col-md-7">
                                <label class="form-label mb-1 fw-semibold">Business Address</label>
                                <textarea id="setStoreAddress" class="form-control form-control-desktop" rows="2" placeholder="e.g. No 45, Temple Road, Maharagama"></textarea>
                            </div>
                            <div class="col-md-5">
                                <label class="form-label mb-1 fw-semibold">Business Logo</label>
                                <div class="d-flex align-items-center gap-2 mt-1">
                                    <div id="setLogoPreviewBox" class="border rounded p-1 text-center bg-white" style="width: 70px; height: 50px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                                        <img id="setLogoImgPreview" src="" alt="Logo" style="max-width: 100%; max-height: 100%; display: none;">
                                        <i id="setLogoIconPlaceholder" class="fa-solid fa-image text-muted fs-4"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <input type="file" id="setLogoFileInput" class="form-control form-control-desktop form-control-sm mb-1" accept="image/*">
                                        <input type="hidden" id="setStoreLogoVal" value="">
                                        <button type="button" id="btnRemoveLogo" class="btn btn-outline-danger btn-sm py-0 px-2" style="font-size: 11px; display: none;">Remove Logo</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <h6 class="fw-bold border-bottom pb-1 mb-2 text-primary">POS Operations & Automation</h6>
                        <div class="row g-2 mb-3">
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="setResetOnConfirm" value="1">
                                    <label class="form-check-label" for="setResetOnConfirm">Reset form on Confirm Order</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="setDirectPrint" value="1">
                                    <label class="form-check-label" for="setDirectPrint">Direct print on Confirm Order</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="setEnableLowStock" value="1">
                                    <label class="form-check-label" for="setEnableLowStock">Enable low stock warnings</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label mb-0 fw-semibold">Low Stock Warning Limit</label>
                                <input type="number" id="setLowStockLimit" class="form-control form-control-desktop" value="5" min="1">
                            </div>
                        </div>

                        <h6 class="fw-bold border-bottom pb-1 mb-2 text-primary">Delivery & Logistics Partner</h6>
                        <div class="row g-2 mb-3">
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="setEnableDelivery" value="1">
                                    <label class="form-check-label" for="setEnableDelivery">Enable Delivery Options</label>
                                </div>
                                <div class="mt-2">
                                    <label class="form-label mb-0 fw-semibold">Default Delivery Partner</label>
                                    <select id="setDeliveryPartner" class="form-select form-select-desktop">
                                        <option value="Prompt XP">Prompt XP</option>
                                        <option value="Fargo">Fargo</option>
                                        <option value="Pronto">Pronto</option>
                                        <option value="Domex">Domex</option>
                                        <option value="SL Post">SL Post</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label mb-0 fw-semibold">Custom Parcel Description</label>
                                <textarea id="setCustomParcelDesc" class="form-control form-control-desktop" rows="2" placeholder="Parcel note on shipping labels"></textarea>
                            </div>
                        </div>

                        <!-- Courier Partner Rates Configuration Matrix -->
                        <h6 class="fw-bold border-bottom pb-1 mb-2 text-primary">Courier Partner Delivery Rates (Rs.)</h6>
                        <div class="table-responsive mb-3 border rounded">
                            <table class="table table-sm pos-table table-bordered align-middle mb-0" id="tableCourierRates">
                                <thead class="table-light">
                                    <tr>
                                        <th style="width: 40%;">Courier Partner</th>
                                        <th style="width: 30%;">First 1 KG Rate (Rs.)</th>
                                        <th style="width: 30%;">Each Extra 1 KG Rate (Rs.)</th>
                                    </tr>
                                </thead>
                                <tbody id="tbodyCourierRates">
                                    <!-- Dynamic Courier Rate Rows -->
                                </tbody>
                            </table>
                        </div>

                        <h6 class="fw-bold border-bottom pb-1 mb-2 text-primary">Printer Devices Configuration</h6>
                        <div class="row g-2 mb-3">
                            <div class="col-md-6">
                                <label class="form-label mb-0 fw-semibold">Invoice Printer</label>
                                <input type="text" id="setInvoicePrinter" class="form-control form-control-desktop" value="Standard PDF Printer">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label mb-0 fw-semibold">Receipt Thermal Printer</label>
                                <input type="text" id="setReceiptPrinter" class="form-control form-control-desktop" value="POS-80 Thermal Printer">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label mb-0 fw-semibold">Parcel Label Printer</label>
                                <input type="text" id="setParcelPrinter" class="form-control form-control-desktop" value="Label Printer 4x6">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label mb-0 fw-semibold">Barcode Printer</label>
                                <input type="text" id="setBarcodePrinter" class="form-control form-control-desktop" value="Barcode Label Printer">
                            </div>
                        </div>

                        <h6 class="fw-bold border-bottom pb-1 mb-2 text-primary">Default Payment Status & Security</h6>
                        <div class="row g-2">
                            <div class="col-md-6">
                                <label class="form-label mb-0 fw-semibold d-block">Default Order Status</label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="setDefaultStatus" id="defStatusPaid" value="Paid">
                                    <label class="form-check-label" for="defStatusPaid">Paid</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="setDefaultStatus" id="defStatusPending" value="Pending">
                                    <label class="form-check-label" for="defStatusPending">Pending</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="setDefaultStatus" id="defStatusPartial" value="Partial Paid">
                                    <label class="form-check-label" for="defStatusPartial">Partial</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check mt-3">
                                    <input class="form-check-input" type="checkbox" id="setRestrictedMode" value="1">
                                    <label class="form-check-label fw-bold text-danger" for="setRestrictedMode">Enable Restricted Mode</label>
                                </div>
                            </div>
                        </div>
                    </form>
                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-desktop-secondary px-4" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="btnSaveSettings" class="btn btn-desktop-primary px-4">Save Settings</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL 8: INFO MODAL -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalInfo" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center">
                    <div class="modal-title fw-bold text-dark">About Zenith OMS</div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4 text-center">
                    <i class="fa-solid fa-desktop fa-4x text-primary mb-3"></i>
                    <h5 class="fw-bold mb-1 text-dark">Zenith OMS</h5>
                    <p class="text-muted mb-3">Order Management & Point of Sale System</p>
                    
                    <div class="border rounded p-3 text-start bg-light mb-3" style="font-size:0.875rem;">
                        <div class="d-flex justify-content-between py-1 border-bottom"><span>Application Status:</span><span class="text-success fw-bold"><i class="fa-solid fa-circle-check me-1"></i> Active & Connected</span></div>
                        <div class="d-flex justify-content-between py-1 border-bottom"><span>System Version:</span><span class="fw-semibold text-dark">v2.5 Professional Edition</span></div>
                        <div class="d-flex justify-content-between py-1"><span>License Status:</span><span class="badge bg-primary">Registered</span></div>
                    </div>

                    <div class="p-2 bg-white border rounded text-secondary small mb-3">
                        <div><strong class="text-dark">Quick Keyboard Shortcuts:</strong></div>
                        <div class="mt-1">Press <strong>F2</strong> to Add Item &nbsp;|&nbsp; Press <strong>F4</strong> to Confirm Order &nbsp;|&nbsp; <strong>Esc</strong> to Close Modal</div>
                    </div>

                    <button type="button" class="btn btn-desktop-primary w-100 py-2 fw-bold" id="btnOpenCloudUpdaterFromInfo">
                        <i class="fa-solid fa-cloud-arrow-down me-1"></i> Check Cloud Code Updates
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL: CLOUD SYSTEM CODE UPDATER MODAL -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalCloudUpdate" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center bg-primary text-white py-2 px-3">
                    <div class="modal-title fw-bold text-white"><i class="fa-solid fa-cloud-arrow-down me-2"></i> Zenith OMS 1-Click Cloud Code Updater</div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="card bg-light border-light mb-4">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <div>
                                <h6 class="fw-bold text-dark mb-1"><i class="fa-solid fa-code-branch me-2 text-primary"></i> Installed Version: <span class="badge bg-primary fs-6">v2.5.0</span></h6>
                                <p class="text-muted small mb-0">Connect to Cloud Update Server to download the latest features and system enhancements.</p>
                            </div>
                            <button type="button" class="btn btn-desktop-primary fw-bold px-3 py-2" id="btnTriggerCheckUpdate">
                                <i class="fa-solid fa-arrows-rotate me-1"></i> Check Cloud Updates
                            </button>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold text-secondary">Cloud Update Server Endpoint URL:</label>
                        <div class="input-group">
                            <input type="text" id="inputUpdateServerUrl" class="form-control form-control-desktop font-monospace" value="https://raw.githubusercontent.com/zencoresystems/zenith-oms-updates/main/version.json">
                            <button class="btn btn-desktop-secondary" type="button" id="btnResetServerUrl">Reset Default</button>
                        </div>
                    </div>

                    <div id="cloudUpdateResultCard" class="card border-info" style="display: none;">
                        <div class="card-header bg-info bg-opacity-10 text-dark fw-bold py-2 d-flex align-items-center justify-content-between">
                            <span><i class="fa-solid fa-circle-info me-2 text-info"></i> Update Package Status</span>
                            <span class="badge bg-success" id="lblLatestVersionBadge">v2.6.0 Available</span>
                        </div>
                        <div class="card-body">
                            <div class="mb-2"><strong>Release Date:</strong> <span id="lblUpdateReleaseDate">----</span></div>
                            <div class="mb-3">
                                <strong>Release Notes & Changelog:</strong>
                                <div class="bg-light p-3 border rounded font-monospace small text-dark mt-1" id="lblUpdateChangelog" style="white-space: pre-wrap; max-height: 180px; overflow-y: auto;">
                                    - New feature updates and stability patches.
                                </div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="small text-muted" id="lblUpdateDownloadUrl">URL: ----</span>
                                <button type="button" class="btn btn-success fw-bold px-4 py-2" id="btnApplyUpdateSubmit" style="display: none;">
                                    <i class="fa-solid fa-download me-2"></i> Download & Install Cloud Update Now
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL 9: PRINT PREVIEW MODAL -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalPrintPreview" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center">
                    <div class="modal-title" id="printModalTitle">Print Preview</div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-3 bg-secondary bg-opacity-10" id="printModalBody">
                    <!-- Dynamic Printable Content -->
                </div>
                <div class="modal-footer bg-light py-2">
                    <button type="button" class="btn btn-desktop-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                    <button type="button" id="btnTriggerPrintAction" class="btn btn-desktop-primary btn-sm"><i class="fa-solid fa-print me-1"></i> Print Document</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- FULL SCREEN LICENSE LOCK OVERLAY (Offline Machine-Bound Expiry Lock) -->
    <!-- ================================================================= -->
    <div id="licenseLockOverlay" style="display: none; position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background-color: rgba(15, 23, 42, 0.98); z-index: 9999999; color: #ffffff; overflow-y: auto; padding: 2rem 1rem;">
        <div class="container" style="max-width: 680px; margin-top: 3vh;">
            <div class="card bg-dark text-white border-danger shadow-lg">
                <div class="card-header bg-danger text-white d-flex align-items-center justify-content-between py-3">
                    <h5 class="mb-0 fw-bold"><i class="fa-solid fa-lock me-2"></i> ZENITH OMS - SYSTEM LICENSE LOCKED</h5>
                    <span class="badge bg-white text-danger fw-bold fs-6" id="lockStatusBadge">EXPIRED</span>
                </div>
                <div class="card-body p-4">
                    <div class="alert alert-warning text-dark border-0 mb-4" id="lockMessageAlert">
                        <i class="fa-solid fa-triangle-exclamation me-2 fs-5"></i>
                        <strong id="lockMessageText">System license has expired or is invalid. Access to Zenith POS is suspended.</strong>
                    </div>

                    <div class="card bg-secondary bg-opacity-25 border-secondary mb-4">
                        <div class="card-header bg-secondary bg-opacity-50 text-white fw-bold py-2">
                            <i class="fa-solid fa-microchip me-2 text-warning"></i> System Hardware & License Diagnostics
                        </div>
                        <div class="card-body font-monospace small text-light py-3">
                            <div class="row mb-2 align-items-center">
                                <div class="col-sm-5 text-secondary">Bound Machine ID:</div>
                                <div class="col-sm-7 fw-bold text-warning d-flex align-items-center justify-content-between">
                                    <span id="lockMachineIdDisplay">----</span>
                                    <button type="button" class="btn btn-xs btn-outline-warning py-0 px-2 ms-2" id="btnCopyLockMachineId" title="Copy Machine ID">
                                        <i class="fa-solid fa-copy"></i> Copy
                                    </button>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5 text-secondary">System Date:</div>
                                <div class="col-sm-7 fw-bold text-info" id="lockSystemDateDisplay">----</div>
                            </div>
                            <div class="row">
                                <div class="col-sm-5 text-secondary">Activation Code:</div>
                                <div class="col-sm-7 text-white text-break fw-bold" id="lockActivationCodeDisplay">----</div>
                            </div>
                        </div>
                    </div>

                    <!-- Developer License Activation Panel -->
                    <div class="card border-primary bg-dark">
                        <div class="card-header bg-primary text-white fw-bold py-2">
                            <i class="fa-solid fa-key me-2"></i> Developer License Activation & Renewal
                        </div>
                        <div class="card-body py-3">
                            <p class="small text-muted mb-3">
                                Enter developer password and activation code to activate system license.
                            </p>
                            <form id="formActivateLicenseLock">
                                <div class="mb-3">
                                    <label class="form-label fw-bold text-light">Password</label>
                                    <input type="password" id="inputLockDevPassword" class="form-control bg-dark text-white border-secondary" placeholder="Enter Password" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold text-light">Activation Code</label>
                                    <input type="text" id="inputLockExpiryDate" class="form-control bg-dark text-white border-secondary font-monospace" placeholder="Enter Activation Code" required>
                                </div>
                                <button type="submit" class="btn btn-primary w-100 fw-bold py-2" id="btnLockActivateSubmit">
                                    <i class="fa-solid fa-shield-check me-2"></i> Activate System
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================= -->
    <!-- MODAL 10: DEVELOPER LICENSE MANAGEMENT MODAL -->
    <!-- ================================================================= -->
    <div class="modal fade modal-desktop" id="modalLicense" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center py-2 px-3 bg-primary text-white">
                    <div class="modal-title fw-bold text-white"><i class="fa-solid fa-shield-halved me-2"></i> Zenith OMS System License Management</div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <div class="card h-100 border-light bg-light">
                                <div class="card-body">
                                    <h6 class="fw-bold text-dark mb-3"><i class="fa-solid fa-circle-info text-primary me-2"></i> Current Status</h6>
                                    <div class="mb-2"><span class="text-secondary">License State:</span> <span class="badge bg-success fw-bold ms-2" id="modalLicStatusBadge">ACTIVE</span></div>
                                    <div class="mb-2"><span class="text-secondary">Machine ID:</span> <strong class="text-dark font-monospace small ms-2" id="modalLicMachineId">----</strong></div>
                                    <div class="mb-2"><span class="text-secondary">System Date:</span> <strong class="text-dark ms-2" id="modalLicSystemDate">----</strong></div>
                                    <div><span class="text-secondary">Activation Code:</span> <div class="font-monospace small text-break fw-bold text-dark mt-1" id="modalLicActivationCode">----</div></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card h-100 border-primary">
                                <div class="card-header bg-primary text-white py-2 fw-bold">
                                    <i class="fa-solid fa-key me-2"></i> System Activation
                                </div>
                                <div class="card-body">
                                    <form id="formActivateLicenseModal">
                                        <div class="mb-3">
                                            <label class="form-label fw-semibold text-secondary">Password:</label>
                                            <input type="password" id="inputModalDevPassword" class="form-control form-control-desktop" placeholder="Enter Password" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label fw-semibold text-secondary">Activation Code:</label>
                                            <input type="text" id="inputModalExpiryDate" class="form-control form-control-desktop font-monospace" placeholder="Enter Activation Code" required>
                                        </div>
                                        <button type="submit" class="btn btn-desktop-primary w-100 py-2 fw-bold">
                                            <i class="fa-solid fa-floppy-disk me-1"></i> Activate System
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Local Offline Bootstrap JS Bundle & SweetAlert2 JS -->
    <script src="<?php echo base_url('bootstrap.bundle.min.js'); ?>"></script>
    <script src="<?php echo base_url('sweetalert2.all.min.js'); ?>"></script>

    <!-- Vanilla JavaScript POS Application Engine -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {

            window.POS_LICENSE = <?php echo json_encode(isset($license) ? $license : array()); ?>;

            function renderLicenseUI(lic) {
                if (!lic) return;

                const statusBadge = document.getElementById('lockStatusBadge');
                if (statusBadge) statusBadge.innerText = lic.status || 'LOCKED';

                const msgText = document.getElementById('lockMessageText');
                if (msgText) msgText.innerText = lic.message || 'System access is locked.';

                const machineIdDisp = document.getElementById('lockMachineIdDisplay');
                if (machineIdDisp) machineIdDisp.innerText = lic.machine_id || '----';

                const sysDateDisp = document.getElementById('lockSystemDateDisplay');
                if (sysDateDisp) sysDateDisp.innerText = lic.system_date || '----';

                const lockActCodeDisp = document.getElementById('lockActivationCodeDisplay');
                if (lockActCodeDisp) lockActCodeDisp.innerText = lic.expiry_md5_slash || lic.expiry_md5_dash || '----';

                const modalBadge = document.getElementById('modalLicStatusBadge');
                if (modalBadge) {
                    modalBadge.innerText = lic.status || 'UNKNOWN';
                    modalBadge.className = 'badge ' + (lic.valid ? 'bg-success' : 'bg-danger') + ' fw-bold ms-2';
                }

                const modalMachineId = document.getElementById('modalLicMachineId');
                if (modalMachineId) modalMachineId.innerText = lic.machine_id || '----';

                const modalSysDate = document.getElementById('modalLicSystemDate');
                if (modalSysDate) modalSysDate.innerText = lic.system_date || '----';

                const modalActCodeDisp = document.getElementById('modalLicActivationCode');
                if (modalActCodeDisp) modalActCodeDisp.innerText = lic.expiry_md5_slash || lic.expiry_md5_dash || '----';

                const lockOverlay = document.getElementById('licenseLockOverlay');
                if (lockOverlay) {
                    if (!lic.valid) {
                        lockOverlay.style.display = 'block';
                    } else {
                        lockOverlay.style.display = 'none';
                    }
                }
            }

            renderLicenseUI(window.POS_LICENSE);

            // SweetAlert2 Offline Helper
            function SwalNotify(message, type = 'info', title = null) {
                let swalIcon = type;
                if (type === 'danger') swalIcon = 'error';
                let defaultTitle = 'Notice';
                if (type === 'warning') defaultTitle = 'Warning';
                if (type === 'success') defaultTitle = 'Success';
                if (type === 'error') defaultTitle = 'Error';

                Swal.fire({
                    title: title || defaultTitle,
                    text: message,
                    icon: swalIcon,
                    confirmButtonColor: '#2196f3'
                });
            }

            // Resilient Modal Helper
            // Resilient Modal Helpers
            function getModalInstance(id) {
                const el = document.getElementById(id);
                if (!el) return null;
                if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                    return bootstrap.Modal.getInstance(el) || bootstrap.Modal.getOrCreateInstance(el);
                }
                return null;
            }

            function showModal(id) {
                const el = document.getElementById(id);
                if (!el) return;
                if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                    const instance = bootstrap.Modal.getOrCreateInstance(el);
                    instance.show();
                } else {
                    el.classList.add('show');
                    el.style.display = 'block';
                    document.body.classList.add('modal-open');
                    let backdrop = document.querySelector('.modal-backdrop');
                    if (!backdrop) {
                        backdrop = document.createElement('div');
                        backdrop.className = 'modal-backdrop fade show';
                        document.body.appendChild(backdrop);
                    }
                }
            }

            function hideModal(id) {
                const el = document.getElementById(id);
                if (!el) return;
                if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                    const instance = bootstrap.Modal.getInstance(el);
                    if (instance) {
                        try { instance.hide(); } catch(e){}
                    }
                }
                el.classList.remove('show');
                el.style.display = 'none';
                document.body.classList.remove('modal-open');
                document.querySelectorAll('.modal-backdrop').forEach(b => b.remove());
            }

            // Close buttons listener for fallback modal handler
            document.querySelectorAll('[data-bs-dismiss="modal"], .btn-close').forEach(btn => {
                btn.addEventListener('click', function() {
                    const modalEl = this.closest('.modal');
                    if (modalEl) {
                        hideModal(modalEl.id);
                    }
                });
            });

            // Currency Formatter Helper
            function formatRs(num, decimals = 0) {
                if (num === null || num === undefined || isNaN(num)) return 'Rs. 0';
                const n = parseFloat(num);
                if (decimals === 0) {
                    return 'Rs. ' + Math.round(n).toLocaleString('en-US');
                }
                return 'Rs. ' + n.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
            }

            // Global State Management
            const state = {
                settings: <?php echo json_encode($settings); ?>,
                products: <?php echo json_encode($products); ?>,
                customers: <?php echo json_encode($customers); ?>,
                courier_rates: <?php echo json_encode($courier_rates ?? array()); ?>,
                cart: [],
                selectedCartIndex: null,
                selectedProdForPOS: null,
                selectedOrderRow: null,
                selectedInvoiceRow: null,
                selectedDraftRow: null,
                selectedCustomerRow: null,
                selectedPmRow: null,
                activeOrderNo: 'ORD-NEW',
                activeDraftId: null,
                activeCustomer: { id: 1, name: 'Visit Oder', contacts: '', contact_2: '', email: '', address: '' },
                activeWaybillId: '',
                activeDeliveryService: 'Prompt XP',
                activePackageWeight: 0,
                activeDeliveryCharge: 0,
                activeStatus: 'Paid',
                activePaidAmount: 0
            };

            // Base API Url
            const baseUrl = '<?php echo base_url(); ?>index.php/pos/';

            // Initializer
            function initPOS() {
                populateCustomerDropdown();
                renderCartTable();
                recalculatePOS();
                fetchInitialData();
                bindNewModalEvents();
            }

            function fetchInitialData() {
                fetch(baseUrl + 'get_initial_data')
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'license_error' || (data.license && !data.license.valid)) {
                            renderLicenseUI(data.license);
                            return;
                        }
                        if (data.status === 'success') {
                            if (data.license) {
                                renderLicenseUI(data.license);
                            }
                            state.settings = data.settings;
                            state.products = data.products;
                            state.customers = data.customers;
                            state.courier_rates = data.courier_rates || [];
                            state.activeOrderNo = data.next_order_no;
                            document.getElementById('lblActiveOrderNo').innerText = data.next_order_no;
                            populateCustomerDropdown();
                        }
                    })
                    .catch(err => console.error('Error fetching initial data:', err));
            }

            // License Activation & Lock Handlers
            function handleLicenseActivation(passwordId, expiryId) {
                const password = document.getElementById(passwordId).value;
                const expiry = document.getElementById(expiryId).value;

                if (!password) {
                    SwalNotify('Developer Password is required.', 'error');
                    return;
                }
                if (!expiry) {
                    SwalNotify('Expiration Date is required.', 'error');
                    return;
                }

                const formData = new FormData();
                formData.append('dev_password', password);
                formData.append('expiry_date', expiry);

                fetch(baseUrl + 'activate_license', {
                    method: 'POST',
                    body: formData
                })
                .then(r => r.json())
                .then(res => {
                    if (res.status === 'success') {
                        Swal.fire({
                            title: 'License Activated!',
                            text: res.message,
                            icon: 'success',
                            confirmButtonColor: '#2196f3'
                        }).then(() => {
                            window.location.reload();
                        });
                    } else {
                        SwalNotify(res.message || 'License activation failed.', 'error');
                    }
                })
                .catch(err => {
                    console.error(err);
                    SwalNotify('An error occurred during license activation.', 'error');
                });
            }

            const formLock = document.getElementById('formActivateLicenseLock');
            if (formLock) {
                formLock.addEventListener('submit', function(e) {
                    e.preventDefault();
                    handleLicenseActivation('inputLockDevPassword', 'inputLockExpiryDate');
                });
            }

            const formModal = document.getElementById('formActivateLicenseModal');
            if (formModal) {
                formModal.addEventListener('submit', function(e) {
                    e.preventDefault();
                    handleLicenseActivation('inputModalDevPassword', 'inputModalExpiryDate');
                });
            }

            const btnCopyId = document.getElementById('btnCopyLockMachineId');
            if (btnCopyId) {
                btnCopyId.addEventListener('click', function() {
                    const text = document.getElementById('lockMachineIdDisplay').innerText;
                    if (text && text !== '----') {
                        navigator.clipboard.writeText(text).then(() => {
                            SwalNotify('Machine ID copied to clipboard!', 'success');
                        });
                    }
                });
            }

            const btnNavLicense = document.getElementById('btnNavLicense');
            if (btnNavLicense) {
                btnNavLicense.addEventListener('click', function() {
                    showModal('modalLicense');
                });
            }

            // Cloud Code Updater Event Handlers
            const btnOpenCloudUpdater = document.getElementById('btnOpenCloudUpdaterFromInfo');
            if (btnOpenCloudUpdater) {
                btnOpenCloudUpdater.addEventListener('click', function() {
                    hideModal('modalInfo');
                    showModal('modalCloudUpdate');
                });
            }

            const btnResetServerUrl = document.getElementById('btnResetServerUrl');
            if (btnResetServerUrl) {
                btnResetServerUrl.addEventListener('click', function() {
                    document.getElementById('inputUpdateServerUrl').value = 'https://raw.githubusercontent.com/zencoresystems/zenith-oms-updates/main/version.json';
                });
            }

            const btnTriggerCheckUpdate = document.getElementById('btnTriggerCheckUpdate');
            if (btnTriggerCheckUpdate) {
                btnTriggerCheckUpdate.addEventListener('click', function() {
                    const serverUrl = document.getElementById('inputUpdateServerUrl').value;
                    const btn = this;
                    btn.disabled = true;
                    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-1"></i> Checking...';

                    fetch(baseUrl + 'check_cloud_update?update_server_url=' + encodeURIComponent(serverUrl))
                        .then(res => res.json())
                        .then(data => {
                            btn.disabled = false;
                            btn.innerHTML = '<i class="fa-solid fa-arrows-rotate me-1"></i> Check Cloud Updates';

                            const card = document.getElementById('cloudUpdateResultCard');
                            card.style.display = 'block';

                            if (data.status === 'success') {
                                document.getElementById('lblLatestVersionBadge').innerText = data.update_available ? ('New Version v' + data.latest_version) : 'Up To Date';
                                document.getElementById('lblLatestVersionBadge').className = 'badge ' + (data.update_available ? 'bg-success' : 'bg-secondary');
                                document.getElementById('lblUpdateReleaseDate').innerText = data.release_date || '-';
                                document.getElementById('lblUpdateChangelog').innerText = data.changelog || 'No release notes provided.';
                                document.getElementById('lblUpdateDownloadUrl').innerText = 'Package: ' + (data.download_url || 'N/A');

                                const btnInstall = document.getElementById('btnApplyUpdateSubmit');
                                if (data.update_available && data.download_url) {
                                    btnInstall.style.display = 'inline-block';
                                    btnInstall.setAttribute('data-url', data.download_url);
                                    btnInstall.setAttribute('data-version', data.latest_version);
                                } else {
                                    btnInstall.style.display = 'none';
                                }

                                SwalNotify(data.message, data.update_available ? 'success' : 'info');
                            } else {
                                SwalNotify(data.message || 'Could not check cloud update server.', data.status || 'warning');
                            }
                        })
                        .catch(err => {
                            btn.disabled = false;
                            btn.innerHTML = '<i class="fa-solid fa-arrows-rotate me-1"></i> Check Cloud Updates';
                            SwalNotify('Error connecting to cloud update endpoint.', 'error');
                        });
                });
            }

            const btnApplyUpdateSubmit = document.getElementById('btnApplyUpdateSubmit');
            if (btnApplyUpdateSubmit) {
                btnApplyUpdateSubmit.addEventListener('click', function() {
                    const downloadUrl = this.getAttribute('data-url');
                    const targetVersion = this.getAttribute('data-version');

                    if (!downloadUrl) {
                        SwalNotify('Download URL not found.', 'error');
                        return;
                    }

                    Swal.fire({
                        title: 'Install Cloud Update?',
                        text: `Download and apply Zenith OMS update to v${targetVersion}? System code files will be updated automatically.`,
                        icon: 'question',
                        showCancelButton: true,
                        confirmButtonColor: '#198754',
                        cancelButtonColor: '#6c757d',
                        confirmButtonText: 'Yes, Install Update'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            Swal.fire({
                                title: 'Downloading & Updating System...',
                                text: 'Please wait while update package is unzipping and replacing application code.',
                                allowOutsideClick: false,
                                didOpen: () => { Swal.showLoading(); }
                            });

                            const formData = new FormData();
                            formData.append('download_url', downloadUrl);
                            formData.append('target_version', targetVersion);

                            fetch(baseUrl + 'apply_cloud_update', {
                                method: 'POST',
                                body: formData
                            })
                            .then(res => res.json())
                            .then(resData => {
                                if (resData.status === 'success') {
                                    Swal.fire({
                                        title: 'Update Complete!',
                                        text: resData.message,
                                        icon: 'success',
                                        confirmButtonText: 'Reload POS'
                                    }).then(() => {
                                        window.location.reload();
                                    });
                                } else {
                                    SwalNotify(resData.message || 'Failed to apply update package.', 'error');
                                }
                            })
                            .catch(err => {
                                SwalNotify('An error occurred during Cloud Update download.', 'error');
                            });
                        }
                    });
                });
            }

            function populateCustomerDropdown() {
                const sel = document.getElementById('selectCustomer');
                if (!sel) return;
                sel.innerHTML = '';
                state.customers.forEach(c => {
                    const opt = document.createElement('option');
                    opt.value = c.id;
                    opt.innerText = c.name;
                    sel.appendChild(opt);
                });

                if (state.activeCustomer && state.activeCustomer.name) {
                    document.getElementById('lblActiveCustomerName').innerText = state.activeCustomer.name;
                }
            }

            // ==========================================
            // POS CALCULATIONS ENGINE
            // ==========================================
            function updateStatusButtonsUI(status, paidAmount) {
                const lbl = document.getElementById('lblActiveStatusText');
                const btns = document.querySelectorAll('.btn-status-toggle');

                btns.forEach(btn => {
                    const s = btn.getAttribute('data-status');
                    btn.classList.remove('active', 'btn-warning', 'btn-success', 'btn-primary', 'text-white', 'text-dark');
                    
                    if (s === 'Pending') {
                        btn.classList.add('btn-outline-warning');
                    } else if (s === 'Paid') {
                        btn.classList.add('btn-outline-success');
                    } else if (s === 'Partial Paid') {
                        btn.classList.add('btn-outline-primary');
                    }

                    if (s === status) {
                        btn.classList.add('active');
                        if (s === 'Pending') {
                            btn.classList.remove('btn-outline-warning');
                            btn.classList.add('btn-warning', 'text-dark');
                        } else if (s === 'Paid') {
                            btn.classList.remove('btn-outline-success');
                            btn.classList.add('btn-success', 'text-white');
                        } else if (s === 'Partial Paid') {
                            btn.classList.remove('btn-outline-primary');
                            btn.classList.add('btn-primary', 'text-white');
                        }
                    }
                });

                if (lbl) {
                    lbl.className = 'badge px-2 py-1 fs-6 fw-bold ';
                    if (status === 'Pending') {
                        lbl.classList.add('bg-warning', 'text-dark');
                        lbl.innerText = 'Pending (Unpaid)';
                    } else if (status === 'Paid') {
                        lbl.classList.add('bg-success', 'text-white');
                        lbl.innerText = 'Paid';
                    } else if (status === 'Partial Paid') {
                        lbl.classList.add('bg-primary', 'text-white');
                        lbl.innerText = `Partial (${formatRs(paidAmount, 0)})`;
                    }
                }
            }

            function recalculatePOS() {
                let totalItems = 0;
                let subTotal = 0.00;
                let totalCost = 0.00;
                let totalDiscount = 0.00;

                state.cart.forEach(item => {
                    const qty = parseInt(item.quantity) || 1;
                    const price = parseFloat(item.unit_price) || 0;
                    const cost = parseFloat(item.cost) || 0;
                    const disc = parseFloat(item.discount) || 0;

                    totalItems += qty;
                    subTotal += (qty * price);
                    totalDiscount += (qty * disc);
                    totalCost += (qty * cost);
                });

                const deliveryCharge = parseFloat(state.activeDeliveryCharge) || 0.00;
                const grandTotal = subTotal + deliveryCharge - totalDiscount;
                const netSales = grandTotal - deliveryCharge;
                const profit = netSales - totalCost;
                const profitMargin = grandTotal > 0 ? (profit / grandTotal) * 100 : 0.00;

                // Calculate Paid & Balance based on activeStatus
                let paidAmount = 0.00;
                let balance = 0.00;

                if (state.activeStatus === 'Paid') {
                    paidAmount = grandTotal;
                    balance = 0.00;
                    state.activePaidAmount = paidAmount;
                } else if (state.activeStatus === 'Pending') {
                    paidAmount = 0.00;
                    balance = grandTotal;
                    state.activePaidAmount = paidAmount;
                } else if (state.activeStatus === 'Partial Paid') {
                    paidAmount = parseFloat(state.activePaidAmount);
                    if (isNaN(paidAmount) || paidAmount < 0) {
                        paidAmount = Math.round(grandTotal / 2);
                        state.activePaidAmount = paidAmount;
                    }
                    if (paidAmount > grandTotal) {
                        paidAmount = grandTotal;
                        state.activePaidAmount = paidAmount;
                    }
                    balance = grandTotal - paidAmount;
                }

                // Update Status Badge and Toggle Buttons Visuals
                updateStatusButtonsUI(state.activeStatus, paidAmount);

                // Update UI Display Labels
                document.getElementById('calcTotalItems').innerText = totalItems;
                document.getElementById('lblDeliveryChargeVal').innerText = formatRs(deliveryCharge, 0);
                document.getElementById('calcSubTotal').innerText = formatRs(subTotal, 0);
                document.getElementById('calcDiscountSummary').innerText = formatRs(totalDiscount, 0);
                document.getElementById('calcGrandTotal').innerText = formatRs(grandTotal, 0);
                if (document.getElementById('calcPaidAmountDisplay')) {
                    document.getElementById('calcPaidAmountDisplay').innerText = formatRs(paidAmount, 0);
                }
                document.getElementById('calcBalance').innerText = formatRs(balance, 0);
                document.getElementById('calcDeliveryCharge').value = deliveryCharge;
                document.getElementById('inputPaymentStatusVal').value = state.activeStatus;

                // Update Footer Bar Summary
                document.getElementById('footSummaryItems').innerText = totalItems;
                document.getElementById('footSummarySubtotal').innerText = formatRs(subTotal, 0);
                document.getElementById('footSummaryDelivery').innerText = formatRs(deliveryCharge, 0);
                document.getElementById('footSummaryDiscount').innerText = formatRs(totalDiscount, 0);
                document.getElementById('footSummaryGrandTotal').innerText = formatRs(grandTotal, 0);
                document.getElementById('footSummaryProfit').innerText = formatRs(profit, 0);
            }

            // Global Dynamic Delivery Charge Calculation Engine
            function calculateDeliveryChargeFromRates() {
                const courierSelect = document.getElementById('deliveryServiceSelect');
                const weightInput = document.getElementById('inputPackageWeight');
                const chargeInput = document.getElementById('inputDeliveryChargeModal');
                const chkFree = document.getElementById('chkFreeDelivery');

                if (!courierSelect || !weightInput || !chargeInput) return;

                if (chkFree && chkFree.checked) {
                    chargeInput.value = 0;
                    chargeInput.disabled = true;
                    return;
                }

                chargeInput.disabled = false;

                const courierName = courierSelect.value || 'Prompt XP';
                let weightVal = parseFloat(weightInput.value);
                if (isNaN(weightVal) || weightVal <= 0) {
                    weightVal = 0;
                }

                const defaultRatesMap = {
                    'Prompt XP': { first: 500, add: 150 },
                    'Fargo': { first: 450, add: 120 },
                    'Pronto': { first: 400, add: 100 },
                    'Domex': { first: 480, add: 130 },
                    'SL Post': { first: 250, add: 80 }
                };

                let firstKg = 500;
                let addKg = 150;

                if (state.courier_rates && Array.isArray(state.courier_rates) && state.courier_rates.length > 0) {
                    const found = state.courier_rates.find(r => r.courier_name && r.courier_name.trim().toLowerCase() === courierName.trim().toLowerCase());
                    if (found) {
                        firstKg = parseFloat(found.first_kg_rate) || 500;
                        addKg = parseFloat(found.additional_kg_rate) || 150;
                    } else if (defaultRatesMap[courierName]) {
                        firstKg = defaultRatesMap[courierName].first;
                        addKg = defaultRatesMap[courierName].add;
                    }
                } else if (defaultRatesMap[courierName]) {
                    firstKg = defaultRatesMap[courierName].first;
                    addKg = defaultRatesMap[courierName].add;
                }

                let totalCharge = 0;
                if (weightVal <= 0) {
                    totalCharge = 0;
                } else if (weightVal <= 1) {
                    totalCharge = firstKg;
                } else {
                    const extraKg = Math.ceil(weightVal - 1);
                    totalCharge = firstKg + (extraKg * addKg);
                }

                chargeInput.value = Math.round(totalCharge);
            }

            // Render Cart Table
            function renderCartTable() {
                const tbody = document.getElementById('tbodyCartItems');
                if (state.cart.length === 0) {
                    tbody.innerHTML = `
                        <tr id="trEmptyCartPlaceholder">
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="fa-solid fa-basket-shopping fa-3x mb-2 text-light-gray"></i>
                                <p class="mb-0 fw-bold">No content in table</p>
                                <small>Select or insert products from the left pane to build order</small>
                            </td>
                        </tr>
                    `;
                    return;
                }

                tbody.innerHTML = '';
                state.cart.forEach((item, index) => {
                    const tr = document.createElement('tr');
                    if (state.selectedCartIndex === index) {
                        tr.classList.add('selected-row');
                    }

                    const qty = parseInt(item.quantity) || 1;
                    const price = parseFloat(item.unit_price) || 0;
                    const disc = parseFloat(item.discount) || 0;
                    const total = (qty * price) - (qty * disc);

                    tr.innerHTML = `
                        <td class="fw-bold">${escapeHtml(item.product_code)}</td>
                        <td>${escapeHtml(item.description)}</td>
                        <td class="text-center">${qty}</td>
                        <td class="text-end">${formatRs(price, 0)}</td>
                        <td class="text-end fw-bold">${formatRs(total, 0)}</td>
                    `;

                    tr.addEventListener('click', function() {
                        if (state.selectedCartIndex === index) {
                            clearLeftProductInputs();
                            renderCartTable();
                        } else {
                            state.selectedCartIndex = index;
                            renderCartTable();
                            populateLeftFormWithItem(item);
                        }
                    });

                    tbody.appendChild(tr);
                });
            }

            function populateLeftFormWithItem(item) {
                document.getElementById('inputProdCode').value = item.product_code;
                document.getElementById('inputProdDesc').value = item.description;
                document.getElementById('inputProdQty').value = item.quantity;
                document.getElementById('inputProdCost').value = item.cost;
                document.getElementById('inputProdPrice').value = item.unit_price;
                document.getElementById('inputProdDiscount').value = item.discount || 0.00;

                const btn = document.getElementById('btnInsertCartItem');
                if (btn) {
                    btn.innerHTML = '<i class="fa-solid fa-pen-to-square me-1"></i> [Update] Item';
                    btn.classList.remove('btn-desktop-primary');
                    btn.classList.add('btn-warning');
                }
            }

            function clearLeftProductInputs() {
                document.getElementById('inputProdCode').value = '';
                document.getElementById('inputProdDesc').value = '';
                document.getElementById('inputProdQty').value = '1';
                document.getElementById('inputProdCost').value = '0.00';
                document.getElementById('inputProdPrice').value = '0.00';
                document.getElementById('inputProdDiscount').value = '0.00';
                document.getElementById('badgeStockStatus').innerText = 'Stock: -';
                state.selectedCartIndex = null;

                const btn = document.getElementById('btnInsertCartItem');
                if (btn) {
                    btn.innerHTML = '<i class="fa-solid fa-plus me-1"></i> [Insert] Item';
                    btn.classList.remove('btn-warning');
                    btn.classList.add('btn-desktop-primary');
                }
            }

            // Insert / Update Item in Cart
            document.getElementById('btnInsertCartItem').addEventListener('click', function() {
                const code = document.getElementById('inputProdCode').value.trim();
                const desc = document.getElementById('inputProdDesc').value.trim();
                const qty = parseInt(document.getElementById('inputProdQty').value) || 1;
                const cost = parseFloat(document.getElementById('inputProdCost').value) || 0.00;
                const price = parseFloat(document.getElementById('inputProdPrice').value) || 0.00;
                const discount = parseFloat(document.getElementById('inputProdDiscount').value) || 0.00;

                if (!code || !desc) {
                    SwalNotify('Please specify Product Code and Description.', 'warning');
                    return;
                }

                if (state.selectedCartIndex !== null && state.cart[state.selectedCartIndex]) {
                    // Update specific selected cart row
                    state.cart[state.selectedCartIndex] = {
                        product_id: state.selectedProdForPOS ? state.selectedProdForPOS.id : state.cart[state.selectedCartIndex].product_id,
                        product_code: code,
                        description: desc,
                        quantity: qty,
                        cost: cost,
                        unit_price: price,
                        discount: discount
                    };
                } else {
                    const existingIndex = state.cart.findIndex(i => i.product_code === code);
                    if (existingIndex >= 0) {
                        state.cart[existingIndex].quantity += qty;
                        state.cart[existingIndex].unit_price = price;
                        state.cart[existingIndex].discount = discount;
                    } else {
                        state.cart.push({
                            product_id: state.selectedProdForPOS ? state.selectedProdForPOS.id : null,
                            product_code: code,
                            description: desc,
                            quantity: qty,
                            cost: cost,
                            unit_price: price,
                            discount: discount
                        });
                    }
                }

                renderCartTable();
                recalculatePOS();
                clearLeftProductInputs();
            });

            // Delete Item from Cart
            document.getElementById('btnDeleteCartItem').addEventListener('click', function() {
                if (state.selectedCartIndex !== null && state.cart[state.selectedCartIndex]) {
                    state.cart.splice(state.selectedCartIndex, 1);
                    state.selectedCartIndex = null;
                    renderCartTable();
                    recalculatePOS();
                    clearLeftProductInputs();
                } else {
                    SwalNotify('Select an item from the cart table to delete.', 'warning');
                }
            });

            // ==========================================
            // NEW CUSTOMER & DELIVERY MODALS LOGIC
            // ==========================================
            function bindNewModalEvents() {
                // Enter Details Button -> Opens Customer Details Modal
                document.getElementById('btnEnterDetails').addEventListener('click', function() {
                    const c = state.activeCustomer || {};
                    document.getElementById('custDetailId').value = c.id || '';
                    document.getElementById('custDetailName').value = c.name || '';
                    document.getElementById('custDetailAddress').value = c.address || '';
                    document.getElementById('custDetailNearestCity').value = c.nearest_city || '';
                    document.getElementById('custDetailContact1').value = c.contacts || '';
                    document.getElementById('custDetailContact2').value = c.contact_2 || '';
                    document.getElementById('custDetailEmail').value = c.email || '';
                    showModal('modalCustomerDetails');
                });

                // Select Customer Button -> Opens Customers Selector Modal
                document.getElementById('btnSelectCustomer').addEventListener('click', function() {
                    showModal('modalCustomerSelector');
                    loadCustomerSelectorTable();
                });

                // Open Selector from Customer Details Modal
                document.getElementById('btnOpenCustomerSelectorFromModal').addEventListener('click', function() {
                    hideModal('modalCustomerDetails');
                    showModal('modalCustomerSelector');
                    loadCustomerSelectorTable();
                });

                // Save Customer Details Form
                document.getElementById('btnSaveCustomerDetails').addEventListener('click', function() {
                    const name = document.getElementById('custDetailName').value.trim();
                    if (!name) {
                        SwalNotify('Customer Name is required.', 'warning');
                        return;
                    }

                    const formData = new FormData();
                    formData.append('id', document.getElementById('custDetailId').value);
                    formData.append('name', name);
                    formData.append('address', document.getElementById('custDetailAddress').value);
                    formData.append('nearest_city', document.getElementById('custDetailNearestCity').value);
                    formData.append('contacts', document.getElementById('custDetailContact1').value);
                    formData.append('contact_2', document.getElementById('custDetailContact2').value);
                    formData.append('email', document.getElementById('custDetailEmail').value);

                    fetch(baseUrl + 'save_customer', { method: 'POST', body: formData })
                        .then(res => res.json())
                        .then(data => {
                            if (data.status === 'success') {
                                state.activeCustomer = data.customer;
                                document.getElementById('lblActiveCustomerName').innerText = data.customer.name;
                                document.getElementById('selectCustomer').value = data.customer.id;
                                document.getElementById('custContact').value = data.customer.contacts || '';
                                document.getElementById('custAddress').value = data.customer.address || '';
                                hideModal('modalCustomerDetails');
                            } else {
                                SwalNotify(data.message, 'error');
                            }
                        });
                });

                // Search in Customer Selector
                document.getElementById('custSelectorSearchInput').addEventListener('input', loadCustomerSelectorTable);

                document.getElementById('deliveryServiceSelect').addEventListener('change', calculateDeliveryChargeFromRates);
                document.getElementById('inputPackageWeight').addEventListener('input', calculateDeliveryChargeFromRates);
                document.getElementById('inputPackageWeight').addEventListener('change', calculateDeliveryChargeFromRates);
                document.getElementById('inputPackageWeight').addEventListener('keyup', calculateDeliveryChargeFromRates);

                // Modal Show Event Handler for Delivery Details
                const delModalEl = document.getElementById('modalDeliveryDetails');
                if (delModalEl) {
                    delModalEl.addEventListener('show.bs.modal', function() {
                        if (!state.activeDeliveryService) state.activeDeliveryService = 'Prompt XP';
                        const currentWeight = (state.activePackageWeight !== undefined && state.activePackageWeight !== null) ? state.activePackageWeight : 1;

                        document.getElementById('inputWaybillId').value = state.activeWaybillId || '';
                        document.getElementById('deliveryServiceSelect').value = state.activeDeliveryService;
                        document.getElementById('inputPackageWeight').value = currentWeight;
                        
                        const isFree = state.isFreeDelivery || false;
                        document.getElementById('chkFreeDelivery').checked = isFree;
                        
                        calculateDeliveryChargeFromRates();
                    });
                }

                // Delivery Charge Set Button -> Opens Delivery Details Modal
                document.getElementById('btnSetDeliveryCharge').addEventListener('click', function() {
                    if (!state.activeDeliveryService) state.activeDeliveryService = 'Prompt XP';
                    const currentWeight = (state.activePackageWeight !== undefined && state.activePackageWeight !== null) ? state.activePackageWeight : 1;

                    document.getElementById('inputWaybillId').value = state.activeWaybillId || '';
                    document.getElementById('deliveryServiceSelect').value = state.activeDeliveryService;
                    document.getElementById('inputPackageWeight').value = currentWeight;
                    document.getElementById('chkFreeDelivery').checked = state.isFreeDelivery || false;

                    calculateDeliveryChargeFromRates();
                    showModal('modalDeliveryDetails');
                });

                // Free Delivery Checkbox Handler
                document.getElementById('chkFreeDelivery').addEventListener('change', function() {
                    const modalChargeInput = document.getElementById('inputDeliveryChargeModal');
                    if (this.checked) {
                        modalChargeInput.value = 0;
                        modalChargeInput.disabled = true;
                    } else {
                        modalChargeInput.disabled = false;
                        calculateDeliveryChargeFromRates();
                    }
                });

                // Save Delivery Details
                document.getElementById('btnSaveDeliveryDetails').addEventListener('click', function() {
                    state.activeWaybillId = document.getElementById('inputWaybillId').value.trim();
                    state.activeDeliveryService = document.getElementById('deliveryServiceSelect').value;
                    const rawW = parseFloat(document.getElementById('inputPackageWeight').value);
                    state.activePackageWeight = isNaN(rawW) ? 0 : rawW;
                    
                    const isFree = document.getElementById('chkFreeDelivery').checked;
                    state.isFreeDelivery = isFree;

                    if (isFree) {
                        state.activeDeliveryCharge = 0;
                    } else {
                        const modalCharge = parseFloat(document.getElementById('inputDeliveryChargeModal').value);
                        state.activeDeliveryCharge = isNaN(modalCharge) ? 0 : modalCharge;
                    }

                    recalculatePOS();
                    hideModal('modalDeliveryDetails');
                });

                // Direct Click on Delivery Charge label for quick manual entry
                const lblDel = document.getElementById('lblDeliveryChargeVal');
                if (lblDel) {
                    lblDel.style.cursor = 'pointer';
                    lblDel.title = 'Click to enter custom delivery charge';
                    lblDel.addEventListener('click', function() {
                        Swal.fire({
                            title: 'Delivery Charge',
                            text: 'Enter Delivery Charge Amount (Rs.):',
                            input: 'number',
                            inputValue: state.activeDeliveryCharge || 0,
                            showCancelButton: true,
                            confirmButtonText: 'Apply',
                            confirmButtonColor: '#2196f3',
                            inputValidator: (val) => {
                                if (val === '' || isNaN(val) || parseFloat(val) < 0) {
                                    return 'Please enter a valid amount.';
                                }
                            }
                        }).then((result) => {
                            if (result.isConfirmed && result.value !== null) {
                                state.activeDeliveryCharge = parseFloat(result.value) || 0;
                                state.isFreeDelivery = (state.activeDeliveryCharge === 0);
                                recalculatePOS();
                            }
                        });
                    });
                }

                // Status Buttons Toggle
                document.querySelectorAll('.btn-status-toggle').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const selectedStatus = this.getAttribute('data-status');
                        state.activeStatus = selectedStatus;

                        if (selectedStatus === 'Partial Paid') {
                            const subTotalText = document.getElementById('calcSubTotal').innerText.replace(/Rs\.\s?|,/g, '');
                            const subTotal = parseFloat(subTotalText) || 0;
                            const delCharge = parseFloat(document.getElementById('calcDeliveryCharge').value) || 0;
                            const discText = document.getElementById('calcDiscountSummary').innerText.replace(/Rs\.\s?|,/g, '');
                            const discount = parseFloat(discText) || 0;
                            const grandTotal = subTotal + delCharge - discount;

                            const defaultPaid = (state.activePaidAmount && state.activePaidAmount > 0 && state.activePaidAmount < grandTotal) 
                                ? state.activePaidAmount 
                                : Math.round(grandTotal / 2);

                            Swal.fire({
                                title: 'Partial Payment',
                                html: `Total Order Amount: <b>${formatRs(grandTotal, 0)}</b><br><br>Enter Paid / Advance Amount (Rs.):`,
                                input: 'number',
                                inputValue: defaultPaid,
                                showCancelButton: true,
                                confirmButtonText: 'Save Payment',
                                confirmButtonColor: '#2196f3',
                                inputValidator: (val) => {
                                    if (val === '' || isNaN(val) || parseFloat(val) < 0) {
                                        return 'Please enter a valid amount.';
                                    }
                                }
                            }).then((result) => {
                                if (result.isConfirmed && result.value !== null) {
                                    let parsed = parseFloat(result.value);
                                    if (isNaN(parsed) || parsed < 0) parsed = 0;
                                    if (parsed > grandTotal) parsed = grandTotal;
                                    state.activePaidAmount = parsed;
                                } else if (!state.activePaidAmount) {
                                    state.activePaidAmount = Math.round(grandTotal / 2);
                                }
                                recalculatePOS();
                            });
                        } else {
                            recalculatePOS();
                        }
                    });
                });

                const paidDisp = document.getElementById('calcPaidAmountDisplay');
                if (paidDisp) {
                    paidDisp.style.cursor = 'pointer';
                    paidDisp.addEventListener('click', function() {
                        state.activeStatus = 'Partial Paid';
                        const subTotalText = document.getElementById('calcSubTotal').innerText.replace(/Rs\.\s?|,/g, '');
                        const subTotal = parseFloat(subTotalText) || 0;
                        const delCharge = parseFloat(document.getElementById('calcDeliveryCharge').value) || 0;
                        const discText = document.getElementById('calcDiscountSummary').innerText.replace(/Rs\.\s?|,/g, '');
                        const discount = parseFloat(discText) || 0;
                        const grandTotal = subTotal + delCharge - discount;

                        const defaultPaid = (state.activePaidAmount && state.activePaidAmount > 0 && state.activePaidAmount < grandTotal) 
                            ? state.activePaidAmount 
                            : Math.round(grandTotal / 2);

                        Swal.fire({
                            title: 'Enter Advance / Paid Amount',
                            html: `Total Order Amount: <b>${formatRs(grandTotal, 0)}</b><br><br>Enter Paid / Advance Amount (Rs.):`,
                            input: 'number',
                            inputValue: defaultPaid,
                            showCancelButton: true,
                            confirmButtonText: 'Save Amount',
                            confirmButtonColor: '#2196f3',
                            inputValidator: (val) => {
                                if (val === '' || isNaN(val) || parseFloat(val) < 0) {
                                    return 'Please enter a valid amount.';
                                }
                            }
                        }).then((result) => {
                            if (result.isConfirmed && result.value !== null) {
                                let parsed = parseFloat(result.value);
                                if (isNaN(parsed) || parsed < 0) parsed = 0;
                                if (parsed > grandTotal) parsed = grandTotal;
                                state.activePaidAmount = parsed;
                                recalculatePOS();
                            }
                        });
                    });
                }
            }

            // Load Customer Selector Table (Screenshot 3)
            function loadCustomerSelectorTable() {
                const search = document.getElementById('custSelectorSearchInput').value;
                fetch(`${baseUrl}get_customers?search=${encodeURIComponent(search)}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            renderCustSelectorTable(data.customers);
                        }
                    });
            }

            function renderCustSelectorTable(customers) {
                const tbody = document.getElementById('tbodyCustSelector');
                tbody.innerHTML = '';
                customers.forEach(c => {
                    const tr = document.createElement('tr');
                    const marginStr = (c.profit_margin && parseFloat(c.profit_margin) > 0) ? `${parseFloat(c.profit_margin).toFixed(2)}%` : '20.38%';

                    tr.innerHTML = `
                        <td class="fw-bold">${escapeHtml(c.name)}</td>
                        <td>${escapeHtml(c.address || '')}</td>
                        <td>${escapeHtml(c.contacts || '')}</td>
                        <td>${escapeHtml(c.email || '')}</td>
                        <td class="fw-bold text-success">${marginStr}</td>
                    `;

                    const selectCustomerToPOS = function() {
                        state.activeCustomer = c;
                        document.getElementById('lblActiveCustomerName').innerText = c.name;
                        document.getElementById('selectCustomer').value = c.id;
                        document.getElementById('custContact').value = c.contacts || '';
                        document.getElementById('custAddress').value = c.address || '';
                        hideModal('modalCustomerSelector');
                    };

                    tr.addEventListener('click', function() {
                        document.querySelectorAll('#tbodyCustSelector tr').forEach(r => r.classList.remove('selected-row'));
                        tr.classList.add('selected-row');
                        selectCustomerToPOS();
                    });

                    tr.addEventListener('dblclick', selectCustomerToPOS);

                    tbody.appendChild(tr);
                });
            }

            // ==========================================
            // PRODUCT SELECTION MODAL LOGIC (Screenshot 2 Popup)
            // ==========================================
            document.getElementById('btnSelectProductModal').addEventListener('click', function() {
                showModal('modalProductSelector');
                loadProductSelectorTable();
                setTimeout(() => {
                    const searchInput = document.getElementById('psSearch');
                    if (searchInput) searchInput.focus();
                }, 150);
            });

            function loadProductSelectorTable() {
                const search = document.getElementById('psSearch').value;
                fetch(baseUrl + 'get_products?search=' + encodeURIComponent(search))
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            state.products = data.products;
                            renderPsTable(data.products);
                        }
                    });
            }

            function renderPsTable(products) {
                const tbody = document.getElementById('tbodyPsProducts');
                tbody.innerHTML = '';
                products.forEach(p => {
                    const tr = document.createElement('tr');

                    tr.innerHTML = `
                        <td class="fw-bold">${escapeHtml(p.product_code)}</td>
                        <td>${escapeHtml(p.description)}</td>
                        <td>${formatRs(p.selling_price, 0)}</td>
                        <td class="text-center">${p.stock}</td>
                    `;

                    const selectProductToPOS = function() {
                        state.selectedProdForPOS = p;
                        document.getElementById('inputProdCode').value = p.product_code;
                        document.getElementById('inputProdDesc').value = p.description;
                        document.getElementById('inputProdCost').value = p.cost;
                        document.getElementById('inputProdPrice').value = p.selling_price;
                        document.getElementById('badgeStockStatus').innerText = `Stock: ${p.stock}`;
                        hideModal('modalProductSelector');
                        document.getElementById('inputProdQty').focus();
                    };

                    tr.addEventListener('click', function() {
                        document.querySelectorAll('#tbodyPsProducts tr').forEach(r => r.classList.remove('selected-row'));
                        tr.classList.add('selected-row');
                        selectProductToPOS();
                    });

                    tr.addEventListener('dblclick', selectProductToPOS);

                    tbody.appendChild(tr);
                });
            }

            document.getElementById('psSearch').addEventListener('input', loadProductSelectorTable);

            // Product Code Autocomplete lookup
            document.getElementById('inputProdCode').addEventListener('change', function() {
                const val = this.value.trim();
                const prod = state.products.find(p => p.product_code === val);
                if (prod) {
                    state.selectedProdForPOS = prod;
                    document.getElementById('inputProdDesc').value = prod.description;
                    document.getElementById('inputProdCost').value = prod.cost;
                    document.getElementById('inputProdPrice').value = prod.selling_price;
                    document.getElementById('badgeStockStatus').innerText = `Stock: ${prod.stock}`;
                }
            });

            // ==========================================
            // TOP BAR NAVIGATION MODAL TRIGGERS
            // ==========================================
            document.getElementById('btnNavProducts').addEventListener('click', () => { showModal('modalProducts'); loadProductsManagement(); });
            document.getElementById('btnNavOrders').addEventListener('click', () => { showModal('modalOrders'); loadOrdersManagement(); });
            document.getElementById('btnNavInvoices').addEventListener('click', () => { showModal('modalInvoices'); loadInvoicesDirectory(); });
            document.getElementById('btnNavDrafts').addEventListener('click', () => { showModal('modalDrafts'); loadDraftsDirectory(); });
            document.getElementById('btnNavSales').addEventListener('click', () => { showModal('modalSales'); loadSalesAnalytics('Month'); });
            document.getElementById('btnNavCustomers').addEventListener('click', () => { showModal('modalCustomers'); loadCustomersDirectory(); });
            document.getElementById('btnNavSettings').addEventListener('click', () => { showModal('modalSettings'); loadSystemSettings(); });
            document.getElementById('btnNavInfo').addEventListener('click', () => { showModal('modalInfo'); });

            const modalOrdersEl = document.getElementById('modalOrders');
            if (modalOrdersEl) {
                modalOrdersEl.addEventListener('show.bs.modal', loadOrdersManagement);
            }
            const modalInvoicesEl = document.getElementById('modalInvoices');
            if (modalInvoicesEl) {
                modalInvoicesEl.addEventListener('show.bs.modal', loadInvoicesDirectory);
            }
            const modalDraftsEl = document.getElementById('modalDrafts');
            if (modalDraftsEl) {
                modalDraftsEl.addEventListener('show.bs.modal', loadDraftsDirectory);
            }

            const btnQuickAdd = document.getElementById('btnQuickAddCustomer');
            if (btnQuickAdd) {
                btnQuickAdd.addEventListener('click', () => {
                    showModal('modalCustomers');
                    loadCustomersDirectory();
                });
            }

            // ==========================================
            // PRODUCTS MANAGEMENT MODULE (MODAL B / Screenshot 1)
            // ==========================================
            function loadProductsManagement() {
                const search = document.getElementById('pmSearch').value;
                fetch(baseUrl + 'get_products?search=' + encodeURIComponent(search))
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            state.products = data.products;
                            renderPmTable(data.products);
                            
                            document.getElementById('pmStatTotalProd').innerText = data.stats.total_products;
                            document.getElementById('pmStatTotalStock').innerText = data.stats.total_stock;
                            document.getElementById('pmStatTotalCost').innerText = formatRs(data.stats.total_cost, 0);
                            document.getElementById('pmStatTotalSelling').innerText = formatRs(data.stats.total_selling, 0);
                        }
                    });
            }

            function renderPmTable(products) {
                const tbody = document.getElementById('tbodyPmProducts');
                tbody.innerHTML = '';
                products.forEach(p => {
                    const tr = document.createElement('tr');
                    if (state.selectedPmRow && state.selectedPmRow.id == p.id) {
                        tr.classList.add('selected-row');
                    }

                    tr.innerHTML = `
                        <td class="fw-bold">${escapeHtml(p.product_code)}</td>
                        <td>${escapeHtml(p.description)}</td>
                        <td class="text-center">${p.stock}</td>
                        <td>${formatRs(p.cost, 0)}</td>
                        <td class="fw-bold">${formatRs(p.selling_price, 0)}</td>
                    `;

                    tr.addEventListener('click', function() {
                        state.selectedPmRow = p;
                        renderPmTable(products);
                        document.getElementById('pmId').value = p.id;
                        document.getElementById('pmCode').value = p.product_code;
                        document.getElementById('pmDesc').value = p.description;
                        document.getElementById('pmStock').value = p.stock;
                        document.getElementById('pmCost').value = p.cost;
                        document.getElementById('pmSellingPrice').value = p.selling_price;
                    });

                    tr.addEventListener('dblclick', function() {
                        state.selectedProdForPOS = p;
                        document.getElementById('inputProdCode').value = p.product_code;
                        document.getElementById('inputProdDesc').value = p.description;
                        document.getElementById('inputProdCost').value = p.cost;
                        document.getElementById('inputProdPrice').value = p.selling_price;
                        document.getElementById('badgeStockStatus').innerText = `Stock: ${p.stock}`;
                        hideModal('modalProducts');
                    });

                    tbody.appendChild(tr);
                });
            }

            document.getElementById('pmSearch').addEventListener('input', loadProductsManagement);

            document.getElementById('btnPmInsert').addEventListener('click', function() {
                document.getElementById('pmId').value = '';
                saveProductForm();
            });

            document.getElementById('btnPmUpdate').addEventListener('click', saveProductForm);

            function saveProductForm() {
                const formData = new FormData();
                formData.append('id', document.getElementById('pmId').value);
                formData.append('product_code', document.getElementById('pmCode').value);
                formData.append('description', document.getElementById('pmDesc').value);
                formData.append('stock', document.getElementById('pmStock').value);
                formData.append('cost', document.getElementById('pmCost').value);
                formData.append('selling_price', document.getElementById('pmSellingPrice').value);

                fetch(baseUrl + 'save_product', { method: 'POST', body: formData })
                    .then(res => res.json())
                    .then(data => {
                        SwalNotify(data.message, data.status === 'success' ? 'success' : 'error');
                        if (data.status === 'success') {
                            loadProductsManagement();
                        }
                    });
            }

            document.getElementById('btnPmDelete').addEventListener('click', function() {
                const id = document.getElementById('pmId').value;
                if (!id) { SwalNotify('Select a product to delete.', 'warning'); return; }
                
                Swal.fire({
                    title: 'Delete Product',
                    text: 'Delete this product record?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, Delete'
                }).then((result) => {
                    if (result.isConfirmed) {
                        const formData = new FormData();
                        formData.append('id', id);
                        fetch(baseUrl + 'delete_product', { method: 'POST', body: formData })
                            .then(res => res.json())
                            .then(data => {
                                SwalNotify(data.message, data.status === 'success' ? 'success' : 'error');
                                loadProductsManagement();
                            });
                    }
                });
            });

            document.getElementById('btnPmIncreaseStock').addEventListener('click', function() {
                const id = document.getElementById('pmId').value;
                if (!id) { SwalNotify('Select a product to add stock.', 'warning'); return; }
                
                Swal.fire({
                    title: 'Add Stock Quantity',
                    text: 'Enter quantity to add to stock:',
                    input: 'number',
                    inputValue: '10',
                    showCancelButton: true,
                    confirmButtonText: 'Add Stock',
                    confirmButtonColor: '#2196f3',
                    inputValidator: (val) => {
                        if (!val || isNaN(val) || parseInt(val) <= 0) {
                            return 'Please enter a valid positive quantity.';
                        }
                    }
                }).then((result) => {
                    if (result.isConfirmed && result.value) {
                        const qty = result.value;
                        const formData = new FormData();
                        formData.append('id', id);
                        formData.append('quantity', qty);
                        fetch(baseUrl + 'increase_stock', { method: 'POST', body: formData })
                            .then(res => res.json())
                            .then(data => {
                                SwalNotify(data.message, data.status === 'success' ? 'success' : 'error');
                                loadProductsManagement();
                            });
                    }
                });
            });

            document.getElementById('btnPmPrintBarcode').addEventListener('click', function() {
                const code = document.getElementById('pmCode').value;
                const desc = document.getElementById('pmDesc').value;
                const price = document.getElementById('pmSellingPrice').value;
                if (!code) { SwalNotify('Select a product to print barcode.', 'warning'); return; }
                renderBarcodePrintView(code, desc, price);
            });

            // ==========================================
            // ORDERS MANAGEMENT MODULE (MODAL C / Screenshot 2)
            // ==========================================
            function loadOrdersManagement() {
                const search = document.getElementById('omSearch').value;
                const sort = document.getElementById('omSort').value;
                const hideDrafts = document.getElementById('omHideDrafts').checked ? '1' : '0';

                fetch(`${baseUrl}get_orders?search=${encodeURIComponent(search)}&sort=${sort}&hide_drafts=${hideDrafts}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            renderOrdersTable(data.orders);
                        }
                    });
            }

            function renderOrdersTable(orders) {
                const tbody = document.getElementById('tbodyOrders');
                if (!tbody) return;
                tbody.innerHTML = '';
                
                if (!orders || !orders.length) {
                    tbody.innerHTML = `<tr><td colspan="11" class="text-center text-muted py-4">No orders found.</td></tr>`;
                    return;
                }

                const chkAll = document.getElementById('chkSelectAllOrders');
                if (chkAll) {
                    chkAll.checked = false;
                    chkAll.onclick = function() {
                        const isChecked = this.checked;
                        document.querySelectorAll('.chk-order-select').forEach(cb => {
                            cb.checked = isChecked;
                        });
                    };
                }

                orders.forEach(o => {
                    const tr = document.createElement('tr');
                    if (state.selectedOrderRow && state.selectedOrderRow.id == o.id) {
                        tr.classList.add('selected-row');
                    }

                    let badgeClass = 'badge-soft-paid';
                    if (o.status === 'Pending') badgeClass = 'badge-soft-pending';
                    if (o.status === 'Partial Paid') badgeClass = 'badge-soft-partial';

                    const displayDate = escapeHtml(o.formatted_date || o.order_date || o.created_at || '-');

                    tr.innerHTML = `
                        <td class="text-center" onclick="event.stopPropagation();">
                            <input type="checkbox" class="form-check-input chk-order-select" data-id="${o.id}">
                        </td>
                        <td class="fw-bold">${escapeHtml(o.order_no)}</td>
                        <td><small>${displayDate}</small></td>
                        <td class="fw-semibold">${escapeHtml(o.customer_name || 'Walk-in Customer')}</td>
                        <td><span class="${badgeClass}">${escapeHtml(o.status)}</span></td>
                        <td><small class="font-monospace text-muted">${escapeHtml(o.tracking_no || '-')}</small></td>
                        <td class="text-end">${formatRs(o.total_cost, 0)}</td>
                        <td class="text-end text-danger">${formatRs(o.discount, 0)}</td>
                        <td class="text-end fw-bold text-primary">${formatRs(o.total_amount, 0)}</td>
                        <td class="text-end text-success">${formatRs(o.profit, 0)}</td>
                        <td class="text-end">${parseFloat(o.profit_margin || 0).toFixed(1)}%</td>
                    `;

                    tr.addEventListener('click', function() {
                        state.selectedOrderRow = o;
                        renderOrdersTable(orders);
                    });

                    tbody.appendChild(tr);
                });
            }

            document.getElementById('omSearch').addEventListener('input', loadOrdersManagement);
            document.getElementById('omSort').addEventListener('change', loadOrdersManagement);
            document.getElementById('omHideDrafts').addEventListener('change', loadOrdersManagement);

            document.getElementById('btnOmDeleteUndo').addEventListener('click', function() {
                if (!state.selectedOrderRow) { SwalNotify('Select an order from the list.', 'warning'); return; }
                
                Swal.fire({
                    title: 'Delete & Undo Stock',
                    text: `Delete Order ${state.selectedOrderRow.order_no} and undo stock deduction in inventory?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, Delete Order'
                }).then((result) => {
                    if (result.isConfirmed) {
                        const formData = new FormData();
                        formData.append('id', state.selectedOrderRow.id);
                        fetch(baseUrl + 'delete_order', { method: 'POST', body: formData })
                            .then(res => res.json())
                            .then(data => {
                                SwalNotify(data.message, data.status === 'success' ? 'success' : 'error');
                                state.selectedOrderRow = null;
                                loadOrdersManagement();
                            });
                    }
                });
            });

            document.getElementById('btnOmUpdateStatus').addEventListener('click', function() {
                if (!state.selectedOrderRow) { SwalNotify('Select an order from the list.', 'warning'); return; }
                
                Swal.fire({
                    title: 'Update Order Status',
                    input: 'select',
                    inputOptions: {
                        'Paid': 'Paid',
                        'Pending': 'Pending',
                        'Partial Paid': 'Partial Paid'
                    },
                    inputValue: state.selectedOrderRow.status,
                    showCancelButton: true,
                    confirmButtonText: 'Update Status',
                    confirmButtonColor: '#2196f3'
                }).then((result) => {
                    if (result.isConfirmed && result.value) {
                        const newStatus = result.value;
                        const formData = new FormData();
                        formData.append('id', state.selectedOrderRow.id);
                        formData.append('status', newStatus);
                        fetch(baseUrl + 'update_order_status', { method: 'POST', body: formData })
                            .then(res => res.json())
                            .then(data => {
                                SwalNotify(data.message, data.status === 'success' ? 'success' : 'error');
                                loadOrdersManagement();
                            });
                    }
                });
            });

            document.getElementById('btnOmGenInvoice').addEventListener('click', function() {
                if (!state.selectedOrderRow) { SwalNotify('Select an order to view invoice.', 'warning'); return; }
                renderInvoicePrintView(state.selectedOrderRow.id);
            });

            document.getElementById('btnOmGenReceipt').addEventListener('click', function() {
                if (!state.selectedOrderRow) { SwalNotify('Select an order to view receipt.', 'warning'); return; }
                renderThermalReceiptView(state.selectedOrderRow.id);
            });

            function triggerParcelLabelPrint() {
                const checkedCbs = Array.from(document.querySelectorAll('.chk-order-select:checked'));
                let targetIds = checkedCbs.map(cb => cb.getAttribute('data-id'));

                if (targetIds.length === 0 && state.selectedOrderRow) {
                    targetIds = [state.selectedOrderRow.id];
                }

                if (targetIds.length === 0) {
                    SwalNotify('Please tick the checkbox next to the order(s) you wish to print parcel shipping labels for.', 'warning');
                    return;
                }

                renderBulkParcelLabelsView(targetIds);
            }

            const btnOmBulkPrintParcel = document.getElementById('btnOmBulkPrintParcel');
            if (btnOmBulkPrintParcel) {
                btnOmBulkPrintParcel.addEventListener('click', triggerParcelLabelPrint);
            }

            document.getElementById('btnOmExport').addEventListener('click', function() {
                SwalNotify('Exporting orders directory...', 'info');
            });

            // ==========================================
            // INVOICES MODULE (MODAL D / Screenshot 3)
            // ==========================================
            function loadInvoicesDirectory() {
                const search = document.getElementById('invSearch').value;
                fetch(baseUrl + 'get_invoices?search=' + encodeURIComponent(search))
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            renderInvoicesTable(data.invoices);
                        }
                    });
            }

            function renderInvoicesTable(invoices) {
                const tbody = document.getElementById('tbodyInvoices');
                if (!tbody) return;
                tbody.innerHTML = '';
                
                if (!invoices || !invoices.length) {
                    tbody.innerHTML = `<tr><td colspan="3" class="text-center text-muted py-4">No invoices found.</td></tr>`;
                    return;
                }

                invoices.forEach(inv => {
                    const tr = document.createElement('tr');
                    if (state.selectedInvoiceRow && state.selectedInvoiceRow.id == inv.id) {
                        tr.classList.add('selected-row');
                    }

                    const displayDate = escapeHtml(inv.formatted_date || inv.order_date || inv.created_at || '-');

                    tr.innerHTML = `
                        <td class="fw-bold">${escapeHtml(inv.invoice_no || inv.order_no)}</td>
                        <td>${displayDate}</td>
                        <td>${escapeHtml(inv.customer_name || 'Walk-in Customer')}</td>
                    `;

                    tr.addEventListener('click', function() {
                        state.selectedInvoiceRow = inv;
                        renderInvoicesTable(invoices);
                    });

                    tbody.appendChild(tr);
                });
            }

            document.getElementById('invSearch').addEventListener('input', loadInvoicesDirectory);

            document.getElementById('btnInvPreview').addEventListener('click', function() {
                if (!state.selectedInvoiceRow) { SwalNotify('Select an invoice from directory.', 'warning'); return; }
                renderInvoicePrintView(state.selectedInvoiceRow.id);
            });

            document.getElementById('btnInvOpen').addEventListener('click', function() {
                if (!state.selectedInvoiceRow) { SwalNotify('Select an invoice from directory.', 'warning'); return; }
                renderInvoicePrintView(state.selectedInvoiceRow.id);
            });

            document.getElementById('btnInvDelete').addEventListener('click', function() {
                if (!state.selectedInvoiceRow) { SwalNotify('Select an invoice to delete.', 'warning'); return; }
                
                Swal.fire({
                    title: 'Delete Invoice',
                    text: 'Delete selected invoice record?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, Delete'
                }).then((result) => {
                    if (result.isConfirmed) {
                        const formData = new FormData();
                        formData.append('id', state.selectedInvoiceRow.id);
                        fetch(baseUrl + 'delete_order', { method: 'POST', body: formData })
                            .then(res => res.json())
                            .then(data => {
                                SwalNotify(data.message, data.status === 'success' ? 'success' : 'error');
                                loadInvoicesDirectory();
                            });
                    }
                });
            });

            // ==========================================
            // DRAFTS MODULE (MODAL E)
            // ==========================================
            function loadDraftsDirectory() {
                const search = document.getElementById('draftSearch').value;
                fetch(baseUrl + 'get_drafts?search=' + encodeURIComponent(search))
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            renderDraftsTable(data.drafts);
                        }
                    });
            }

            function renderDraftsTable(drafts) {
                const tbody = document.getElementById('tbodyDrafts');
                if (!tbody) return;
                tbody.innerHTML = '';

                if (!drafts || !drafts.length) {
                    tbody.innerHTML = `<tr><td colspan="4" class="text-center text-muted py-4">No drafts found.</td></tr>`;
                    return;
                }

                drafts.forEach(d => {
                    const tr = document.createElement('tr');
                    if (state.selectedDraftRow && state.selectedDraftRow.id == d.id) {
                        tr.classList.add('selected-row');
                    }

                    const displayDate = escapeHtml(d.formatted_date || d.order_date || d.created_at || '-');

                    tr.innerHTML = `
                        <td class="fw-bold">${escapeHtml(d.order_no)}</td>
                        <td>${displayDate}</td>
                        <td>${escapeHtml(d.draft_name || 'Draft')}</td>
                        <td>${escapeHtml(d.customer_name || 'Walk-in Customer')}</td>
                    `;

                    tr.addEventListener('click', function() {
                        state.selectedDraftRow = d;
                        renderDraftsTable(drafts);
                    });

                    tbody.appendChild(tr);
                });
            }

            document.getElementById('draftSearch').addEventListener('input', loadDraftsDirectory);

            document.getElementById('btnDraftOpen').addEventListener('click', function() {
                if (!state.selectedDraftRow) { SwalNotify('Select a draft order to open.', 'warning'); return; }
                fetch(baseUrl + 'load_draft/' + state.selectedDraftRow.id)
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            state.cart = data.items.map(i => ({
                                product_id: i.product_id,
                                product_code: i.product_code,
                                description: i.description,
                                quantity: parseInt(i.quantity),
                                cost: parseFloat(i.cost),
                                unit_price: parseFloat(i.unit_price),
                                discount: 0.00
                            }));

                            state.activeDraftId = data.order.id;
                            document.getElementById('selectCustomer').value = data.order.customer_id || 1;
                            document.getElementById('calcDeliveryCharge').value = data.order.delivery_charge;

                            renderCartTable();
                            recalculatePOS();
                            hideModal('modalDrafts');
                            SwalNotify(`Draft "${data.order.draft_name}" loaded into POS canvas.`, 'success');
                        }
                    });
            });

            document.getElementById('btnDraftDelete').addEventListener('click', function() {
                if (!state.selectedDraftRow) { SwalNotify('Select a draft to delete.', 'warning'); return; }
                
                Swal.fire({
                    title: 'Delete Draft',
                    text: 'Delete selected draft?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, Delete'
                }).then((result) => {
                    if (result.isConfirmed) {
                        const formData = new FormData();
                        formData.append('id', state.selectedDraftRow.id);
                        fetch(baseUrl + 'delete_order', { method: 'POST', body: formData })
                            .then(res => res.json())
                            .then(data => {
                                SwalNotify(data.message, data.status === 'success' ? 'success' : 'error');
                                loadDraftsDirectory();
                            });
                    }
                });
            });

            // ==========================================
            // SALES ANALYTICS MODULE (MODAL F / Screenshot 4)
            // ==========================================
            function loadSalesAnalytics(period) {
                fetch(baseUrl + 'get_sales_analytics?period=' + period)
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            renderSalesAnalyticsTable(data.rows);

                            document.getElementById('salesTotalOrders').innerText = data.summary.total_orders;
                            document.getElementById('salesTotalRevenue').innerText = formatRs(data.summary.total_revenue, 2);
                            document.getElementById('salesTotalProfit').innerText = formatRs(data.summary.total_profit, 2);
                        }
                    });
            }

            function renderSalesAnalyticsTable(rows) {
                const tbody = document.getElementById('tbodySales');
                tbody.innerHTML = '';
                rows.forEach(r => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td class="fw-bold">${r.period}</td>
                        <td>${r.orders_count}</td>
                        <td>${r.items_sold}</td>
                        <td>${formatRs(r.revenue, 2)}</td>
                        <td>${formatRs(r.cost, 2)}</td>
                        <td class="fw-bold text-success">${formatRs(r.profit, 2)}</td>
                        <td>${parseFloat(r.profit_margin).toFixed(2)}%</td>
                    `;
                    tbody.appendChild(tr);
                });
            }

            document.getElementById('salesPeriodSelect').addEventListener('change', function() {
                loadSalesAnalytics(this.value);
            });

            document.getElementById('btnSalesCharts').addEventListener('click', function() { SwalNotify('Toggling visual analytics charts view...', 'info'); });
            document.getElementById('btnSalesMoreDetails').addEventListener('click', function() { SwalNotify('Displaying extended sales breakdown report...', 'info'); });
            document.getElementById('btnSalesExport').addEventListener('click', function() { SwalNotify('Exporting Sales report...', 'info'); });

            // ==========================================
            // CUSTOMERS MODULE (MODAL G / Screenshot 5)
            // ==========================================
            function loadCustomersDirectory() {
                const search = document.getElementById('cmSearch').value;
                const sort = document.getElementById('cmSort').value;
                fetch(`${baseUrl}get_customers?search=${encodeURIComponent(search)}&sort=${sort}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            state.customers = data.customers;
                            renderCustomersTable(data.customers);
                        }
                    });
            }

            function renderCustomersTable(customers) {
                const tbody = document.getElementById('tbodyCustomers');
                tbody.innerHTML = '';
                customers.forEach(c => {
                    const tr = document.createElement('tr');
                    if (state.selectedCustomerRow && state.selectedCustomerRow.id == c.id) {
                        tr.classList.add('selected-row');
                    }

                    tr.innerHTML = `
                        <td class="fw-bold">${escapeHtml(c.name)}</td>
                        <td>${escapeHtml(c.contacts || '')}</td>
                        <td>${c.orders_count}</td>
                        <td>${c.items_count}</td>
                        <td>${formatRs(c.total_spent, 0)}</td>
                        <td>${formatRs(c.total_cost, 0)}</td>
                        <td>${formatRs(c.total_profit, 0)}</td>
                        <td>${parseFloat(c.profit_margin).toFixed(2)}%</td>
                        <td>${parseFloat(c.profit_margin * 0.8).toFixed(2)}%</td>
                    `;

                    tr.addEventListener('click', function() {
                        state.selectedCustomerRow = c;
                        renderCustomersTable(customers);
                    });

                    tbody.appendChild(tr);
                });
            }

            document.getElementById('cmSearch').addEventListener('input', loadCustomersDirectory);
            document.getElementById('cmSort').addEventListener('change', loadCustomersDirectory);
            document.getElementById('btnCmExport').addEventListener('click', function() { SwalNotify('Exporting Customers list...', 'info'); });

            // ==========================================
            // SETTINGS MODULE (MODAL H)
            // ==========================================
            function renderCourierRatesSettingsTable(rates) {
                const tbody = document.getElementById('tbodyCourierRates');
                if (!tbody) return;
                tbody.innerHTML = '';

                const list = (rates && rates.length) ? rates : [
                    { courier_name: 'Prompt XP', first_kg_rate: 500, additional_kg_rate: 150 },
                    { courier_name: 'Fargo', first_kg_rate: 450, additional_kg_rate: 120 },
                    { courier_name: 'Pronto', first_kg_rate: 400, additional_kg_rate: 100 },
                    { courier_name: 'Domex', first_kg_rate: 480, additional_kg_rate: 130 },
                    { courier_name: 'SL Post', first_kg_rate: 250, additional_kg_rate: 80 }
                ];

                list.forEach(r => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td class="fw-bold align-middle">${escapeHtml(r.courier_name)}</td>
                        <td>
                            <input type="number" class="form-control form-control-desktop courier-first-kg py-1 px-2" data-courier="${escapeHtml(r.courier_name)}" value="${r.first_kg_rate}" step="10">
                        </td>
                        <td>
                            <input type="number" class="form-control form-control-desktop courier-add-kg py-1 px-2" data-courier="${escapeHtml(r.courier_name)}" value="${r.additional_kg_rate}" step="10">
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            }

            function loadSystemSettings() {
                fetch(baseUrl + 'get_settings')
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            const s = data.settings || {};
                            document.getElementById('setStoreName').value = s.store_name || 'Sithangi Teddy Factory';
                            document.getElementById('setStorePhone').value = s.store_phone || '0775476996';
                            document.getElementById('setStoreAddress').value = s.store_address || '';
                            document.getElementById('setStoreLogoVal').value = s.store_logo || '';

                            const imgPreview = document.getElementById('setLogoImgPreview');
                            const iconPlaceholder = document.getElementById('setLogoIconPlaceholder');
                            const btnRemove = document.getElementById('btnRemoveLogo');

                            if (s.store_logo) {
                                const src = s.store_logo.startsWith('data:') ? s.store_logo : (baseUrl + s.store_logo);
                                imgPreview.src = src;
                                imgPreview.style.display = 'block';
                                iconPlaceholder.style.display = 'none';
                                btnRemove.style.display = 'inline-block';
                            } else {
                                imgPreview.style.display = 'none';
                                iconPlaceholder.style.display = 'block';
                                btnRemove.style.display = 'none';
                            }

                            document.getElementById('setResetOnConfirm').checked = s.reset_on_confirm == 1;
                            document.getElementById('setDirectPrint').checked = s.direct_print == 1;
                            document.getElementById('setEnableLowStock').checked = s.enable_low_stock == 1;
                            document.getElementById('setLowStockLimit').value = s.low_stock_limit;
                            document.getElementById('setEnableDelivery').checked = s.enable_delivery == 1;
                            document.getElementById('setDeliveryPartner').value = s.delivery_partner;
                            document.getElementById('setCustomParcelDesc').value = s.custom_parcel_desc || '';
                            document.getElementById('setInvoicePrinter').value = s.invoice_printer;
                            document.getElementById('setReceiptPrinter').value = s.receipt_printer;
                            document.getElementById('setParcelPrinter').value = s.parcel_printer;
                            document.getElementById('setBarcodePrinter').value = s.barcode_printer;
                            document.getElementById('setRestrictedMode').checked = s.restricted_mode == 1;

                            if (s.default_status === 'Paid') document.getElementById('defStatusPaid').checked = true;
                            if (s.default_status === 'Pending') document.getElementById('defStatusPending').checked = true;
                            if (s.default_status === 'Partial Paid') document.getElementById('defStatusPartial').checked = true;

                            if (data.courier_rates) {
                                state.courier_rates = data.courier_rates;
                            }
                            renderCourierRatesSettingsTable(data.courier_rates || state.courier_rates);
                        }
                    });
            }

            const logoFileInput = document.getElementById('setLogoFileInput');
            if (logoFileInput) {
                logoFileInput.addEventListener('change', function() {
                    const file = this.files[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onload = function(e) {
                            document.getElementById('setLogoImgPreview').src = e.target.result;
                            document.getElementById('setLogoImgPreview').style.display = 'block';
                            document.getElementById('setLogoIconPlaceholder').style.display = 'none';
                            document.getElementById('setStoreLogoVal').value = e.target.result;
                            document.getElementById('btnRemoveLogo').style.display = 'inline-block';
                        };
                        reader.readAsDataURL(file);
                    }
                });
            }

            const btnRemoveLogo = document.getElementById('btnRemoveLogo');
            if (btnRemoveLogo) {
                btnRemoveLogo.addEventListener('click', function() {
                    document.getElementById('setLogoFileInput').value = '';
                    document.getElementById('setStoreLogoVal').value = '';
                    document.getElementById('setLogoImgPreview').style.display = 'none';
                    document.getElementById('setLogoIconPlaceholder').style.display = 'block';
                    this.style.display = 'none';
                });
            }

            document.getElementById('btnSaveSettings').addEventListener('click', function() {
                const formData = new FormData();
                formData.append('store_name', document.getElementById('setStoreName').value);
                formData.append('store_phone', document.getElementById('setStorePhone').value);
                formData.append('store_address', document.getElementById('setStoreAddress').value);
                formData.append('store_logo', document.getElementById('setStoreLogoVal').value);

                const fileInput = document.getElementById('setLogoFileInput');
                if (fileInput && fileInput.files && fileInput.files[0]) {
                    formData.append('store_logo_file', fileInput.files[0]);
                }

                formData.append('reset_on_confirm', document.getElementById('setResetOnConfirm').checked ? 1 : 0);
                formData.append('direct_print', document.getElementById('setDirectPrint').checked ? 1 : 0);
                formData.append('enable_low_stock', document.getElementById('setEnableLowStock').checked ? 1 : 0);
                formData.append('low_stock_limit', document.getElementById('setLowStockLimit').value);
                formData.append('enable_delivery', document.getElementById('setEnableDelivery').checked ? 1 : 0);
                formData.append('delivery_partner', document.getElementById('setDeliveryPartner').value);
                formData.append('custom_parcel_desc', document.getElementById('setCustomParcelDesc').value);
                formData.append('invoice_printer', document.getElementById('setInvoicePrinter').value);
                formData.append('receipt_printer', document.getElementById('setReceiptPrinter').value);
                formData.append('parcel_printer', document.getElementById('setParcelPrinter').value);
                formData.append('barcode_printer', document.getElementById('setBarcodePrinter').value);
                formData.append('restricted_mode', document.getElementById('setRestrictedMode').checked ? 1 : 0);

                const statusRadio = document.querySelector('input[name="setDefaultStatus"]:checked');
                formData.append('default_status', statusRadio ? statusRadio.value : 'Paid');

                // Extract and save Courier Rates
                const ratesToSave = [];
                document.querySelectorAll('#tbodyCourierRates tr').forEach(tr => {
                    const fInput = tr.querySelector('.courier-first-kg');
                    const aInput = tr.querySelector('.courier-add-kg');
                    if (fInput && aInput) {
                        ratesToSave.push({
                            courier_name: fInput.getAttribute('data-courier'),
                            first_kg_rate: parseFloat(fInput.value) || 0,
                            additional_kg_rate: parseFloat(aInput.value) || 0
                        });
                    }
                });

                const crFormData = new FormData();
                crFormData.append('rates', JSON.stringify(ratesToSave));
                fetch(baseUrl + 'save_courier_rates', { method: 'POST', body: crFormData })
                    .then(res => res.json())
                    .then(crData => {
                        if (crData.status === 'success') {
                            state.courier_rates = crData.courier_rates;
                        }
                    });

                fetch(baseUrl + 'save_settings', { method: 'POST', body: formData })
                    .then(res => res.json())
                    .then(data => {
                        SwalNotify(data.message, data.status === 'success' ? 'success' : 'error');
                        if (data.status === 'success') {
                            state.settings = data.settings;
                            hideModal('modalSettings');
                        }
                    });
            });

            // ==========================================
            // POS MAIN CHECKOUT ACTIONS
            // ==========================================

            document.getElementById('btnResetCart').addEventListener('click', function() {
                Swal.fire({
                    title: 'Reset Current Order',
                    text: 'Are you sure you want to reset the current order?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, Reset Cart'
                }).then((result) => {
                    if (result.isConfirmed) {
                        state.cart = [];
                        state.selectedCartIndex = null;
                        state.activeDraftId = null;
                        state.activeDeliveryCharge = 0;
                        state.isFreeDelivery = false;
                        clearLeftProductInputs();
                        renderCartTable();
                        recalculatePOS();
                    }
                });
            });

            document.getElementById('btnSaveDraft').addEventListener('click', function() {
                if (state.cart.length === 0) {
                    SwalNotify('Cart is empty. Please add items to save draft.', 'warning');
                    return;
                }

                const defaultDraftName = 'Draft Order #' + Math.floor(Math.random()*1000);
                Swal.fire({
                    title: 'Save Draft Order',
                    text: 'Enter a recognizable name for this order draft:',
                    input: 'text',
                    inputValue: defaultDraftName,
                    showCancelButton: true,
                    confirmButtonText: 'Save Draft',
                    confirmButtonColor: '#2196f3',
                    inputValidator: (val) => {
                        if (!val || !val.trim()) {
                            return 'Please enter a name for the draft.';
                        }
                    }
                }).then((result) => {
                    if (result.isConfirmed && result.value) {
                        saveOrderPayload(1, result.value.trim(), false);
                    }
                });
            });

            document.getElementById('btnGenerateInvoice').addEventListener('click', function() {
                if (state.cart.length === 0) {
                    SwalNotify('Cart is empty. Please add items to generate invoice.', 'warning');
                    return;
                }
                saveOrderPayload(0, null, true, 'invoice');
            });

            document.getElementById('btnConfirmOrder').addEventListener('click', function() {
                if (state.cart.length === 0) {
                    SwalNotify('Cart is empty. Please add items to confirm order.', 'warning');
                    return;
                }
                saveOrderPayload(0, null, true, 'receipt');
            });

            function saveOrderPayload(isDraft, draftName, openPrintModal = false, printType = 'receipt') {
                const customerId = document.getElementById('selectCustomer').value;
                const custRow = state.customers.find(c => c.id == customerId);
                const statusInput = document.getElementById('inputPaymentStatusVal');
                const status = state.activeStatus || (statusInput ? statusInput.value : 'Paid');

                const payload = {
                    order_id: state.activeDraftId,
                    customer_id: customerId,
                    customer_name: custRow ? custRow.name : 'Visit Oder',
                    customer_contacts: document.getElementById('custContact').value,
                    customer_address: document.getElementById('custAddress').value,
                    is_draft: isDraft,
                    draft_name: draftName,
                    status: status,
                    waybill_id: state.activeWaybillId || '',
                    delivery_service: state.activeDeliveryService || 'Prompt XP',
                    package_weight: state.activePackageWeight || 0,
                    delivery_charge: parseFloat(document.getElementById('calcDeliveryCharge').value) || 0.00,
                    discount: parseFloat(document.getElementById('calcDiscountSummary').innerText.replace(/Rs\.\s?|,/g, '')) || 0.00,
                    paid_amount: parseFloat(state.activePaidAmount) || 0.00,
                    balance: parseFloat(document.getElementById('calcBalance').innerText.replace(/Rs\.\s?|,/g, '')) || 0.00,
                    items: state.cart
                };

                fetch(baseUrl + 'save_order', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                })
                .then(res => res.json())
                .then(data => {
                    SwalNotify(data.message, data.status === 'success' ? 'success' : 'error');
                    if (data.status === 'success') {
                        const orderId = data.order.id;

                        if (openPrintModal) {
                            if (printType === 'invoice') {
                                renderInvoicePrintView(orderId);
                            } else {
                                renderThermalReceiptView(orderId);
                            }
                        }

                        if (state.settings.reset_on_confirm == 1 || isDraft == 0) {
                            state.cart = [];
                            state.activeDraftId = null;
                            clearLeftProductInputs();
                            renderCartTable();
                            recalculatePOS();
                            fetchInitialData();
                        }
                    }
                })
                .catch(err => {
                    console.error('Save order error:', err);
                    SwalNotify('Error processing order transaction.', 'error');
                });
            }

            // ==========================================
            // PRINT TEMPLATES RENDERING ENGINE
            // ==========================================

            function renderThermalReceiptView(orderId) {
                fetch(baseUrl + 'get_invoice_details/' + orderId)
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            const o = data.order;
                            const c = data.customer || { name: 'Walk-in Customer', contacts: '', address: '' };
                            const items = data.items || [];
                            const settings = data.settings || {};

                            document.getElementById('printModalTitle').innerText = '80mm Thermal Receipt Preview';

                            let totalQty = 0;
                            let totalLineDiscount = 0;
                            let itemsHtml = '';

                            items.forEach(i => {
                                const qty = parseInt(i.quantity) || 1;
                                totalQty += qty;

                                const rate = parseFloat(i.unit_price) || 0;
                                const unitDisc = parseFloat(i.discount) || 0;
                                const lineDisc = qty * unitDisc;
                                totalLineDiscount += lineDisc;
                                const lineTotal = parseFloat(i.total) || ((qty * rate) - lineDisc);

                                itemsHtml += `
                                    <tr>
                                        <td colspan="4" style="padding: 4px 0 1px 0; font-weight: bold; font-size: 11px; word-break: break-word; text-align: left;">
                                            ${escapeHtml(i.description)}
                                        </td>
                                    </tr>
                                    <tr style="border-bottom: 1px dotted #ccc;">
                                        <td style="padding: 1px 2px 4px 2px; text-align: left; vertical-align: top;">${qty}</td>
                                        <td style="padding: 1px 2px 4px 2px; text-align: right; vertical-align: top;">${rate.toFixed(2)}</td>
                                        <td style="padding: 1px 2px 4px 2px; text-align: right; vertical-align: top;">${lineDisc > 0 ? lineDisc.toFixed(2) : '0.00'}</td>
                                        <td style="padding: 1px 2px 4px 2px; text-align: right; vertical-align: top; font-weight: bold;">${lineTotal.toFixed(2)}</td>
                                    </tr>
                                `;
                            });

                            const subTotal = parseFloat(o.sub_total) || 0.00;
                            const deliveryCharge = parseFloat(o.delivery_charge) || 0.00;
                            const orderDiscount = parseFloat(o.discount) || 0.00;
                            const grandTotal = parseFloat(o.total_amount) || 0.00;
                            
                            const totalDiscountSaved = (orderDiscount > 0) ? orderDiscount : totalLineDiscount;

                            let paidAmount = parseFloat(o.paid_amount) || 0.00;
                            let balanceAmount = parseFloat(o.balance_amount) || 0.00;

                            if (o.status === 'Paid' && paidAmount === 0) {
                                paidAmount = grandTotal;
                                balanceAmount = 0.00;
                            } else if (o.status === 'Pending') {
                                paidAmount = 0.00;
                                balanceAmount = grandTotal;
                            }

                            document.getElementById('printModalBody').innerHTML = `
                                <div class="printable-area thermal-receipt" style="width: 280px; margin: 0 auto; padding: 10px; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 11px; color: #000; background: #fff;">
                                    
                                    <!-- Store Header -->
                                    <div style="text-align: center; margin-bottom: 6px;">
                                        ${settings.store_logo ? `<img src="${settings.store_logo.startsWith('data:') ? settings.store_logo : (baseUrl + settings.store_logo)}" alt="Logo" style="max-height: 48px; width: auto; margin-bottom: 4px; display: block; margin-left: auto; margin-right: auto;">` : ''}
                                        <div style="font-size: 16px; font-weight: 800; letter-spacing: 0.5px; text-transform: uppercase; color: #000;">${escapeHtml(settings.store_name || 'SITHANGI TEDDY FACTORY')}</div>
                                        ${settings.store_address ? `<div style="font-size: 10px; color: #333; margin-top: 2px;">${escapeHtml(settings.store_address)}</div>` : '<div style="font-size: 10px; color: #333; margin-top: 2px;">No:- 12/B, Yakkala Road, Yakkala.</div>'}
                                        <div style="font-size: 10px; font-weight: bold; color: #000;">${escapeHtml(settings.store_phone || '0775476996')}</div>
                                    </div>

                                    <div style="border-top: 1px solid #000; margin: 6px 0;"></div>

                                    <!-- Bill Info Header -->
                                    <div style="font-size: 10px; margin-bottom: 6px; line-height: 1.4;">
                                        <div style="display: flex; justify-content: space-between;">
                                            <span>Bill No: <strong>${escapeHtml(o.order_no)}</strong></span>
                                            <span style="font-weight: bold; text-transform: uppercase;">${o.status}</span>
                                        </div>
                                        <div style="display: flex; justify-content: space-between;">
                                            <span>Cashier:</span>
                                            <strong>Sithangi POS</strong>
                                        </div>
                                        <div style="display: flex; justify-content: space-between;">
                                            <span>Date:</span>
                                            <span>${o.order_date || o.created_at}</span>
                                        </div>
                                        
                                        <div style="border-top: 1px dashed #aaa; margin: 5px 0;"></div>
                                        
                                        <!-- Customer Info -->
                                        <div>Customer: <strong>${escapeHtml(c.name || 'Walk-in Customer')}</strong></div>
                                        ${c.contacts ? `<div>Contact: ${escapeHtml(c.contacts)}</div>` : ''}
                                        ${c.address ? `<div>Address: ${escapeHtml(c.address)}</div>` : ''}
                                    </div>

                                    <!-- Items Table -->
                                    <table style="width: 100%; font-size: 10px; border-collapse: collapse; margin-top: 6px;">
                                        <thead>
                                            <tr style="background-color: #000; color: #fff; text-transform: uppercase; font-size: 9px;">
                                                <th style="padding: 4px 2px; text-align: left; width: 15%;">QTY</th>
                                                <th style="padding: 4px 2px; text-align: right; width: 28%;">RATE</th>
                                                <th style="padding: 4px 2px; text-align: right; width: 27%;">DISC</th>
                                                <th style="padding: 4px 2px; text-align: right; width: 30%;">AMOUNT</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${itemsHtml}
                                        </tbody>
                                    </table>

                                    <div style="border-top: 1.5px solid #000; margin: 6px 0 4px 0;"></div>

                                    <!-- Totals & Payments -->
                                    <div style="font-size: 11px; line-height: 1.5;">
                                        ${deliveryCharge > 0 ? `<div style="display: flex; justify-content: space-between;"><span>SUB TOTAL:</span><span>${subTotal.toFixed(2)}</span></div>` : ''}
                                        ${deliveryCharge > 0 ? `<div style="display: flex; justify-content: space-between;"><span>DELIVERY:</span><span>${deliveryCharge.toFixed(2)}</span></div>` : ''}
                                        ${totalDiscountSaved > 0 ? `<div style="display: flex; justify-content: space-between;"><span>DISCOUNT:</span><span>-${totalDiscountSaved.toFixed(2)}</span></div>` : ''}

                                        <div style="display: flex; justify-content: space-between; font-size: 14px; font-weight: bold; margin-top: 4px; border-top: 1px solid #000; padding-top: 4px;">
                                            <span>GRAND TOTAL</span>
                                            <span>${grandTotal.toFixed(2)}</span>
                                        </div>

                                        <div style="display: flex; justify-content: space-between; margin-top: 4px; font-size: 11px;">
                                            <span>PAYMENTS:</span>
                                            <span>${paidAmount.toFixed(2)}</span>
                                        </div>
                                        <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 12px;">
                                            <span>BALANCE:</span>
                                            <span>Rs. ${balanceAmount.toFixed(2)}</span>
                                        </div>
                                    </div>

                                    <!-- YOU SAVED Section -->
                                    ${totalDiscountSaved > 0 ? `
                                    <div style="border-top: 1px dashed #000; border-bottom: 1px dashed #000; margin: 8px 0; padding: 6px 0; text-align: center;">
                                        <div style="font-weight: bold; font-size: 11px; letter-spacing: 1px; text-transform: uppercase;">YOU SAVED</div>
                                        <div style="font-size: 15px; font-weight: bold; margin-top: 2px;">Rs. ${totalDiscountSaved.toFixed(2)}</div>
                                    </div>
                                    ` : '<div style="border-top: 1px dashed #000; margin: 8px 0;"></div>'}

                                    <!-- Footer -->
                                    <div style="text-align: center; font-size: 10px; line-height: 1.4;">
                                        <div style="font-weight: bold; margin-bottom: 2px;">ITEMS COUNT: ${totalQty}</div>
                                        <div style="font-weight: bold; font-size: 12px; margin-top: 4px;">Thank You! Come Again</div>
                                        <div style="font-size: 9px; color: #555; margin-top: 4px; font-style: italic;">System Powered By Zenith OMS</div>
                                    </div>
                                </div>
                            `;

                            showModal('modalPrintPreview');
                        }
                    });
            }

            function renderInvoicePrintView(orderId) {
                fetch(baseUrl + 'get_invoice_details/' + orderId)
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            const o = data.order;
                            const c = data.customer || { name: 'Visit Oder', contacts: '-', address: '-' };
                            const items = data.items;

                            document.getElementById('printModalTitle').innerText = 'Official A4 Invoice Preview';

                            let itemsRows = '';
                            items.forEach((i, idx) => {
                                itemsRows += `
                                    <tr>
                                        <td class="text-center">${idx + 1}</td>
                                        <td class="fw-bold">${escapeHtml(i.product_code)}</td>
                                        <td>${escapeHtml(i.description)}</td>
                                        <td class="text-center">${i.quantity}</td>
                                        <td class="text-end">${formatRs(i.unit_price, 0)}</td>
                                        <td class="text-end fw-bold">${formatRs(i.total, 0)}</td>
                                    </tr>
                                `;
                            });

                            document.getElementById('printModalBody').innerHTML = `
                                <div class="printable-area bg-white p-4 rounded border shadow-sm">
                                    <div class="d-flex justify-content-between border-bottom pb-3 mb-3">
                                        <div>
                                            <h3 class="fw-bold text-primary mb-0"><i class="fa-solid fa-desktop me-2"></i> ZENITH OMS POS</h3>
                                            <p class="text-muted mb-0">Retail Order Management & Billing System</p>
                                            <small class="text-secondary">Colombo, Sri Lanka | Phone: +94 77 123 4567</small>
                                        </div>
                                        <div class="text-end">
                                            <h4 class="fw-bold mb-0">INVOICE</h4>
                                            <div class="badge bg-primary fs-6 mb-1">${o.invoice_no || o.order_no}</div>
                                            <div class="small text-muted">Date: ${o.order_date}</div>
                                            <div class="small fw-bold">Status: <span class="badge bg-success">${o.status}</span></div>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <div class="col-6">
                                            <h6 class="fw-bold text-secondary mb-1">Billed To Customer:</h6>
                                            <div class="fw-bold fs-6">${escapeHtml(c.name)}</div>
                                            <div>Contact: ${escapeHtml(c.contacts || '-')}</div>
                                            <div>Address: ${escapeHtml(c.address || '-')}</div>
                                        </div>
                                        <div class="col-6 text-end">
                                            <h6 class="fw-bold text-secondary mb-1">Logistics Reference:</h6>
                                            <div>Tracking No: <strong>${o.tracking_no || 'N/A'}</strong></div>
                                            <div>Delivery Partner: <strong>Prompt XP</strong></div>
                                        </div>
                                    </div>
                                    <table class="table table-bordered align-middle mb-3">
                                        <thead class="table-light">
                                            <tr>
                                                <th style="width: 5%;" class="text-center">#</th>
                                                <th style="width: 15%;">Product ID</th>
                                                <th style="width: 45%;">Description</th>
                                                <th style="width: 10%;" class="text-center">Qty</th>
                                                <th style="width: 12%;" class="text-end">Unit Price</th>
                                                <th style="width: 13%;" class="text-end">Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${itemsRows}
                                        </tbody>
                                    </table>
                                    <div class="row justify-content-end mb-3">
                                        <div class="col-5">
                                            <div class="d-flex justify-content-between py-1 border-bottom"><span>Subtotal:</span><span>${formatRs(o.sub_total, 0)}</span></div>
                                            <div class="d-flex justify-content-between py-1 border-bottom"><span>Delivery Charge:</span><span>${formatRs(o.delivery_charge, 0)}</span></div>
                                            <div class="d-flex justify-content-between py-1 border-bottom text-danger"><span>Discount:</span><span>${formatRs(o.discount, 0)}</span></div>
                                            <div class="d-flex justify-content-between py-2 fw-bold fs-5 text-primary"><span>Total Amount:</span><span>${formatRs(o.total_amount, 0)}</span></div>
                                        </div>
                                    </div>
                                    <div class="border-top pt-3 text-center text-muted small">
                                        <p class="mb-0">Thank you for your business! Terms: Payment due upon receipt.</p>
                                    </div>
                                </div>
                            `;

                            showModal('modalPrintPreview');
                        }
                    });
            }

            function generateBarcodeSVG(text, height = 40, barWidth = 1.8) {
                if (!text) text = '000000';
                text = String(text).trim();

                const code128 = [
                    "212222","222122","222221","121223","121322","131222","122213","122312","132212","221213",
                    "221312","231212","112232","122132","122231","113222","123122","123221","223211","221132",
                    "221231","213212","223112","312131","311222","321122","321221","312212","322112","322211",
                    "212123","212321","232121","111323","131123","131321","112313","132113","132311","211313",
                    "231113","231311","112133","112331","132131","113123","113321","133121","313121","211331",
                    "231131","213113","213311","213131","311123","311321","331121","312113","312311","332111",
                    "314111","221411","431111","111224","111422","121124","121421","141122","141221","112214",
                    "112412","122114","122411","142112","142211","241211","221114","413111","241112","134111",
                    "111242","121142","121241","114212","124112","124211","411212","421112","421211","212141",
                    "214121","412121","111143","111341","113141","114113","114311","411113","411311","113114",
                    "114131","311141","411131","211412","211214","211232","2331112"
                ];

                const startB = 104;
                const stop = 106;

                let checksum = startB;
                const sequence = [code128[startB]];

                for (let i = 0; i < text.length; i++) {
                    let val = text.charCodeAt(i) - 32;
                    if (val < 0 || val > 95) val = 0;
                    checksum += (val * (i + 1));
                    sequence.push(code128[val]);
                }

                const checkVal = checksum % 103;
                sequence.push(code128[checkVal]);
                sequence.push(code128[stop]);

                const patternString = sequence.join('');

                let totalWidth = 0;
                for (let i = 0; i < patternString.length; i++) {
                    totalWidth += (parseFloat(patternString[i]) * barWidth);
                }

                let rects = '';
                let posX = 0;
                for (let i = 0; i < patternString.length; i++) {
                    let w = parseFloat(patternString[i]) * barWidth;
                    if (i % 2 === 0) {
                        rects += `<rect x="${posX.toFixed(2)}" y="0" width="${w.toFixed(2)}" height="${height}" fill="#000000"/>`;
                    }
                    posX += w;
                }

                return `<svg xmlns="http://www.w3.org/2000/svg" width="${totalWidth.toFixed(0)}" height="${height}" viewBox="0 0 ${totalWidth.toFixed(0)} ${height}" style="display: block; margin: 0 auto; max-width: 100%; height: ${height}px;">${rects}</svg>`;
            }

            function renderParcelLabelView(orderId) {
                renderBulkParcelLabelsView([orderId]);
            }

            function renderBulkParcelLabelsView(orderIds) {
                if (!orderIds || !orderIds.length) {
                    SwalNotify('No order selected for parcel labels.', 'warning');
                    return;
                }

                fetch(baseUrl + 'get_bulk_parcel_details', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ ids: orderIds })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'success') {
                        const orders = data.orders;
                        const settings = data.settings || {};
                        const storeName = settings.store_name || 'Sithangi Teddy Factory';
                        const storePhone = settings.store_phone || '0775476996';
                        const storeLogo = settings.store_logo || '';
                        const deliveryPartner = settings.delivery_partner || 'Prompt XP';

                        const totalPages = Math.ceil(orders.length / 4);
                        document.getElementById('printModalTitle').innerText = `Bulk Parcel Labels Preview (${orders.length} Label${orders.length > 1 ? 's' : ''} - ${totalPages} Page${totalPages > 1 ? 's' : ''} / 4 per A4 Sheet)`;

                        const pageSize = 4;
                        let pagesHtml = '';

                        for (let p = 0; p < orders.length; p += pageSize) {
                            const pageOrders = orders.slice(p, p + pageSize);
                            let pageLabelsHtml = '';

                            pageOrders.forEach(item => {
                                const o = item.order;
                                const c = item.customer || {};

                                const rawTracking = o.tracking_no || ('PXP-' + Math.floor(100000 + Math.random() * 900000));
                                const trackingNo = escapeHtml(rawTracking);
                                const waybillId = escapeHtml(o.waybill_id || rawTracking);
                                const custName = escapeHtml(c.name || 'Walk-in Customer');
                                const custPhone = escapeHtml(c.contacts || '-') + (c.contact_2 ? ' / ' + escapeHtml(c.contact_2) : '');
                                const custAddress = escapeHtml(c.address || '-');
                                const custBranch = escapeHtml(c.nearest_city || 'Main Branch');
                                const orderDesc = escapeHtml(o.item_summary || 'General Retail Goods');
                                const orderNo = escapeHtml(o.order_no || ('ORD-' + o.id));
                                const invoiceNo = escapeHtml(o.invoice_no || '');
                                const orderDate = escapeHtml(o.formatted_date || '-');

                                let codVal = 0.00;
                                if (o.status !== 'Paid') {
                                    const bal = parseFloat(o.balance_amount);
                                    codVal = (bal > 0) ? bal : parseFloat(o.total_amount);
                                }

                                const topBarcodeSvg = generateBarcodeSVG(rawTracking, 38, 1.4);
                                const bottomBarcodeSvg = generateBarcodeSVG(o.waybill_id || rawTracking, 44, 1.6);

                                pageLabelsHtml += `
                                    <div class="parcel-label-a6 bg-white p-3 border border-2 border-dark rounded d-flex flex-column justify-content-between" style="box-sizing: border-box; height: 138mm; overflow: hidden; font-family: Arial, Helvetica, sans-serif; color: #000; line-height: 1.4;">
                                        
                                        <!-- Header: Courier & Top Barcode -->
                                        <div class="d-flex justify-content-between align-items-center border-bottom border-2 border-dark pb-2 mb-2">
                                            <div class="d-flex align-items-center gap-2">
                                                ${storeLogo ? `<img src="${storeLogo.startsWith('data:') ? storeLogo : (baseUrl + storeLogo)}" alt="Logo" style="max-height: 38px; max-width: 75px; object-fit: contain;">` : `<i class="fa-solid fa-truck-fast text-dark" style="font-size: 26px;"></i>`}
                                                <div>
                                                    <div class="fw-bold text-dark text-uppercase" style="font-size: 16px; letter-spacing: 0.5px; line-height: 1.1;">${escapeHtml(deliveryPartner)}</div>
                                                    <small class="text-secondary fw-bold" style="font-size: 10px;">Express Delivery</small>
                                                </div>
                                            </div>
                                            <div class="text-end" style="max-width: 150px;">
                                                <div>${topBarcodeSvg}</div>
                                                <div class="font-monospace fw-bold text-dark text-center" style="font-size: 11px; margin-top: 1px;">${trackingNo}</div>
                                            </div>
                                        </div>

                                        <!-- Sender & Order Ref -->
                                        <div class="border-bottom border-2 border-dark pb-2 mb-2" style="font-size: 12px; line-height: 1.45;">
                                            <div class="d-flex justify-content-between">
                                                <div>From: <strong class="text-dark">${escapeHtml(storeName)}</strong> (${escapeHtml(storePhone)})</div>
                                                <div>Order: <strong class="text-dark fs-6">${orderNo}</strong></div>
                                            </div>
                                            <div class="d-flex justify-content-between text-secondary fw-semibold" style="font-size: 11px;">
                                                <span>Date: ${orderDate}</span>
                                                ${invoiceNo ? `<span>Inv: ${invoiceNo}</span>` : ''}
                                            </div>
                                        </div>

                                        <!-- Customer Details & Recipient Block -->
                                        <div class="flex-grow-1 d-flex flex-column justify-content-between py-1">
                                            <div class="d-flex flex-column justify-content-around flex-grow-1 py-1" style="gap: 6px;">
                                                <div class="fw-bold text-uppercase text-dark border-bottom border-2 border-dark pb-1 mb-1" style="font-size: 13px; letter-spacing: 1px;">Recipient Details</div>
                                                <div style="font-size: 15px;">To: <strong class="text-dark text-uppercase" style="font-size: 19px !important; letter-spacing: 0.5px;">${custName}</strong></div>
                                                <div style="font-size: 14px;">Address: <span class="fw-bold text-dark">${custAddress}</span></div>
                                                <div style="font-size: 14px;">City / Branch: <span class="fw-bold text-dark">${custBranch}</span></div>
                                                <div style="font-size: 15px;">Contact Number: <strong class="text-dark" style="font-size: 16px !important;">${custPhone}</strong></div>
                                                <div class="text-muted" style="font-size: 12px;">Items: <span class="text-dark fw-bold">${orderDesc}</span></div>
                                            </div>

                                            <!-- COD Box -->
                                            <div class="p-2.5 rounded bg-light border border-2 border-dark d-flex justify-content-between align-items-center my-2 shadow-sm">
                                                <span class="fw-bold text-dark" style="font-size: 14px; letter-spacing: 0.5px;">COD AMOUNT:</span>
                                                <span class="fw-extrabold text-dark" style="font-size: 22px;">${formatRs(codVal, 0)}</span>
                                            </div>
                                        </div>

                                        <!-- Bottom Waybill Barcode -->
                                        <div class="pt-2 text-center border-top border-2 border-dark mt-auto">
                                            <div>${bottomBarcodeSvg}</div>
                                            <div class="font-monospace fw-bold text-dark" style="font-size: 12px; margin-top: 2px;">Waybill: ${waybillId}</div>
                                        </div>

                                    </div>
                                `;
                            });

                            pagesHtml += `
                                <div class="a4-parcel-page bg-white p-2 mb-4 mx-auto border shadow-sm" style="width: 200mm; min-height: 285mm; height: 285mm; box-sizing: border-box; display: grid; grid-template-columns: 1fr 1fr; grid-template-rows: 1fr 1fr; gap: 4mm; page-break-after: always; break-after: page; page-break-inside: avoid; break-inside: avoid;">
                                    ${pageLabelsHtml}
                                </div>
                            `;
                        }

                        document.getElementById('printModalBody').innerHTML = `
                            <div class="printable-area p-2">
                                ${pagesHtml}
                            </div>
                        `;

                        showModal('modalPrintPreview');
                    } else {
                        SwalNotify(data.message || 'Failed to generate parcel labels.', 'error');
                    }
                });
            }

            function renderBarcodePrintView(code, desc, price) {
                document.getElementById('printModalTitle').innerText = 'Product Barcode Label Preview';
                const barcodeSvg = generateBarcodeSVG(code, 50, 2);

                document.getElementById('printModalBody').innerHTML = `
                    <div class="printable-area bg-white p-4 border rounded mx-auto text-center shadow-sm" style="max-width: 320px;">
                        <h6 class="fw-bold mb-2">${escapeHtml(desc)}</h6>
                        <div class="my-3">${barcodeSvg}</div>
                        <div class="fw-bold fs-5 text-primary mb-1">${escapeHtml(code)}</div>
                        <div class="fw-bold text-dark fs-5">${formatRs(price, 0)}</div>
                    </div>
                `;

                showModal('modalPrintPreview');
            }

            document.getElementById('btnTriggerPrintAction').addEventListener('click', function() {
                window.print();
            });

            document.addEventListener('keydown', function(e) {
                if (e.key === 'F2') {
                    e.preventDefault();
                    document.getElementById('btnInsertCartItem').click();
                }
                if (e.key === 'F4') {
                    e.preventDefault();
                    document.getElementById('btnConfirmOrder').click();
                }
            });

            function escapeHtml(str) {
                if (!str) return '';
                return String(str)
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;')
                    .replace(/'/g, '&#039;');
            }

            initPOS();
        });
    </script>
</body>
</html>
