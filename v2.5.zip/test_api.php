<?php
$mysqli = new mysqli("localhost", "root", "", "teddy_pos");
$query = "SELECT orders.*, customers.name as customer_name, customers.contacts as customer_contacts, customers.address as customer_address 
          FROM orders 
          LEFT JOIN customers ON customers.id = orders.customer_id 
          WHERE orders.is_draft = 0 
          ORDER BY orders.id DESC";

$res = $mysqli->query($query);
$orders = $res->fetch_all(MYSQLI_ASSOC);

foreach ($orders as &$o) {
    $raw_date = (!empty($o['order_date']) && $o['order_date'] !== '0000-00-00 00:00:00') ? $o['order_date'] : ((!empty($o['created_at']) && $o['created_at'] !== '0000-00-00 00:00:00') ? $o['created_at'] : null);
    $o['formatted_date'] = $raw_date ? date('Y-m-d H:i', strtotime($raw_date)) : '-';
    
    $cnt_row = $mysqli->query("SELECT COUNT(*) as cnt FROM order_items WHERE order_id = " . (int)$o['id'])->fetch_assoc();
    $o['items_count'] = $cnt_row ? (int)$cnt_row['cnt'] : 0;

    $o['sub_total'] = number_format((float)$o['sub_total'], 2, '.', '');
    $o['delivery_charge'] = number_format((float)$o['delivery_charge'], 2, '.', '');
    $o['discount'] = number_format((float)$o['discount'], 2, '.', '');
    $o['total_cost'] = number_format((float)$o['total_cost'], 2, '.', '');
    $o['total_amount'] = number_format((float)$o['total_amount'], 2, '.', '');
    $o['profit'] = number_format((float)$o['profit'], 2, '.', '');
    $o['profit_margin'] = number_format((float)$o['profit_margin'], 2, '.', '');
}

header('Content-Type: application/json');
echo json_encode(array('status' => 'success', 'orders' => $orders));
