<?php
/**
 * Codseez OMS POS - CodeIgniter Application Bootstrapper
 */
define('ENVIRONMENT', isset($_SERVER['CI_ENV']) ? $_SERVER['CI_ENV'] : 'development');

if (ENVIRONMENT === 'development') {
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Sri Lanka Colombo Standard Timezone (UTC+05:30)
date_default_timezone_set('Asia/Colombo');

define('BASEPATH', __DIR__);
define('APPPATH', __DIR__ . '/application/');

// Helper Functions
if (!function_exists('base_url')) {
    function base_url($uri = '') {
        $scheme = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https://' : 'http://';
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
        $script = isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '';
        $base_dir = rtrim(dirname($script), '/\\');
        if ($base_dir === '/' || $base_dir === '\\') {
            $base_dir = '';
        }
        return $scheme . $host . $base_dir . '/' . ltrim($uri, '/');
    }
}

if (!function_exists('site_url')) {
    function site_url($uri = '') {
        return base_url('index.php/' . ltrim($uri, '/'));
    }
}

// Core Framework Bootstrapper for CodeIgniter compatibility
class CI_Input {
    public function get($key = null) {
        if (isset($_SERVER['REQUEST_URI']) && strpos($_SERVER['REQUEST_URI'], '?') !== false) {
            $q = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);
            if ($q) {
                parse_str($q, $qs);
                $_GET = array_merge($_GET, $qs);
            }
        }
        if ($key === null) return $_GET;
        return isset($_GET[$key]) ? $_GET[$key] : null;
    }
    public function post($key = null) {
        if ($key === null) return $_POST;
        return isset($_POST[$key]) ? $_POST[$key] : null;
    }
}

class CI_Output {
    private $content_type = 'text/html';
    private $output_data = '';

    public function set_content_type($type, $charset = 'UTF-8') {
        $this->content_type = $type;
        header("Content-Type: {$type}; charset={$charset}");
        return $this;
    }

    public function set_output($output) {
        $this->output_data = $output;
        return $this;
    }

    public function _display() {
        echo $this->output_data;
    }
}

class CI_Session {
    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            @session_start();
        }
    }
    public function userdata($key = null) {
        if (session_status() === PHP_SESSION_NONE) {
            @session_start();
        }
        if ($key === null) return isset($_SESSION) ? $_SESSION : array();
        return isset($_SESSION[$key]) ? $_SESSION[$key] : null;
    }
    public function set_userdata($key, $val = null) {
        if (session_status() === PHP_SESSION_NONE) {
            @session_start();
        }
        if (is_array($key)) {
            foreach ($key as $k => $v) {
                $_SESSION[$k] = $v;
            }
        } else {
            $_SESSION[$key] = $val;
        }
    }
    public function unset_userdata($key) {
        if (session_status() === PHP_SESSION_NONE) {
            @session_start();
        }
        if (is_array($key)) {
            foreach ($key as $k) unset($_SESSION[$k]);
        } else {
            unset($_SESSION[$key]);
        }
    }
    public function sess_destroy() {
        if (session_status() === PHP_SESSION_NONE) {
            @session_start();
        }
        $_SESSION = array();
        @session_destroy();
    }
}

class CI_Loader {
    public function database() {}
    public function helper($helpers) {}
    public function library($libraries) {}
    public function view($view, $data = array()) {
        extract($data);
        $file = APPPATH . 'views/' . $view . '.php';
        if (file_exists($file)) {
            include $file;
        } else {
            echo "View [{$view}] not found.";
        }
    }
}

class CI_DB_Result {
    private $rows = array();
    public function __construct($rows) {
        $this->rows = is_array($rows) ? $rows : array();
    }
    public function result_array() {
        return $this->rows;
    }
    public function row_array() {
        return isset($this->rows[0]) ? $this->rows[0] : null;
    }
    public function row() {
        if (isset($this->rows[0])) {
            return (object)$this->rows[0];
        }
        return null;
    }
}

class CI_DB {
    private $pdo;
    private $_select = '*';
    private $_from = '';
    private $_joins = array();
    private $_where = array();
    private $_group_starts = 0;
    private $_likes = array();
    private $_order_by = array();
    private $_limit = null;
    private $_sets = array();
    private $_in_trans = false;
    private $_trans_status = true;

    public function __construct() {
        $db_config = include APPPATH . 'config/database.php';
        $cfg = $db['default'];
        $dsn = "mysql:host={$cfg['hostname']};dbname={$cfg['database']};charset=utf8mb4";
        try {
            $this->pdo = new PDO($dsn, $cfg['username'], $cfg['password'], array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ));
            $this->pdo->exec("SET time_zone = '+05:30'");
        } catch (PDOException $e) {
            die("Database Connection Error: " . $e->getMessage());
        }
    }

    private function reset_query() {
        $this->_select = '*';
        $this->_from = '';
        $this->_joins = array();
        $this->_where = array();
        $this->_likes = array();
        $this->_order_by = array();
        $this->_limit = null;
        $this->_sets = array();
    }

    private function protect_col($field) {
        $field = trim($field);
        if (strpos($field, ' ') !== false || strpos($field, '(') !== false) {
            return $field;
        }
        if (strpos($field, '.') !== false) {
            $parts = explode('.', $field);
            return '`' . implode('`.`', $parts) . '`';
        }
        return "`{$field}`";
    }

    public function select($fields) {
        $this->_select = $fields;
        return $this;
    }

    public function select_sum($field, $alias = null) {
        $alias_name = $alias ? $alias : $field;
        $this->_select = "SUM(" . $this->protect_col($field) . ") as {$alias_name}";
        return $this;
    }

    public function from($table) {
        $this->_from = $table;
        return $this;
    }

    public function join($table, $cond, $type = 'INNER') {
        $this->_joins[] = strtoupper($type) . " JOIN {$table} ON {$cond}";
        return $this;
    }

    public function where($field, $value = null) {
        if (is_array($field)) {
            foreach ($field as $k => $v) {
                $this->where($k, $v);
            }
        } else {
            $col = $this->protect_col($field);
            $this->_where[] = array('raw' => "{$col} = ?", 'val' => $value);
        }
        return $this;
    }

    public function where_in($field, $values = array()) {
        if (empty($values)) return $this;
        $col = $this->protect_col($field);
        $placeholders = implode(', ', array_fill(0, count($values), '?'));
        $this->_where[] = array('raw' => "{$col} IN ({$placeholders})", 'vals' => array_values($values), 'is_in' => true);
        return $this;
    }

    public function group_start() {
        $this->_where[] = array('raw' => '(', 'val' => null, 'is_clause' => true);
        return $this;
    }

    public function group_end() {
        $this->_where[] = array('raw' => ')', 'val' => null, 'is_clause' => true);
        return $this;
    }

    public function like($field, $match) {
        $this->_likes[] = array('op' => 'AND', 'field' => $field, 'match' => "%{$match}%");
        return $this;
    }

    public function or_like($field, $match) {
        $this->_likes[] = array('op' => 'OR', 'field' => $field, 'match' => "%{$match}%");
        return $this;
    }

    public function order_by($field, $dir = 'ASC') {
        $this->_order_by[] = $this->protect_col($field) . " " . strtoupper($dir);
        return $this;
    }

    public function limit($limit) {
        $this->_limit = (int)$limit;
        return $this;
    }

    public function set($key, $value = '', $escape = TRUE) {
        if ($escape === FALSE) {
            $this->_sets[] = array('type' => 'raw', 'clause' => $this->protect_col($key) . " = {$value}");
        } else {
            $this->_sets[] = array('type' => 'param', 'key' => $key, 'val' => $value);
        }
        return $this;
    }

    public function get($table = null) {
        if ($table) $this->_from = $table;
        
        $sql = "SELECT {$this->_select} FROM " . $this->protect_col($this->_from);
        if (!empty($this->_joins)) {
            $sql .= " " . implode(' ', $this->_joins);
        }

        $params = array();
        $where_str = '';
        foreach ($this->_where as $w) {
            if (isset($w['is_clause'])) {
                $where_str .= " " . $w['raw'] . " ";
            } else if (!empty($w['is_in'])) {
                $trimmed = trim($where_str);
                if ($trimmed !== '' && substr($trimmed, -1) !== '(') {
                    $where_str .= " AND ";
                }
                $where_str .= $w['raw'];
                foreach ($w['vals'] as $v) {
                    $params[] = $v;
                }
            } else {
                $trimmed = trim($where_str);
                if ($trimmed !== '' && substr($trimmed, -1) !== '(') {
                    $where_str .= " AND ";
                }
                $where_str .= $w['raw'];
                $params[] = $w['val'];
            }
        }

        if (!empty($this->_likes)) {
            $like_parts = array();
            foreach ($this->_likes as $idx => $lk) {
                $op = ($idx > 0) ? $lk['op'] : '';
                $like_parts[] = "{$op} " . $this->protect_col($lk['field']) . " LIKE ?";
                $params[] = $lk['match'];
            }
            $trimmed = trim($where_str);
            if ($trimmed !== '') {
                $where_str .= " AND (" . implode(' ', $like_parts) . ")";
            } else {
                $where_str .= "(" . implode(' ', $like_parts) . ")";
            }
        }

        if (trim($where_str) !== '') {
            $sql .= " WHERE " . $where_str;
        }

        if (!empty($this->_order_by)) {
            $sql .= " ORDER BY " . implode(', ', $this->_order_by);
        }

        if ($this->_limit !== null) {
            $sql .= " LIMIT {$this->_limit}";
        }

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        $this->reset_query();
        return new CI_DB_Result($rows);
    }

    public function get_where($table, $where = array()) {
        $this->where($where);
        return $this->get($table);
    }

    public function count_all_results($table = null) {
        $res = $this->get($table)->result_array();
        return count($res);
    }

    public function insert($table, $data = array()) {
        $keys = array_keys($data);
        $cols = implode('`, `', $keys);
        $placeholders = implode(', ', array_fill(0, count($keys), '?'));
        
        $sql = "INSERT INTO `{$table}` (`{$cols}`) VALUES ({$placeholders})";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(array_values($data));
        
        $this->reset_query();
        return true;
    }

    public function insert_id() {
        return (int)$this->pdo->lastInsertId();
    }

    public function update($table, $data = array()) {
        $params = array();
        $set_parts = array();

        if (!empty($data)) {
            foreach ($data as $k => $v) {
                $set_parts[] = "`{$k}` = ?";
                $params[] = $v;
            }
        }

        if (!empty($this->_sets)) {
            foreach ($this->_sets as $s) {
                if ($s['type'] === 'raw') {
                    $set_parts[] = $s['clause'];
                } else {
                    $set_parts[] = "`{$s['key']}` = ?";
                    $params[] = $s['val'];
                }
            }
        }

        $sql = "UPDATE `{$table}` SET " . implode(', ', $set_parts);

        $where_parts = array();
        foreach ($this->_where as $w) {
            if (!isset($w['is_clause'])) {
                $where_parts[] = $w['raw'];
                $params[] = $w['val'];
            }
        }

        if (!empty($where_parts)) {
            $sql .= " WHERE " . implode(' AND ', $where_parts);
        }

        $stmt = $this->pdo->prepare($sql);
        $res = $stmt->execute($params);

        $this->reset_query();
        return $res;
    }

    public function delete($table) {
        $sql = "DELETE FROM `{$table}`";
        $params = array();
        $where_parts = array();

        foreach ($this->_where as $w) {
            if (!isset($w['is_clause'])) {
                $where_parts[] = $w['raw'];
                $params[] = $w['val'];
            }
        }

        if (!empty($where_parts)) {
            $sql .= " WHERE " . implode(' AND ', $where_parts);
        }

        $stmt = $this->pdo->prepare($sql);
        $res = $stmt->execute($params);

        $this->reset_query();
        return $res;
    }

    public function trans_start() {
        $this->pdo->beginTransaction();
        $this->_in_trans = true;
        $this->_trans_status = true;
    }

    public function trans_rollback() {
        if ($this->_in_trans) {
            $this->pdo->rollBack();
            $this->_in_trans = false;
        }
        $this->_trans_status = false;
    }

    public function trans_complete() {
        if ($this->_in_trans) {
            $this->pdo->commit();
            $this->_in_trans = false;
        }
        return $this->_trans_status;
    }

    public function trans_status() {
        return $this->_trans_status;
    }

    public function query($sql, $binds = array()) {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($binds);
        if (stripos(trim($sql), 'SELECT') === 0) {
            return new CI_DB_Result($stmt->fetchAll());
        }
        return true;
    }
}

abstract class CI_Controller {
    public $input;
    public $output;
    public $load;
    public $db;
    public $session;

    public function __construct() {
        $this->input = new CI_Input();
        $this->output = new CI_Output();
        $this->load = new CI_Loader();
        $this->db = new CI_DB();
        $this->session = new CI_Session();
    }
}

// Router
require_once APPPATH . 'controllers/Pos.php';

$uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
$script_name = isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '';

// Remove base directory from URI
$raw_path = parse_url($uri, PHP_URL_PATH);
$path = rawurldecode($raw_path);

$base_dir = rawurldecode(dirname($script_name));
$base_dir = str_replace('\\', '/', $base_dir);

if ($base_dir !== '/' && $base_dir !== '\\' && $base_dir !== '.') {
    if (strpos($path, $base_dir) === 0) {
        $path = substr($path, strlen($base_dir));
    }
}

$path = trim($path, '/');
$path = preg_replace('/^index\.php\/?/i', '', $path);
$path = trim($path, '/');

$segments = array_values(array_filter(explode('/', $path)));

$controller_name = 'Pos';
$method_name = 'index';

if (!empty($segments)) {
    if (strtolower($segments[0]) === 'pos') {
        array_shift($segments);
    }
    if (!empty($segments)) {
        $method_name = array_shift($segments);
    }
}

$params = $segments;

$controller = new Pos();
if (method_exists($controller, $method_name)) {
    call_user_func_array(array($controller, $method_name), $params);
    $controller->output->_display();
} else {
    header("HTTP/1.1 404 Not Found");
    echo "404 Endpoint [{$method_name}] Not Found.";
}
