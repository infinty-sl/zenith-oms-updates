-- Database Schema & Seed Data for Codseez OMS POS Clone
-- Application: Teddy POS / Codseez OMS
-- MySQL / MariaDB Compatible

CREATE DATABASE IF NOT EXISTS `teddy_pos` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `teddy_pos`;

-- --------------------------------------------------------
-- Table structure for `customers`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `order_items`;
DROP TABLE IF EXISTS `orders`;
DROP TABLE IF EXISTS `products`;
DROP TABLE IF EXISTS `customers`;
DROP TABLE IF EXISTS `settings`;

CREATE TABLE `customers` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `contacts` VARCHAR(255) DEFAULT NULL,
  `contact_2` VARCHAR(100) DEFAULT NULL,
  `email` VARCHAR(150) DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `nearest_city` VARCHAR(150) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table structure for `products`
-- --------------------------------------------------------
CREATE TABLE `products` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `product_code` VARCHAR(50) NOT NULL,
  `description` VARCHAR(255) NOT NULL,
  `stock` INT(11) NOT NULL DEFAULT 0,
  `cost` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `selling_price` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code_unique` (`product_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table structure for `orders`
-- --------------------------------------------------------
CREATE TABLE `orders` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `order_no` VARCHAR(50) NOT NULL,
  `customer_id` INT(11) DEFAULT NULL,
  `order_date` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `status` ENUM('Pending','Paid','Partial Paid') DEFAULT 'Paid',
  `tracking_no` VARCHAR(100) DEFAULT NULL,
  `delivery_charge` DECIMAL(12,2) DEFAULT 500.00,
  `discount` DECIMAL(12,2) DEFAULT 0.00,
  `sub_total` DECIMAL(12,2) DEFAULT 0.00,
  `total_cost` DECIMAL(12,2) DEFAULT 0.00,
  `total_amount` DECIMAL(12,2) DEFAULT 0.00,
  `profit` DECIMAL(12,2) DEFAULT 0.00,
  `profit_margin` DECIMAL(5,2) DEFAULT 0.00,
  `is_draft` TINYINT(1) DEFAULT 0,
  `draft_name` VARCHAR(100) DEFAULT NULL,
  `invoice_no` VARCHAR(50) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no_unique` (`order_no`),
  KEY `fk_orders_customer` (`customer_id`),
  CONSTRAINT `fk_orders_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table structure for `order_items`
-- --------------------------------------------------------
CREATE TABLE `order_items` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `order_id` INT(11) NOT NULL,
  `product_id` INT(11) DEFAULT NULL,
  `product_code` VARCHAR(50) NOT NULL,
  `description` VARCHAR(255) NOT NULL,
  `quantity` INT(11) NOT NULL DEFAULT 1,
  `cost` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `unit_price` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `total` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `fk_items_order` (`order_id`),
  KEY `fk_items_product` (`product_id`),
  CONSTRAINT `fk_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table structure for `settings`
-- --------------------------------------------------------
CREATE TABLE `settings` (
  `id` INT(11) NOT NULL DEFAULT 1,
  `reset_on_confirm` TINYINT(1) DEFAULT 1,
  `direct_print` TINYINT(1) DEFAULT 0,
  `enable_low_stock` TINYINT(1) DEFAULT 1,
  `low_stock_limit` INT(11) DEFAULT 5,
  `enable_delivery` TINYINT(1) DEFAULT 1,
  `delivery_partner` VARCHAR(100) DEFAULT 'Prompt XP',
  `custom_parcel_desc` TEXT DEFAULT NULL,
  `remind_delivery` TINYINT(1) DEFAULT 0,
  `remind_customer` TINYINT(1) DEFAULT 0,
  `default_status` ENUM('Pending','Paid','Partial Paid') DEFAULT 'Paid',
  `invoice_printer` VARCHAR(100) DEFAULT 'Standard PDF Printer',
  `receipt_printer` VARCHAR(100) DEFAULT 'POS-80 Thermal Printer',
  `parcel_printer` VARCHAR(100) DEFAULT 'Label Printer 4x6',
  `barcode_printer` VARCHAR(100) DEFAULT 'Barcode Label Printer',
  `restricted_mode` TINYINT(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table structure for `courier_rates`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `courier_rates` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `courier_name` VARCHAR(100) NOT NULL,
  `first_kg_rate` DECIMAL(12,2) NOT NULL DEFAULT 500.00,
  `additional_kg_rate` DECIMAL(12,2) NOT NULL DEFAULT 150.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `courier_name_unique` (`courier_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Initial Data Seeding
-- --------------------------------------------------------

-- Default Courier Rates
INSERT INTO `courier_rates` (`id`, `courier_name`, `first_kg_rate`, `additional_kg_rate`) VALUES
(1, 'Prompt XP', 500.00, 150.00),
(2, 'Fargo', 450.00, 120.00),
(3, 'Pronto', 400.00, 100.00),
(4, 'Domex', 480.00, 130.00),
(5, 'SL Post', 250.00, 80.00)
ON DUPLICATE KEY UPDATE `first_kg_rate` = VALUES(`first_kg_rate`), `additional_kg_rate` = VALUES(`additional_kg_rate`);

-- Default Settings (ID = 1)
INSERT INTO `settings` (`id`, `reset_on_confirm`, `direct_print`, `enable_low_stock`, `low_stock_limit`, `enable_delivery`, `delivery_partner`, `custom_parcel_desc`, `remind_delivery`, `remind_customer`, `default_status`, `invoice_printer`, `receipt_printer`, `parcel_printer`, `barcode_printer`, `restricted_mode`)
VALUES (1, 1, 0, 1, 5, 1, 'Prompt XP', 'Handle with Care - Electronic & Plush Retail Items', 1, 1, 'Paid', 'Standard PDF Printer', 'POS-80 Thermal Printer', 'Label Printer 4x6', 'Barcode Label Printer', 0);

-- Initial Customers (Matching Desktop Screenshots)
INSERT INTO `customers` (`id`, `name`, `contacts`, `address`) VALUES
(1, 'Visit Oder', '', 'Store Main Counter'),
(2, 'A J M Tekla Swarnahansini', '0771234567', 'No. 45, Galle Road, Colombo 03'),
(3, 'Sanjeewani Madhushika', '0750685834', '12/A, Kandy Road, Kiribathgoda'),
(4, 'M D M C N Dissanayaka', '0740634200', '88 Main Street, Negombo'),
(5, 'Anupama Madumali', '0743379118', 'No. 302, High Level Rd, Nugegoda'),
(6, 'Mahasamige Vijitha Lal', '0765434747', 'No 15, Temple Rd, Maharagama'),
(7, 'Janmi Navodya', '0772060209', '34 Station Road, Kelaniya'),
(8, 'Tharun Maleesha', '0713704375', '56 Cross Street, Pettah'),
(9, 'Shalika Mihisarani', '0768944373', '102 Main Street, Gampaha'),
(10, 'Pasindu Sankalpa', '0779937115', 'Flat 4B, Lotus Tower Rd, Colombo 01'),
(11, 'Raigama Shop', '0768770336', 'Raigama Junction, Horana'),
(12, 'Shammi', '0750685834', 'Main Street, Dehiwala'),
(13, 'Malinda Ekanayaka', '0740634200', 'High Level Road, Pannipitiya'),
(14, 'D G Asanka Nuwan K', '0743379118', 'Kandy Road, Kadawatha'),
(15, 'Lahiru Guruge', '0765434747', 'Galle Road, Mount Lavinia'),
(16, 'Sweet Art Cake', '0772060209', 'Station Road, Homagama'),
(17, 'Sathsarani Piumika', '0713704375', 'Negombo Road, Wattala'),
(18, 'R P Mahinda Jayalath', '0768944373', 'Kurunegala Road, Narammala'),
(19, 'Hug Zon', '0779937115', 'Nawala Road, Rajagiriya'),
(20, 'A H Nalin Lasantha', '0768770336', 'Peradeniya Road, Kandy'),
(21, 'Chamodya Madushani', '0773572540', 'Matara Road, Galle');

-- Initial Products (Matching Desktop Screenshots)
INSERT INTO `products` (`id`, `product_code`, `description`, `stock`, `cost`, `selling_price`) VALUES
(1, 'AA-0001', 'Labubu 1 Feet', 88, 700.00, 1000.00),
(2, 'BR-0001', '5 Feet Teddy', 23, 3900.00, 6900.00),
(3, 'BR-0007', '5 Feet D Blue', 10, 3900.00, 6900.00),
(4, 'BR-0025', '5 Feet D Pink', 47, 3900.00, 6900.00),
(5, 'BR-0026', '5 Feet H Pink', 19, 3900.00, 6900.00),
(6, 'BR-0027', '5 Feet L Pink', 20, 3900.00, 6900.00),
(7, 'BR-0028', '5 Feet Red', 33, 3900.00, 6900.00),
(8, 'BR-0029', '5 Feet L Blue', 6, 3900.00, 6900.00),
(9, 'BR-0030', '5 Feet Brown', 17, 3900.00, 6900.00),
(10, 'BR-0031', '5 Feet D Yellow', 3, 3900.00, 6900.00),
(11, 'BR-0032', '5 Feet L Yellow', 10, 3900.00, 6900.00),
(12, 'BR-0033', '5 Feet Purple', 17, 3900.00, 6900.00),
(13, 'BR-0034', '5 Feet Black & White', 8, 3900.00, 6900.00),
(14, 'BR-0035', '5 Feet Red & White', 7, 3900.00, 6900.00);

-- Initial Orders (Matching Desktop Screenshots)
INSERT INTO `orders` (`id`, `order_no`, `customer_id`, `order_date`, `status`, `tracking_no`, `delivery_charge`, `discount`, `sub_total`, `total_cost`, `total_amount`, `profit`, `profit_margin`, `is_draft`, `draft_name`, `invoice_no`) VALUES
(1, '2522', 2, '2026-10-02 20:12:45', 'Paid', 'PXP-998811', 700.00, 0.00, 6900.00, 3900.00, 7600.00, 3000.00, 39.47, 0, NULL, '1117'),
(2, '2521', 2, '2026-10-02 20:12:10', 'Paid', 'PXP-998812', 700.00, 0.00, 6900.00, 3900.00, 7600.00, 3000.00, 39.47, 0, NULL, '1116'),
(3, '2520', 1, '2026-10-02 20:12:00', 'Paid', 'PXP-998813', 700.00, 0.00, 6900.00, 3900.00, 7600.00, 3000.00, 39.47, 0, NULL, '1115'),
(4, '2519', 2, '2026-09-23 00:33:15', 'Paid', 'PXP-998814', 500.00, 0.00, 2700.00, 1700.00, 3200.00, 1000.00, 31.25, 0, NULL, '1114'),
(5, '2518', 3, '2026-09-23 00:30:40', 'Paid', 'PXP-998815', 500.00, 0.00, 9500.00, 5100.00, 10000.00, 4400.00, 44.00, 0, NULL, '1113'),
(6, '2517', 4, '2026-09-23 00:26:22', 'Paid', 'PXP-998816', 500.00, 0.00, 8800.00, 4900.00, 9300.00, 3900.00, 41.94, 0, NULL, '1112'),
(7, '2516', 5, '2026-09-23 00:21:05', 'Paid', 'PXP-998817', 500.00, 0.00, 7300.00, 4300.00, 7800.00, 3000.00, 38.46, 0, NULL, '1111'),
(8, '2515', 6, '2026-09-23 00:13:50', 'Paid', 'PXP-998818', 500.00, 0.00, 2700.00, 1700.00, 3200.00, 1000.00, 31.25, 0, NULL, '1110'),
(9, '2514', 7, '2026-09-23 00:11:15', 'Paid', 'PXP-998819', 500.00, 0.00, 2700.00, 1700.00, 3200.00, 1000.00, 31.25, 0, NULL, '1109'),
(10, '2513', 8, '2026-09-23 00:09:02', 'Paid', 'PXP-998820', 500.00, 0.00, 7300.00, 4300.00, 7800.00, 3000.00, 38.46, 0, NULL, '1108'),
(11, '2512', 9, '2026-09-23 00:04:18', 'Paid', 'PXP-998821', 500.00, 0.00, 7300.00, 4300.00, 7800.00, 3000.00, 38.46, 0, NULL, '1107');

-- Initial Order Items
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_code`, `description`, `quantity`, `cost`, `unit_price`, `total`) VALUES
(1, 1, 2, 'BR-0001', '5 Feet Teddy', 1, 3900.00, 6900.00, 6900.00),
(2, 2, 2, 'BR-0001', '5 Feet Teddy', 1, 3900.00, 6900.00, 6900.00),
(3, 3, 2, 'BR-0001', '5 Feet Teddy', 1, 3900.00, 6900.00, 6900.00),
(4, 4, 1, 'AA-0001', 'Labubu 1 Feet', 2, 700.00, 1000.00, 2000.00),
(5, 5, 2, 'BR-0001', '5 Feet Teddy', 1, 3900.00, 6900.00, 6900.00),
(6, 6, 7, 'BR-0028', '5 Feet Red', 1, 3900.00, 6900.00, 6900.00);

-- --------------------------------------------------------
-- Table structure for `users`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `role` ENUM('admin', 'cashier') NOT NULL DEFAULT 'cashier',
  `status` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `users` (`id`, `username`, `password`, `full_name`, `role`, `status`) VALUES
(1, 'admin', 'admin', 'Super Admin', 'admin', 1),
(2, 'cashier', '1234', 'Cashier 1', 'cashier', 1);

